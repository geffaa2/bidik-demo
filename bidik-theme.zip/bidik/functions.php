<?php
/** Bidik block theme: loads the site stylesheet and the custom-select script. */
defined( 'ABSPATH' ) || exit;

add_action( 'wp_enqueue_scripts', static function (): void {
	$dir = get_theme_file_path( 'assets/' );
	$uri = get_theme_file_uri( 'assets/' );
	wp_enqueue_style( 'bidik-site', $uri . 'site.css', [], (string) filemtime( $dir . 'site.css' ) );
	wp_enqueue_script( 'bidik-site', $uri . 'site.js', [], (string) filemtime( $dir . 'site.js' ), true );
} );
