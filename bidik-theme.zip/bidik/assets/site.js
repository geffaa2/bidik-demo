/* Bidik: custom select. Replaces native <select> in membership forms with an ARIA listbox; the real select stays in the DOM and keeps the value. */
(function () {
	var CHEVRON = '<svg class="icon sm" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
	var uid = 0;

	function enhance(select) {
		if (select.dataset.bdSelect || select.multiple) return;
		select.dataset.bdSelect = '1';
		var id = 'bd-sel-' + (++uid);
		var wrap = document.createElement('div');
		wrap.className = 'bd-select';
		select.parentNode.insertBefore(wrap, select);
		wrap.appendChild(select);
		select.tabIndex = -1;
		select.setAttribute('aria-hidden', 'true');

		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'bd-select__btn';
		btn.setAttribute('aria-haspopup', 'listbox');
		btn.setAttribute('aria-expanded', 'false');
		btn.setAttribute('aria-controls', id);
		var label = select.id && document.querySelector('label[for="' + select.id + '"]');
		if (label) { if (!label.id) label.id = id + '-label'; btn.setAttribute('aria-labelledby', label.id + ' ' + id + '-btn'); }
		btn.id = id + '-btn';
		var text = document.createElement('span');
		btn.appendChild(text);
		btn.insertAdjacentHTML('beforeend', CHEVRON);

		var list = document.createElement('ul');
		list.id = id;
		list.className = 'bd-select__list';
		list.setAttribute('role', 'listbox');
		list.hidden = true;
		list.tabIndex = -1;

		var opts = Array.prototype.slice.call(select.options);
		var items = opts.map(function (o, i) {
			var li = document.createElement('li');
			li.setAttribute('role', 'option');
			li.id = id + '-o' + i;
			li.textContent = o.text;
			li.dataset.index = i;
			list.appendChild(li);
			return li;
		});
		wrap.appendChild(btn);
		wrap.appendChild(list);

		var active = select.selectedIndex;
		function paint() {
			text.textContent = opts[select.selectedIndex] ? opts[select.selectedIndex].text : '';
			items.forEach(function (li, i) {
				li.setAttribute('aria-selected', i === select.selectedIndex ? 'true' : 'false');
				li.classList.toggle('is-active', i === active);
			});
			if (!list.hidden && items[active]) {
				btn.setAttribute('aria-activedescendant', items[active].id);
				items[active].scrollIntoView({ block: 'nearest' });
			}
		}
		function open() { list.hidden = false; btn.setAttribute('aria-expanded', 'true'); active = select.selectedIndex; paint(); }
		function close(focus) { list.hidden = true; btn.setAttribute('aria-expanded', 'false'); btn.removeAttribute('aria-activedescendant'); if (focus) btn.focus(); }
		function choose(i) {
			if (i < 0 || i >= opts.length) return;
			select.selectedIndex = i;
			select.dispatchEvent(new Event('change', { bubbles: true }));
			active = i; paint(); close(true);
		}

		btn.addEventListener('click', function () { list.hidden ? open() : close(); });
		list.addEventListener('mousedown', function (e) { e.preventDefault(); });
		list.addEventListener('click', function (e) { var li = e.target.closest('li'); if (li) choose(+li.dataset.index); });
		var typed = '', timer;
		btn.addEventListener('keydown', function (e) {
			var k = e.key;
			if (list.hidden) {
				if (k === 'ArrowDown' || k === 'ArrowUp' || k === 'Enter' || k === ' ') { e.preventDefault(); open(); }
				else if (k.length === 1) { typeahead(k); }
				return;
			}
			if (k === 'ArrowDown') { e.preventDefault(); active = Math.min(active + 1, items.length - 1); paint(); }
			else if (k === 'ArrowUp') { e.preventDefault(); active = Math.max(active - 1, 0); paint(); }
			else if (k === 'Home') { e.preventDefault(); active = 0; paint(); }
			else if (k === 'End') { e.preventDefault(); active = items.length - 1; paint(); }
			else if (k === 'Enter' || k === ' ') { e.preventDefault(); choose(active); }
			else if (k === 'Escape') { e.preventDefault(); close(true); }
			else if (k === 'Tab') { close(false); }
			else if (k.length === 1) { typeahead(k); }
		});
		function typeahead(ch) {
			clearTimeout(timer); typed += ch.toLowerCase(); timer = setTimeout(function () { typed = ''; }, 600);
			for (var i = 0; i < opts.length; i++) {
				if (opts[i].text.toLowerCase().indexOf(typed) === 0) { active = i; if (list.hidden) { select.selectedIndex = i; select.dispatchEvent(new Event('change', { bubbles: true })); } paint(); break; }
			}
		}
		document.addEventListener('click', function (e) { if (!wrap.contains(e.target) && !list.hidden) close(false); });
		select.addEventListener('change', paint);
		paint();
	}

	/* After a failed checkout PMPro puts the old card number and code back. Clear them and focus the number. */
	function resetCardAfterError() {
		var form = document.querySelector('form.pmpro_form');
		var number = form && form.querySelector('#AccountNumber');
		if (!number || !document.querySelector('.pmpro_message.pmpro_error')) return;
		number.value = '';
		var cvv = form.querySelector('#CVV');
		if (cvv) cvv.value = '';
		number.focus({ preventScroll: true });
	}

	function init() {
		document.querySelectorAll('.pmpro select, .pmpro_login_wrap select').forEach(enhance);
		resetCardAfterError();
	}
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

/* Billing notice: dismiss it for this visit. */
(function () {
  var bar = document.querySelector('[data-bd-banner]');
  if (!bar) return;
  try { if (sessionStorage.getItem('bd-banner-off')) { bar.hidden = true; return; } } catch (e) {}
  bar.querySelector('[data-bd-banner-close]').addEventListener('click', function () {
    bar.hidden = true;
    try { sessionStorage.setItem('bd-banner-off', '1'); } catch (e) {}
  });
})();

