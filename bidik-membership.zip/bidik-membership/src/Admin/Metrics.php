<?php
namespace Bidik\Admin;

/**
 * Pure: the numbers on Bidik › Overview. No WordPress, so the owner's MRR can be checked against the subscriptions by a test.
 *
 * MRR counts what is being paid for: active and past-due (still inside the grace period) subscriptions.
 * Trials have paid nothing yet, paused plans bill nothing, canceled plans are gone. A yearly price counts as one twelfth a month.
 */
final class Metrics {
	public const PAYING = [ 'active', 'past_due' ];

	/** @param array{status:string,interval:string,price:int} $s price in cents for one billing interval */
	public static function monthly( array $s ): float {
		return 'year' === $s['interval'] ? $s['price'] / 12 : (float) $s['price'];
	}

	/** @param list<array{status:string,interval:string,price:int}> $subs @return int cents a month */
	public static function mrr( array $subs ): int {
		$sum = 0.0;
		foreach ( $subs as $s ) {
			if ( in_array( $s['status'], self::PAYING, true ) ) {
				$sum += self::monthly( $s );
			}
		}
		return (int) round( $sum );
	}

	/** @param list<array{status:string,tier:string}> $subs @return array<string,int> paying members per tier */
	public static function by_tier( array $subs ): array {
		$out = [ 'member' => 0, 'pro' => 0 ];
		foreach ( $subs as $s ) {
			if ( in_array( $s['status'], self::PAYING, true ) && isset( $out[ $s['tier'] ] ) ) {
				++$out[ $s['tier'] ];
			}
		}
		return $out;
	}

	/** Share of finished trials that became paying customers, as a fraction (null when no trial finished). @param bool[] $converted one entry per finished trial */
	public static function conversion( array $converted ): ?float {
		return $converted ? count( array_filter( $converted ) ) / count( $converted ) : null;
	}

	/** Churned in the window as a share of everyone who was paying at its start (those still paying plus those who left). */
	public static function churn_rate( int $churned, int $paying_now ): ?float {
		$base = $churned + $paying_now;
		return $base > 0 ? $churned / $base : null;
	}

	public static function money( int $cents ): string {
		return '$' . number_format( $cents / 100, 2 );
	}

	public static function percent( ?float $fraction ): string {
		return null === $fraction ? 'n/a' : rtrim( rtrim( number_format( $fraction * 100, 1 ), '0' ), '.' ) . '%';
	}
}
