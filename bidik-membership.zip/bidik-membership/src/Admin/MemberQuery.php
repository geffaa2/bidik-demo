<?php
namespace Bidik\Admin;

use Bidik\Billing\MembershipSync;
use Bidik\Billing\PlanChange;

defined( 'ABSPATH' ) || exit;

/** The Members list and its CSV export read through this one query, so what you filter is what you download. */
final class MemberQuery {
	public const COLUMNS = [ 'member_id', 'email', 'name', 'plan', 'interval', 'status', 'monthly_amount', 'joined_at', 'period_end', 'grace_until', 'churn_type', 'stripe_subscription_id' ];
	public const STATUSES = [ 'trialing', 'active', 'past_due', 'paused', 'canceled' ];

	/** @param array{level?:string,status?:string,s?:string} $f */
	private static function where( array $f ): array {
		global $wpdb;
		$w = [ '1=1' ];
		$a = [];
		if ( ! empty( $f['level'] ) && in_array( $f['level'], [ 'member', 'pro' ], true ) ) {
			$ids = [];
			foreach ( pmpro_getAllLevels( true, false, true ) as $l ) {
				if ( get_pmpro_membership_level_meta( (int) $l->id, 'bidik_tier', true ) === $f['level'] ) {
					$ids[] = (int) $l->id;
				}
			}
			$w[] = 's.level_id IN (' . ( $ids ? implode( ',', $ids ) : '0' ) . ')';
		}
		if ( ! empty( $f['status'] ) && in_array( $f['status'], self::STATUSES, true ) ) {
			$w[] = 's.status = %s';
			$a[] = $f['status'];
		}
		if ( ! empty( $f['s'] ) ) {
			$like = '%' . $wpdb->esc_like( (string) $f['s'] ) . '%';
			$w[]  = '(u.user_email LIKE %s OR u.display_name LIKE %s OR u.user_login LIKE %s)';
			array_push( $a, $like, $like, $like );
		}
		return [ implode( ' AND ', $w ), $a ];
	}

	public static function count( array $f ): int {
		global $wpdb;
		[ $w, $a ] = self::where( $f );
		$sql = "SELECT COUNT(*) FROM {$wpdb->prefix}bidik_subscriptions s JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE $w";
		return (int) $wpdb->get_var( $a ? $wpdb->prepare( $sql, $a ) : $sql );
	}

	/** @param array{level?:string,status?:string,s?:string} $f @return list<array<string,mixed>> */
	public static function rows( array $f, string $orderby = 'joined', string $order = 'desc', int $limit = 0, int $offset = 0 ): array {
		global $wpdb;
		[ $w, $a ] = self::where( $f );
		$col = [ 'joined' => 's.created_at', 'status' => 's.status', 'plan' => 's.level_id', 'name' => 'u.display_name', 'renews' => 's.current_period_end' ][ $orderby ] ?? 's.created_at';
		$dir = 'asc' === strtolower( $order ) ? 'ASC' : 'DESC';
		$sql = "SELECT s.*, u.user_email, u.display_name FROM {$wpdb->prefix}bidik_subscriptions s JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE $w ORDER BY $col $dir, s.id DESC" . ( $limit ? sprintf( ' LIMIT %d OFFSET %d', $limit, $offset ) : '' );
		$out = [];
		foreach ( (array) $wpdb->get_results( $a ? $wpdb->prepare( $sql, $a ) : $sql, ARRAY_A ) as $s ) {
			$lvl   = PlanChange::level( (int) $s['level_id'] );
			$cents = (int) round( MembershipSync::price_for( (int) $s['user_id'], (int) $s['level_id'] ) * 100 );
			$out[] = $s + [ 'plan' => $lvl['name'] ?? '', 'tier' => $lvl['tier'] ?? '', 'interval' => $lvl['interval'] ?? 'month', 'monthly_cents' => (int) round( Metrics::monthly( [ 'status' => 'active', 'interval' => $lvl['interval'] ?? 'month', 'price' => $cents ] ) ) ];
		}
		return $out;
	}

	/** @param list<array<string,mixed>> $rows */
	public static function csv( array $rows ): string {
		$out = \Bidik\Import\Csv::line( self::COLUMNS );
		foreach ( $rows as $r ) {
			$out .= \Bidik\Import\Csv::line( [ (string) $r['user_id'], (string) $r['user_email'], (string) $r['display_name'], (string) $r['plan'], (string) $r['interval'], (string) $r['status'],
				in_array( $r['status'], Metrics::PAYING, true ) ? number_format( $r['monthly_cents'] / 100, 2, '.', '' ) : '0.00', (string) $r['created_at'], (string) ( $r['current_period_end'] ?? '' ), (string) ( $r['grace_until'] ?? '' ),
				(string) ( $r['churn_type'] ?? '' ), (string) $r['gateway_subscription_id'] ] );
		}
		return $out;
	}
}
