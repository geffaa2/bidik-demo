<?php
namespace Bidik\Admin;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/** Bidik › Members: filter by plan and status, search, sort, and export exactly what is filtered. */
final class MembersTable extends \WP_List_Table {
	public function __construct() {
		parent::__construct( [ 'singular' => 'member', 'plural' => 'members', 'ajax' => false ] );
	}

	/** @return array{level:string,status:string,s:string} */
	public static function filters(): array {
		return [ 'level' => sanitize_key( $_GET['level'] ?? '' ), 'status' => sanitize_key( $_GET['status'] ?? '' ), 's' => sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ) ]; // phpcs:ignore WordPress.Security.NonceVerification
	}

	public function get_columns(): array {
		return [ 'name' => 'Member', 'plan' => 'Plan', 'status' => 'Status', 'mrr' => 'Per month', 'joined' => 'Joined', 'renews' => 'Renews or ends' ];
	}

	protected function get_sortable_columns(): array {
		return [ 'name' => [ 'name', false ], 'plan' => [ 'plan', false ], 'status' => [ 'status', false ], 'joined' => [ 'joined', true ], 'renews' => [ 'renews', false ] ];
	}

	public function prepare_items(): void {
		$f     = self::filters();
		$per   = 20;
		$page  = max( 1, $this->get_pagenum() );
		$order = sanitize_key( $_GET['order'] ?? 'desc' ); // phpcs:ignore WordPress.Security.NonceVerification
		$by    = sanitize_key( $_GET['orderby'] ?? 'joined' ); // phpcs:ignore WordPress.Security.NonceVerification
		$this->_column_headers = [ $this->get_columns(), [], $this->get_sortable_columns() ];
		$this->items           = MemberQuery::rows( $f, $by, $order, $per, ( $page - 1 ) * $per );
		$this->set_pagination_args( [ 'total_items' => MemberQuery::count( $f ), 'per_page' => $per ] );
	}

	public function no_items(): void {
		echo 'No members match. Clear the filters, or load the demo history with the seeder.';
	}

	public static function badge( string $status ): string {
		$label = [ 'trialing' => 'Trial', 'active' => 'Active', 'past_due' => 'Past due', 'paused' => 'Paused', 'canceled' => 'Canceled' ][ $status ] ?? $status;
		return '<span class="bd-pill bd-pill--' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
	}

	public function column_name( $r ): string {
		$url = add_query_arg( [ 'page' => 'bidik-members', 'member' => (int) $r['user_id'] ], admin_url( 'admin.php' ) );
		return '<strong><a href="' . esc_url( $url ) . '">' . esc_html( $r['display_name'] ) . '</a></strong><br><span class="bd-sub">' . esc_html( $r['user_email'] ) . '</span>';
	}

	public function column_default( $r, $col ) {
		$d = static fn( ?string $m ) => $m ? esc_html( ( new \DateTimeImmutable( $m, new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( 'j M Y' ) ) : '<span class="bd-sub">none</span>';
		switch ( $col ) {
			case 'plan':
				return esc_html( $r['plan'] );
			case 'status':
				return self::badge( $r['status'] ) . ( $r['churn_type'] ? '<br><span class="bd-sub">' . esc_html( $r['churn_type'] ) . '</span>' : '' );
			case 'mrr':
				return in_array( $r['status'], Metrics::PAYING, true ) ? esc_html( Metrics::money( $r['monthly_cents'] ) ) : '<span class="bd-sub">0</span>';
			case 'joined':
				return $d( $r['created_at'] );
			case 'renews':
				return 'past_due' === $r['status'] ? 'grace until ' . $d( $r['grace_until'] ) : ( 'canceled' === $r['status'] ? $d( $r['canceled_at'] ?? null ) : $d( $r['current_period_end'] ) );
		}
		return '';
	}

	protected function extra_tablenav( $which ): void {
		if ( 'top' !== $which ) {
			return;
		}
		$f   = self::filters();
		$sel = static function ( string $name, array $opts, string $cur ): string {
			$h = '<label class="screen-reader-text" for="bd-f-' . esc_attr( $name ) . '">' . esc_html( ucfirst( $name ) ) . '</label><select name="' . esc_attr( $name ) . '" id="bd-f-' . esc_attr( $name ) . '">';
			foreach ( $opts as $v => $l ) {
				$h .= '<option value="' . esc_attr( (string) $v ) . '"' . selected( $cur, (string) $v, false ) . '>' . esc_html( $l ) . '</option>';
			}
			return $h . '</select>';
		};
		echo '<div class="alignleft actions">' . $sel( 'level', [ '' => 'All plans', 'member' => 'Member', 'pro' => 'Pro' ], $f['level'] ) // phpcs:ignore WordPress.Security.EscapeOutput
			. $sel( 'status', [ '' => 'All statuses', 'trialing' => 'Trial', 'active' => 'Active', 'past_due' => 'Past due', 'paused' => 'Paused', 'canceled' => 'Canceled' ], $f['status'] ) // phpcs:ignore WordPress.Security.EscapeOutput
			. '<input type="submit" class="button" value="Filter">';
		$export = wp_nonce_url( add_query_arg( array_filter( $f ) + [ 'action' => 'bidik_export' ], admin_url( 'admin-post.php' ) ), 'bidik_export' );
		echo ' <a class="button" href="' . esc_url( $export ) . '">Export CSV</a></div>';
	}
}
