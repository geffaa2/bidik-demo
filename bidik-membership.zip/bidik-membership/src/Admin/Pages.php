<?php
namespace Bidik\Admin;

use Bidik\Billing\MembershipSync;
use Bidik\Billing\PlanChange;
use Bidik\Courses\Catalog;
use Bidik\Courses\Progress;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** The owner's side: Bidik › Overview, Members (and a member's page), Emails. Plain wp-admin components. */
final class Pages {
	public static function register(): void {
		add_action( 'admin_menu', [ self::class, 'menu' ] );
		add_action( 'admin_post_bidik_export', [ self::class, 'export' ] );
		add_action( 'admin_enqueue_scripts', static function ( string $hook ): void {
			if ( str_contains( $hook, 'bidik' ) ) {
				wp_enqueue_style( 'bidik-admin', plugins_url( 'assets/admin-bidik.css', BIDIK_FILE ), [], (string) filemtime( dirname( __DIR__, 2 ) . '/assets/admin-bidik.css' ) );
			}
		} );
		Data::register();
	}

	public static function menu(): void {
		$cap = 'manage_options';
		add_menu_page( 'Bidik', 'Bidik', $cap, 'bidik', [ self::class, 'overview' ], 'dashicons-camera', 3 );
		add_submenu_page( 'bidik', 'Overview', 'Overview', $cap, 'bidik', [ self::class, 'overview' ] );
		add_submenu_page( 'bidik', 'Members', 'Members', $cap, 'bidik-members', [ self::class, 'members' ] );
		add_submenu_page( 'bidik', 'Emails', 'Emails', $cap, 'bidik-emails', [ self::class, 'emails' ] );
		add_submenu_page( 'bidik', 'Import', 'Import', $cap, 'bidik-import', [ \Bidik\Import\Admin::class, 'page' ] );
		add_submenu_page( 'bidik', 'Integrations', 'Integrations', $cap, 'bidik-integrations', [ \Bidik\Esp\Admin::class, 'page' ] );
	}

	private static function guard(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'You do not have permission to open this page.', 'Not allowed', [ 'response' => 403 ] );
		}
	}

	private static function d( ?string $mysql, string $fmt = 'j M Y' ): string {
		return $mysql ? ( new \DateTimeImmutable( $mysql, new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( $fmt ) : '';
	}

	/* -------------------------------------------------------------- overview */

	public static function overview(): void {
		self::guard();
		Data::snapshot_today();
		$o      = Data::overview();
		$series = Data::series( 180 );
		$card   = static fn( string $label, string $value, string $note = '' ) => '<div class="bd-card"><p class="bd-card__label">' . esc_html( $label ) . '</p><p class="bd-card__value">' . esc_html( $value ) . '</p>' . ( $note ? '<p class="bd-card__note">' . esc_html( $note ) . '</p>' : '' ) . '</div>';
		$churn  = $o['churn'];
		echo '<div class="wrap bd-admin"><h1>Bidik › Overview</h1><p class="bd-lead">Everything on this page is computed from the subscriptions, so it always agrees with the Members list.</p><div class="bd-cards">'; // phpcs:ignore
		echo $card( 'MRR', Metrics::money( $o['mrr'] ), 'Active and past-due plans; yearly counts as 1/12' ) // phpcs:ignore WordPress.Security.EscapeOutput
			. $card( 'Paying members', (string) ( $o['by_tier']['member'] + $o['by_tier']['pro'] ), $o['by_tier']['member'] . ' Member · ' . $o['by_tier']['pro'] . ' Pro · ' . $o['free'] . ' Free' )
			. $card( 'Trials running', (string) $o['trials'], 'Not paid yet, so not in MRR' )
			. $card( 'Trial to paid, 30 days', Metrics::percent( $o['conversion'] ), $o['trials_done'] ? $o['trials_done'] . ' trials ended' : 'No trial ended in the last 30 days' )
			. $card( 'Churn, 30 days', (string) ( $churn['voluntary'] + $churn['involuntary'] ), $churn['voluntary'] . ' chose to leave · ' . $churn['involuntary'] . ' payment failed · ' . Metrics::percent( $churn['rate'] ) );
		echo '</div>';
		echo '<div class="bd-box"><h2>MRR, last 6 months</h2>' . self::chart( $series ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput

		echo '<div class="bd-box"><h2>In grace period <span class="bd-sub">(' . count( $o['grace'] ) . ')</span></h2>';
		if ( ! $o['grace'] ) {
			echo '<p class="bd-sub">Nobody is past due.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>Member</th><th>Plan</th><th>Owes</th><th>Access until</th><th>Days left</th></tr></thead><tbody>';
			global $wpdb;
			foreach ( $o['grace'] as $g ) {
				$u    = get_userdata( $g['user_id'] );
				$sub  = $wpdb->get_row( $wpdb->prepare( "SELECT grace_until, level_id FROM {$wpdb->prefix}bidik_subscriptions WHERE id = %d", $g['id'] ), ARRAY_A );
				$open = (int) $wpdb->get_var( $wpdb->prepare( "SELECT amount_cents FROM {$wpdb->prefix}bidik_invoices WHERE subscription_id = %d AND status = 'open' ORDER BY id DESC LIMIT 1", $g['id'] ) );
				$left = max( 0, (int) ceil( ( strtotime( $sub['grace_until'] . ' UTC' ) - Clock::now() ) / DAY_IN_SECONDS ) );
				$lvl  = PlanChange::level( (int) $sub['level_id'] );
				echo '<tr><td><a href="' . esc_url( add_query_arg( [ 'page' => 'bidik-members', 'member' => $g['user_id'] ], admin_url( 'admin.php' ) ) ) . '">' . esc_html( $u ? $u->display_name : '#' . $g['user_id'] ) . '</a></td><td>' . esc_html( $lvl['name'] ?? '' ) . '</td><td>' . esc_html( Metrics::money( $open ) ) . '</td><td>' . esc_html( self::d( $sub['grace_until'] ) ) . '</td><td>' . (int) $left . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div></div>';
	}

	/** An inline SVG line chart with the numbers underneath for anyone who cannot see it. @param list<array<string,mixed>> $series */
	public static function chart( array $series ): string {
		if ( count( $series ) < 2 ) {
			return '<p class="bd-sub">The chart appears after the second daily snapshot. Load the demo history with the seeder to see it now.</p>';
		}
		$w = 860;
		$h = 240;
		[ $l, $r, $t, $b ] = [ 56, 12, 12, 28 ];
		$max  = max( 1, max( array_column( $series, 'mrr' ) ) );
		$step = 10 ** max( 0, strlen( (string) intdiv( $max, 100 ) ) - 1 ) * 100; // a round gridline step in cents
		$top  = (int) ceil( $max / $step ) * $step;
		$n    = count( $series );
		$x    = static fn( int $i ) => $l + ( $w - $l - $r ) * $i / ( $n - 1 );
		$y    = static fn( int $v ) => $t + ( $h - $t - $b ) * ( 1 - $v / $top );
		$pts  = [];
		foreach ( $series as $i => $p ) {
			$pts[] = round( $x( $i ), 1 ) . ',' . round( $y( $p['mrr'] ), 1 );
		}
		$grid = '';
		for ( $g = 0; $g <= 4; $g++ ) {
			$v     = (int) round( $top * $g / 4 );
			$grid .= '<line x1="' . $l . '" x2="' . ( $w - $r ) . '" y1="' . round( $y( $v ), 1 ) . '" y2="' . round( $y( $v ), 1 ) . '" class="bd-grid"/><text x="' . ( $l - 8 ) . '" y="' . round( $y( $v ) + 4, 1 ) . '" text-anchor="end" class="bd-axis">' . esc_html( '$' . number_format( $v / 100 ) ) . '</text>';
		}
		$ticks = '';
		$seen  = [];
		foreach ( $series as $i => $p ) {
			$m = substr( $p['day'], 0, 7 );
			if ( ! isset( $seen[ $m ] ) && ( $i > 0 || (int) substr( $p['day'], 8, 2 ) <= 7 ) ) { // label each month where it starts; the first only if it starts early enough to leave room
				$seen[ $m ] = 1;
				$ticks     .= '<text x="' . round( $x( $i ), 1 ) . '" y="' . ( $h - 8 ) . '" text-anchor="middle" class="bd-axis">' . esc_html( ( new \DateTimeImmutable( $p['day'] ) )->format( 'M' ) ) . '</text>';
			}
		}
		$first = $series[0]['mrr'];
		$last  = $series[ $n - 1 ]['mrr'];
		$area  = 'M' . implode( ' L', $pts ) . ' L' . round( $x( $n - 1 ), 1 ) . ',' . ( $h - $b ) . ' L' . $l . ',' . ( $h - $b ) . ' Z';
		return '<svg class="bd-chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . esc_attr( 'MRR over the last ' . $n . ' days, from ' . Metrics::money( $first ) . ' to ' . Metrics::money( $last ) ) . '">' . $grid . $ticks
			. '<path d="' . $area . '" class="bd-area"/><polyline points="' . implode( ' ', $pts ) . '" class="bd-line" fill="none"/></svg>'
			. '<p class="bd-sub">From ' . esc_html( Metrics::money( $first ) ) . ' on ' . esc_html( $series[0]['day'] ) . ' to ' . esc_html( Metrics::money( $last ) ) . ' on ' . esc_html( $series[ $n - 1 ]['day'] ) . '. Trials are not counted until they convert.</p>';
	}

	/* -------------------------------------------------------------- members */

	public static function members(): void {
		self::guard();
		if ( ! empty( $_GET['member'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			self::member( (int) $_GET['member'] ); // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$t = new MembersTable();
		$t->prepare_items();
		echo '<div class="wrap bd-admin"><h1>Bidik › Members</h1><form method="get"><input type="hidden" name="page" value="bidik-members">';
		$t->search_box( 'Search members', 'bidik-member' );
		$t->display();
		echo '</form><p class="bd-sub">Export columns: ' . esc_html( implode( ', ', MemberQuery::COLUMNS ) ) . '. The file contains exactly the rows your filters show, not only the current page.</p></div>';
	}

	public static function export(): void {
		self::guard();
		check_admin_referer( 'bidik_export' );
		$rows = MemberQuery::rows( MembersTable::filters() );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="bidik-members-' . gmdate( 'Y-m-d' ) . '.csv"' );
		echo MemberQuery::csv( $rows ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	private static function member( int $uid ): void {
		global $wpdb;
		$u = get_userdata( $uid );
		if ( ! $u ) {
			echo '<div class="wrap"><h1>Member not found</h1></div>';
			return;
		}
		$p    = $wpdb->prefix . 'bidik_';
		$sub  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$p}subscriptions WHERE user_id = %d ORDER BY id DESC LIMIT 1", $uid ), ARRAY_A );
		$lvl  = $sub ? PlanChange::level( (int) $sub['level_id'] ) : null;
		$back = esc_url( add_query_arg( 'page', 'bidik-members', admin_url( 'admin.php' ) ) );
		echo '<div class="wrap bd-admin"><p><a href="' . $back . '">← All members</a></p><h1>' . esc_html( $u->display_name ) . '</h1><p class="bd-sub">' . esc_html( $u->user_email ) . ' · joined ' . esc_html( wp_date( 'j M Y', strtotime( $u->user_registered . ' UTC' ) ) ) . '</p>'; // phpcs:ignore
		echo '<div class="bd-cards">';
		$cell = static fn( string $k, string $v ) => '<div class="bd-card"><p class="bd-card__label">' . esc_html( $k ) . '</p><p class="bd-card__value bd-card__value--sm">' . $v . '</p></div>';
		echo $cell( 'Plan', esc_html( $lvl['name'] ?? 'Free' ) ) . $cell( 'Status', $sub ? MembersTable::badge( $sub['status'] ) : 'Free' ) // phpcs:ignore WordPress.Security.EscapeOutput
			. $cell( 'Per month', $sub && in_array( $sub['status'], Metrics::PAYING, true ) ? esc_html( Metrics::money( (int) round( Metrics::monthly( [ 'status' => 'active', 'interval' => $lvl['interval'], 'price' => (int) round( MembershipSync::price_for( $uid, (int) $sub['level_id'] ) * 100 ) ] ) ) ) ) : '0' )
			. $cell( 'Renews or ends', $sub ? esc_html( self::d( $sub['current_period_end'] ) ) : 'none' );
		echo '</div>';

		// timeline: invoices, emails, billing events and survey answers, newest first
		$tl = [];
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$p}invoices WHERE user_id = %d", $uid ), ARRAY_A ) as $i ) {
			$lines = json_decode( (string) $i['line_items'], true );
			$tl[]  = [ $i['created_at'], 'Invoice', $i['number'] . ' · ' . Metrics::money( (int) $i['amount_cents'] ) . ' · ' . ( 'paid' === $i['status'] ? 'paid' : 'unpaid' ) . ( ! empty( $lines[0]['description'] ) ? ' · ' . $lines[0]['description'] : '' ) ];
		}
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT sent_at, subject FROM {$p}email_log WHERE user_id = %d", $uid ), ARRAY_A ) as $e ) {
			$tl[] = [ $e['sent_at'], 'Email', $e['subject'] ];
		}
		if ( $sub ) {
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT type, created_at FROM {$p}events WHERE payload LIKE %s", '%' . $wpdb->esc_like( '"' . $sub['gateway_subscription_id'] . '"' ) . '%' ), ARRAY_A ) as $ev ) {
				$tl[] = [ $ev['created_at'], 'Billing event', $ev['type'] ];
			}
		}
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$p}cancel_feedback WHERE user_id = %d", $uid ), ARRAY_A ) as $f ) {
			$tl[] = [ $f['created_at'], 'Survey', ( \Bidik\Billing\Leave::REASONS[ $f['reason'] ] ?? $f['reason'] ) . ( $f['comment'] ? ': “' . $f['comment'] . '”' : '' ) . ( $f['offer_shown'] ? ' · offer: ' . $f['offer_shown'] . ( $f['offer_accepted'] ? ' (taken)' : ' (not taken)' ) : '' ) ];
		}
		usort( $tl, static fn( $a, $b ) => strcmp( $b[0], $a[0] ) );
		echo '<div class="bd-box"><h2>Billing timeline</h2>';
		if ( ! $tl ) {
			echo '<p class="bd-sub">Nothing yet.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>When</th><th>What</th><th>Detail</th></tr></thead><tbody>';
			foreach ( array_slice( $tl, 0, 60 ) as [ $when, $kind, $text ] ) {
				echo '<tr><td>' . esc_html( self::d( $when, 'j M Y H:i' ) ) . '</td><td>' . esc_html( $kind ) . '</td><td>' . esc_html( $text ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div><div class="bd-box"><h2>Course progress</h2><table class="widefat striped"><thead><tr><th>Course</th><th>Lessons done</th></tr></thead><tbody>';
		foreach ( Catalog::courses() as $c ) {
			$ids = array_map( static fn( $l ) => $l['post']->ID, Catalog::structure( $c->ID )['lessons'] );
			echo '<tr><td>' . esc_html( get_the_title( $c ) ) . '</td><td>' . count( Progress::done( $uid, $ids ) ) . ' of ' . count( $ids ) . '</td></tr>';
		}
		echo '</tbody></table></div></div>';
	}

	/* -------------------------------------------------------------- emails */

	public static function emails(): void {
		global $wpdb;
		self::guard();
		$log = $wpdb->prefix . 'bidik_email_log';
		echo '<div class="wrap bd-admin"><h1>Bidik › Emails</h1><p class="bd-lead">Every email the site sends is kept here, whether or not the host could deliver it.</p>';
		$view = (int) ( $_GET['view'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $view ) {
			$e = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $log WHERE id = %d", $view ), ARRAY_A );
			if ( $e ) {
				$ctx = json_decode( (string) $e['context'], true );
				echo '<p><a href="' . esc_url( add_query_arg( 'page', 'bidik-emails', admin_url( 'admin.php' ) ) ) . '">← All emails</a></p><div class="bd-box"><p><strong>' . esc_html( $e['subject'] ) . '</strong><br><span class="bd-sub">To ' . esc_html( $e['recipient'] ) . ' · ' . esc_html( self::d( $e['sent_at'], 'j M Y H:i' ) ) . ' · ' . esc_html( $e['template'] ) . '</span></p>'
					. '<iframe class="bd-mail" sandbox title="Email preview" srcdoc="' . esc_attr( (string) ( $ctx['html'] ?? '' ) ) . '"></iframe></div></div>';
				return;
			}
		}
		$rows = (array) $wpdb->get_results( "SELECT id, user_id, template, subject, recipient, sent_at FROM $log ORDER BY id DESC LIMIT 100", ARRAY_A );
		echo '<table class="widefat striped"><thead><tr><th>Sent</th><th>To</th><th>Template</th><th>Subject</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td>' . esc_html( self::d( $r['sent_at'], 'j M Y H:i' ) ) . '</td><td>' . esc_html( $r['recipient'] ) . '</td><td><code>' . esc_html( $r['template'] ) . '</code></td><td>' . esc_html( $r['subject'] ) . '</td><td><a href="' . esc_url( add_query_arg( [ 'page' => 'bidik-emails', 'view' => $r['id'] ], admin_url( 'admin.php' ) ) ) . '">Preview</a></td></tr>';
		}
		echo $rows ? '' : '<tr><td colspan="5">No emails yet.</td></tr>';
		echo '</tbody></table><p class="bd-sub">Showing the latest 100.</p></div>';
	}
}
