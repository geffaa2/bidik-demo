<?php
namespace Bidik\Admin;

use Bidik\Billing\MembershipSync;
use Bidik\Billing\PlanChange;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Reads subscriptions into the plain arrays Metrics and MrrHistory work on, and keeps the daily snapshot. */
final class Data {
	private static function ts( ?string $mysql ): ?int {
		return $mysql ? ( new \DateTimeImmutable( $mysql, new \DateTimeZone( 'UTC' ) ) )->getTimestamp() : null;
	}

	/** @return array<int,array{interval:string,tier:string}> level id => terms */
	private static function levels(): array {
		static $memo = null;
		return $memo ??= ( function () {
			$out = [];
			foreach ( pmpro_getAllLevels( true, false, true ) as $l ) {
				$out[ (int) $l->id ] = [ 'interval' => (string) get_pmpro_membership_level_meta( (int) $l->id, 'bidik_interval', true ) ?: 'month', 'tier' => (string) get_pmpro_membership_level_meta( (int) $l->id, 'bidik_tier', true ) ];
			}
			return $out;
		} )();
	}

	/**
	 * Every subscription as the calculators want it. Price is what that member pays for one interval, in cents.
	 *
	 * @return list<array<string,mixed>>
	 */
	public static function subscriptions(): array {
		global $wpdb;
		$lv   = self::levels();
		$rows = [];
		foreach ( (array) $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}bidik_subscriptions ORDER BY id", ARRAY_A ) as $s ) {
			$l      = $lv[ (int) $s['level_id'] ] ?? [ 'interval' => 'month', 'tier' => '' ];
			$rows[] = [ 'id' => (int) $s['id'], 'user_id' => (int) $s['user_id'], 'status' => (string) $s['status'], 'interval' => $l['interval'], 'tier' => $l['tier'],
				'price' => (int) round( MembershipSync::price_for( (int) $s['user_id'], (int) $s['level_id'] ) * 100 ), 'created' => (int) self::ts( $s['created_at'] ), 'trial_end' => self::ts( $s['trial_end'] ),
				'canceled' => self::ts( $s['canceled_at'] ?? null ), 'churn' => $s['churn_type'] ?? null, 'grace_until' => $s['grace_until'], 'period_end' => $s['current_period_end'] ];
		}
		return $rows;
	}

	/** @return array<string,mixed> */
	public static function overview( ?int $now = null ): array {
		global $wpdb;
		$now   ??= Clock::now();
		$subs    = self::subscriptions();
		$from    = $now - 30 * DAY_IN_SECONDS;
		$trials  = array_filter( $subs, static fn( $s ) => $s['trial_end'] && $s['trial_end'] <= $now && $s['trial_end'] >= $from );
		$paid    = array_map( 'intval', (array) $wpdb->get_col( "SELECT DISTINCT subscription_id FROM {$wpdb->prefix}bidik_invoices WHERE status = 'paid' AND amount_cents > 0" ) );
		$churn   = [ 'voluntary' => 0, 'involuntary' => 0 ];
		foreach ( $subs as $s ) {
			if ( $s['canceled'] && $s['canceled'] >= $from && $s['canceled'] <= $now ) {
				++$churn[ 'involuntary' === $s['churn'] ? 'involuntary' : 'voluntary' ];
			}
		}
		$paying = array_filter( $subs, static fn( $s ) => in_array( $s['status'], Metrics::PAYING, true ) );
		$live   = array_filter( $subs, static fn( $s ) => in_array( $s['status'], [ 'trialing', 'active', 'past_due', 'paused' ], true ) );
		$users  = (int) ( count_users()['avail_roles']['subscriber'] ?? 0 );
		$grace  = array_values( array_filter( $subs, static fn( $s ) => 'past_due' === $s['status'] ) );
		usort( $grace, static fn( $a, $b ) => strcmp( (string) $a['grace_until'], (string) $b['grace_until'] ) );
		return [
			'mrr'        => Metrics::mrr( $subs ),
			'by_tier'    => Metrics::by_tier( $subs ),
			'free'       => max( 0, $users - count( array_unique( array_column( $live, 'user_id' ) ) ) ),
			'trials'     => count( array_filter( $subs, static fn( $s ) => 'trialing' === $s['status'] ) ),
			'conversion' => Metrics::conversion( array_map( static fn( $s ) => in_array( $s['id'], $paid, true ), $trials ) ),
			'trials_done' => count( $trials ),
			'churn'      => $churn + [ 'rate' => Metrics::churn_rate( array_sum( $churn ), count( $paying ) ) ],
			'grace'      => $grace,
		];
	}

	/** One row per day for the chart, from the stored snapshots (the last point is today's live number). @return list<array<string,mixed>> */
	public static function series( int $days = 180, ?int $now = null ): array {
		global $wpdb;
		$now ??= Clock::now();
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_mrr_snapshots WHERE day >= %s ORDER BY day ASC", gmdate( 'Y-m-d', $now - $days * DAY_IN_SECONDS ) ), ARRAY_A );
		return array_map( static fn( $r ) => [ 'day' => $r['day'], 'mrr' => (int) $r['mrr_cents'], 'trials' => (int) $r['trials'], 'active_by_tier' => json_decode( (string) $r['active_by_tier'], true ) ?: [], 'churned_voluntary' => (int) $r['churned_voluntary'], 'churned_involuntary' => (int) $r['churned_involuntary'] ], $rows );
	}

	/** @param array{day:string,mrr:int,trials:int,active_by_tier:array<string,int>,churned_voluntary:int,churned_involuntary:int} $row */
	public static function store( array $row ): void {
		global $wpdb;
		$t    = $wpdb->prefix . 'bidik_mrr_snapshots';
		$data = [ 'mrr_cents' => $row['mrr'], 'active_by_tier' => wp_json_encode( $row['active_by_tier'] ), 'trials' => $row['trials'], 'churned_voluntary' => $row['churned_voluntary'], 'churned_involuntary' => $row['churned_involuntary'] ];
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT day FROM $t WHERE day = %s", $row['day'] ) ) ) {
			$wpdb->update( $t, $data, [ 'day' => $row['day'] ] );
		} else {
			$wpdb->insert( $t, [ 'day' => $row['day'] ] + $data );
		}
	}

	/**
	 * Today's snapshot, taken from the live subscriptions (so it always equals the Overview's figures). Past days are replayed from dates
	 * by MrrHistory, which cannot know when a pause began, so a paused member counts as paying on those days: a small, documented difference.
	 */
	public static function snapshot_today( ?int $now = null ): void {
		global $wpdb;
		$now  ??= Clock::now();
		$subs   = self::subscriptions();
		$day    = gmdate( 'Y-m-d', $now );
		$from   = ( new \DateTimeImmutable( $day . ' 00:00:00', new \DateTimeZone( 'UTC' ) ) )->getTimestamp();
		$churn  = [ 'voluntary' => 0, 'involuntary' => 0 ];
		foreach ( $subs as $s ) {
			if ( $s['canceled'] && $s['canceled'] >= $from && $s['canceled'] <= $now ) {
				++$churn[ 'involuntary' === $s['churn'] ? 'involuntary' : 'voluntary' ];
			}
		}
		self::store( [ 'day' => $day, 'mrr' => Metrics::mrr( $subs ), 'trials' => count( array_filter( $subs, static fn( $s ) => 'trialing' === $s['status'] ) ), 'active_by_tier' => Metrics::by_tier( $subs ),
			'churned_voluntary' => $churn['voluntary'], 'churned_involuntary' => $churn['involuntary'] ] );
	}

	public static function register(): void {
		add_action( 'bidik_daily_snapshot', [ self::class, 'snapshot_today' ] );
		if ( ! wp_next_scheduled( 'bidik_daily_snapshot' ) ) {
			wp_schedule_event( time() + 600, 'daily', 'bidik_daily_snapshot' );
		}
	}
}
