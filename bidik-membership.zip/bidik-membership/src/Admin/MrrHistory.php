<?php
namespace Bidik\Admin;

/**
 * Pure: replays subscriptions day by day, so the chart and the daily snapshot come from one calculation and can be
 * checked against the live numbers. A day is a UTC day and is judged at its last second.
 */
final class MrrHistory {
	/**
	 * @param list<array{created:int,trial_end:?int,canceled:?int,churn:?string,interval:string,price:int,tier:string}> $subs timestamps in UTC
	 * @return list<array{day:string,mrr:int,trials:int,active_by_tier:array<string,int>,churned_voluntary:int,churned_involuntary:int}>
	 */
	public static function series( array $subs, string $from, string $to ): array {
		$out = [];
		$d   = new \DateTimeImmutable( $from . ' 00:00:00', new \DateTimeZone( 'UTC' ) );
		$end = new \DateTimeImmutable( $to . ' 00:00:00', new \DateTimeZone( 'UTC' ) );
		for ( ; $d <= $end; $d = $d->modify( '+1 day' ) ) {
			$start = $d->getTimestamp();
			$last  = $start + 86399;
			$paying = [];
			$trials = 0;
			$vol    = 0;
			$invol  = 0;
			foreach ( $subs as $s ) {
				if ( $s['canceled'] && $s['canceled'] >= $start && $s['canceled'] <= $last ) {
					'involuntary' === $s['churn'] ? ++$invol : ++$vol;
				}
				if ( $s['created'] > $last || ( $s['canceled'] && $s['canceled'] <= $last ) ) {
					continue; // not yet a customer that day, or already gone
				}
				if ( $s['trial_end'] && $last <= $s['trial_end'] ) {
					++$trials;
					continue;
				}
				$paying[] = [ 'status' => 'active', 'interval' => $s['interval'], 'price' => $s['price'], 'tier' => $s['tier'] ];
			}
			$out[] = [ 'day' => $d->format( 'Y-m-d' ), 'mrr' => Metrics::mrr( $paying ), 'trials' => $trials, 'active_by_tier' => Metrics::by_tier( $paying ), 'churned_voluntary' => $vol, 'churned_involuntary' => $invol ];
		}
		return $out;
	}
}
