<?php
namespace Bidik\Import;

/** Pure CSV reader for the importer: BOM, comma/semicolon/tab, quotes with "" and line breaks inside a cell, blank lines skipped. */
final class Csv {
	/** @return array{header:list<string>,rows:list<array{line:int,cells:list<string>}>} line is the 1-based line where the record starts */
	public static function parse( string $text ): array {
		$text = preg_replace( '/^\xEF\xBB\xBF/', '', $text ) ?? $text;
		$first = strtok( $text, "\r\n" ) ?: '';
		$delim = ',';
		foreach ( [ ';', "\t" ] as $d ) {
			if ( substr_count( $first, $d ) > substr_count( $first, $delim ) ) {
				$delim = $d;
			}
		}
		$records = [];
		$cells   = [];
		$cell    = '';
		$quoted  = false;
		$line    = 1;
		$start   = 1;
		$len     = strlen( $text );
		for ( $i = 0; $i < $len; $i++ ) {
			$c = $text[ $i ];
			if ( $quoted ) {
				if ( '"' === $c ) {
					if ( '"' === ( $text[ $i + 1 ] ?? '' ) ) {
						$cell .= '"';
						++$i;
					} else {
						$quoted = false;
					}
				} else {
					$cell .= $c;
					if ( "\n" === $c ) {
						++$line;
					}
				}
				continue;
			}
			if ( '"' === $c && '' === $cell ) {
				$quoted = true;
			} elseif ( $c === $delim ) {
				$cells[] = $cell;
				$cell    = '';
			} elseif ( "\n" === $c || "\r" === $c ) {
				if ( "\r" === $c && "\n" === ( $text[ $i + 1 ] ?? '' ) ) {
					++$i;
				}
				$cells[] = $cell;
				self::push( $records, $cells, $start );
				$cells = [];
				$cell  = '';
				++$line;
				$start = $line;
			} else {
				$cell .= $c;
			}
		}
		if ( '' !== $cell || $cells ) {
			$cells[] = $cell;
			self::push( $records, $cells, $start );
		}
		$header = array_map( static fn( $h ) => trim( $h ), array_shift( $records )['cells'] ?? [] );
		return [ 'header' => $header, 'rows' => $records ];
	}

	/** @param list<array{line:int,cells:list<string>}> $records @param list<string> $cells */
	private static function push( array &$records, array $cells, int $line ): void {
		if ( 1 === count( $cells ) && '' === trim( $cells[0] ) ) {
			return; // blank line
		}
		$records[] = [ 'line' => $line, 'cells' => array_map( static fn( $c ) => trim( $c ), $cells ) ];
	}

	/** One CSV line for the failed-rows report. @param list<string> $cells */
	public static function line( array $cells ): string {
		return implode( ',', array_map( static fn( $c ) => preg_match( '/[",\r\n]/', $c ) ? '"' . str_replace( '"', '""', $c ) . '"' : $c, $cells ) ) . "\n";
	}
}
