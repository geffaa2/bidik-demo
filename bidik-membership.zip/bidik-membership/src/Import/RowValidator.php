<?php
namespace Bidik\Import;

/**
 * Pure: checks one mapped row of the member file. It never touches the database; the caller passes in what exists.
 * A row is valid, a warning (it will import, but something deserves a look) or failed (it will not import).
 */
final class RowValidator {
	public const FIELDS   = [ 'email', 'name', 'level', 'status', 'started_at', 'expires_at', 'stripe_customer_id', 'stripe_subscription_id' ];
	public const STATUSES = [ 'active', 'trialing', 'past_due', 'paused', 'canceled' ];

	/** "Pro", "pro yearly", "Member (monthly)", "member-year" → [tier, interval], or null. @return array{0:string,1:string}|null */
	public static function level( string $raw ): ?array {
		$s = strtolower( trim( $raw ) );
		if ( ! preg_match( '/^(free|member|pro)(?:[\s\-_(]*(monthly|month|yearly|year|annual)\)?)?$/', $s, $m ) ) {
			return null;
		}
		$interval = isset( $m[2] ) && in_array( $m[2], [ 'yearly', 'year', 'annual' ], true ) ? 'year' : 'month';
		return [ $m[1], 'free' === $m[1] ? 'month' : $interval ];
	}

	private static function date( string $raw ): ?int {
		$raw = trim( $raw );
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/', $raw, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			return null;
		}
		return gmmktime( (int) ( $m[4] ?? 0 ), (int) ( $m[5] ?? 0 ), (int) ( $m[6] ?? 0 ), (int) $m[2], (int) $m[3], (int) $m[1] );
	}

	/**
	 * @param array<string,string> $row mapped fields (see FIELDS), missing ones are ''
	 * @param array{line:int,now:int,seen_emails:array<string,int>,seen_subs:array<string,int>,existing_emails:array<string,bool>,existing_subs:array<string,string>} $ctx
	 * @return array{status:string,messages:list<string>,clean:array<string,mixed>}
	 */
	public static function validate( array $row, array $ctx ): array {
		$row   = $row + array_fill_keys( self::FIELDS, '' );
		$fail  = [];
		$warn  = [];
		$email = strtolower( trim( $row['email'] ) );
		if ( '' === $email ) {
			$fail[] = 'missing email';
		} elseif ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			$fail[] = 'invalid email';
		} elseif ( isset( $ctx['seen_emails'][ $email ] ) ) {
			$fail[] = 'duplicate email in this file (first on line ' . $ctx['seen_emails'][ $email ] . ')';
		}
		$lv = self::level( $row['level'] );
		if ( '' === trim( $row['level'] ) ) {
			$fail[] = 'missing level';
		} elseif ( ! $lv ) {
			$fail[] = "unknown level '" . trim( $row['level'] ) . "'";
		}
		$status = '' === trim( $row['status'] ) ? 'active' : strtolower( trim( $row['status'] ) );
		if ( ! in_array( $status, self::STATUSES, true ) ) {
			$fail[] = "unknown status '" . trim( $row['status'] ) . "'";
		}
		$started = '' === trim( $row['started_at'] ) ? $ctx['now'] : self::date( $row['started_at'] );
		if ( '' === trim( $row['started_at'] ) ) {
			$warn[] = 'no started_at: using today';
		} elseif ( null === $started ) {
			$fail[] = 'invalid started_at (use YYYY-MM-DD)';
		}
		$expires = null;
		if ( '' !== trim( $row['expires_at'] ) ) {
			$expires = self::date( $row['expires_at'] );
			if ( null === $expires ) {
				$fail[] = 'invalid expires_at (use YYYY-MM-DD)';
			} elseif ( $started && $expires < $started ) {
				$fail[] = 'expires_at is before started_at';
			}
		}
		$cus = trim( $row['stripe_customer_id'] );
		$sub = trim( $row['stripe_subscription_id'] );
		if ( '' !== $cus && ! preg_match( '/^cus_[A-Za-z0-9]+$/', $cus ) ) {
			$fail[] = 'malformed stripe_customer_id';
		}
		if ( '' !== $sub ) {
			if ( ! preg_match( '/^sub_[A-Za-z0-9]+$/', $sub ) ) {
				$fail[] = 'malformed stripe_subscription_id';
			} elseif ( isset( $ctx['seen_subs'][ $sub ] ) ) {
				$fail[] = 'duplicate stripe_subscription_id in this file (first on line ' . $ctx['seen_subs'][ $sub ] . ')';
			} elseif ( isset( $ctx['existing_subs'][ $sub ] ) && $ctx['existing_subs'][ $sub ] !== $email ) {
				$fail[] = 'stripe_subscription_id already belongs to another member';
			}
		}
		$paid = $lv && 'free' !== $lv[0];
		if ( $paid && '' === $sub && ! $fail ) {
			$warn[] = 'no stripe_subscription_id: a sandbox subscription will be created';
		}
		if ( $lv && 'free' === $lv[0] && 'active' !== $status ) {
			$warn[] = 'status is ignored for Free';
		}
		if ( '' === trim( $row['name'] ) && ! $fail ) {
			$warn[] = 'no name: the email will be used';
		}
		if ( $email && ! $fail && isset( $ctx['existing_emails'][ $email ] ) ) {
			$warn[] = 'member exists: will be updated';
		}
		return [
			'status'   => $fail ? 'failed' : ( $warn ? 'warning' : 'valid' ),
			'messages' => array_merge( $fail, $warn ),
			'clean'    => [ 'email' => $email, 'name' => trim( $row['name'] ), 'tier' => $lv[0] ?? '', 'interval' => $lv[1] ?? 'month', 'status' => $status, 'started' => $started, 'expires' => $expires, 'customer' => $cus, 'subscription' => $sub ],
		];
	}

	/** Guesses which CSV column holds which field. @param list<string> $header @return array<string,?int> field => column index */
	public static function guess( array $header ): array {
		$norm  = array_map( static fn( $h ) => preg_replace( '/[^a-z]/', '', strtolower( $h ) ), $header );
		$alias = [ 'email' => [ 'email', 'emailaddress', 'mail' ], 'name' => [ 'name', 'fullname', 'customername' ], 'level' => [ 'level', 'plan', 'membership', 'tier' ], 'status' => [ 'status', 'state' ],
			'started_at' => [ 'startedat', 'started', 'startdate', 'joined', 'joinedat', 'createdat' ], 'expires_at' => [ 'expiresat', 'expires', 'enddate', 'expirydate', 'renewsat' ],
			'stripe_customer_id' => [ 'stripecustomerid', 'customerid', 'stripecustomer' ], 'stripe_subscription_id' => [ 'stripesubscriptionid', 'subscriptionid', 'stripesubscription' ] ];
		$out = [];
		foreach ( $alias as $field => $names ) {
			$out[ $field ] = null;
			foreach ( $norm as $i => $n ) {
				if ( in_array( $n, $names, true ) ) {
					$out[ $field ] = $i;
					break;
				}
			}
		}
		return $out;
	}
}
