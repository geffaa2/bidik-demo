<?php
namespace Bidik\Import;

defined( 'ABSPATH' ) || exit;

/** Bidik › Import: upload, map the columns, review the dry run, import, and download what failed. */
final class Admin {
	private const LABELS = [ 'email' => 'Email', 'name' => 'Name', 'level' => 'Plan (Free, Member, Pro, optionally monthly or yearly)', 'status' => 'Status (active, trialing, past_due, paused, canceled)', 'started_at' => 'Started on (YYYY-MM-DD)',
		'expires_at' => 'Paid until (YYYY-MM-DD)', 'stripe_customer_id' => 'Stripe customer id (cus_…)', 'stripe_subscription_id' => 'Stripe subscription id (sub_…)' ];

	public static function register(): void {
		foreach ( [ 'upload', 'map', 'start', 'failed', 'sample' ] as $a ) {
			add_action( "admin_post_bidik_import_$a", [ self::class, $a ] );
		}
		Importer::register();
	}

	private static function guard( string $nonce = '' ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'You do not have permission to import members.', 'Not allowed', [ 'response' => 403 ] );
		}
		if ( $nonce ) {
			check_admin_referer( $nonce );
		}
	}

	private static function url( array $args = [] ): string {
		return add_query_arg( [ 'page' => 'bidik-import' ] + $args, admin_url( 'admin.php' ) );
	}

	private static function back( string $msg, array $args = [] ): void {
		wp_safe_redirect( self::url( $args + [ 'notice' => rawurlencode( $msg ) ] ) );
		exit;
	}

	public static function upload(): void {
		self::guard( 'bidik_import' );
		$f = $_FILES['members'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $f || UPLOAD_ERR_OK !== $f['error'] || ! is_uploaded_file( $f['tmp_name'] ) ) {
			self::back( 'Choose a CSV file first.' );
		}
		try {
			$id = Importer::create( (string) $f['name'], (string) file_get_contents( $f['tmp_name'] ) );
		} catch ( \DomainException $e ) {
			self::back( $e->getMessage() );
		}
		wp_safe_redirect( self::url( [ 'import' => $id ] ) );
		exit;
	}

	public static function map(): void {
		self::guard( 'bidik_import' );
		$id     = (int) ( $_POST['import'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		$fields = [];
		foreach ( RowValidator::FIELDS as $f ) {
			$v             = $_POST['col'][ $f ] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification
			$fields[ $f ] = '' === $v ? null : (int) $v;
		}
		try {
			Importer::map( $id, $fields, ! empty( $_POST['welcome'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			Importer::dry_run( $id );
		} catch ( \DomainException $e ) {
			self::back( $e->getMessage(), [ 'import' => $id ] );
		}
		wp_safe_redirect( self::url( [ 'import' => $id, 'step' => 'review' ] ) );
		exit;
	}

	public static function start(): void {
		self::guard( 'bidik_import' );
		$id = (int) ( $_POST['import'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		try {
			Importer::start( $id );
		} catch ( \DomainException $e ) {
			self::back( $e->getMessage(), [ 'import' => $id ] );
		}
		wp_safe_redirect( self::url( [ 'import' => $id, 'step' => 'run' ] ) );
		exit;
	}

	public static function failed(): void {
		self::guard();
		$id = (int) ( $_GET['import'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		check_admin_referer( 'bidik_import_failed_' . $id );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="bidik-import-' . $id . '-failed-rows.csv"' );
		echo Importer::failed_csv( $id ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	public static function sample(): void {
		self::guard();
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="bidik-import-sample.csv"' );
		echo "email,name,level,status,started_at,expires_at,stripe_customer_id,stripe_subscription_id\nrani@example.com,Rani Prameswari,Member,active,2026-05-12,2026-12-12,cus_Aa1,sub_Bb1\nbayu@example.com,Bayu Santoso,Pro yearly,active,2026-01-03,2027-01-03,cus_Aa2,sub_Bb2\ndewi@example.com,Dewi Lestari,Free,,2026-09-01,,,\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	private static function steps( int $on ): string {
		$h = '<ol class="bd-steps">';
		foreach ( [ 'Upload', 'Match columns', 'Review', 'Import' ] as $i => $label ) {
			$h .= '<li' . ( $i + 1 === $on ? ' class="is-on" aria-current="step"' : '' ) . '>' . ( $i + 1 ) . '. ' . esc_html( $label ) . '</li>';
		}
		return $h . '</ol>';
	}

	public static function page(): void {
		self::guard();
		$id   = (int) ( $_GET['import'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		$step = sanitize_key( $_GET['step'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="wrap bd-admin"><h1>Bidik › Import</h1>';
		if ( ! empty( $_GET['notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-error"><p>' . esc_html( rawurldecode( (string) $_GET['notice'] ) ) . '</p></div>'; // phpcs:ignore
		}
		$imp = $id ? Importer::get( $id ) : null;
		if ( ! $imp ) {
			self::upload_form();
		} elseif ( 'run' === $step || in_array( $imp['status'], [ 'running', 'done' ], true ) ) {
			self::run_view( $imp );
		} elseif ( 'review' === $step && 'dryrun' === $imp['status'] ) {
			self::review( $imp );
		} else {
			self::mapping( $imp );
		}
		echo '</div>';
	}

	private static function upload_form(): void {
		echo self::steps( 1 ) . '<div class="bd-box"><p>Bring members over from your old platform. Upload a CSV with one member per row. Members are matched by email, so running a file twice updates people instead of duplicating them. Nothing is written until you have reviewed a dry run.</p>' // phpcs:ignore
			. '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bidik_import_upload">' . wp_nonce_field( 'bidik_import', '_wpnonce', true, false )
			. '<p><label for="bd-file"><strong>CSV file</strong></label><br><input type="file" id="bd-file" name="members" accept=".csv,text/csv" required></p><p><button class="button button-primary" type="submit">Upload and continue</button> '
			. '<a class="button" href="' . esc_url( admin_url( 'admin-post.php?action=bidik_import_sample' ) ) . '">Download a sample file</a></p></form></div>';
	}

	private static function mapping( array $imp ): void {
		global $wpdb;
		$header = $imp['mapping']['header'] ?? [];
		$saved  = $imp['mapping']['fields'] ?? RowValidator::guess( $header );
		$first  = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT data FROM ' . $wpdb->prefix . 'bidik_import_rows WHERE import_id = %d ORDER BY line_no LIMIT 3', $imp['id'] ), ARRAY_A );
		echo self::steps( 2 ) . '<div class="bd-box"><p><strong>' . (int) $imp['total'] . ' rows</strong> found. Tell Bidik which column is which. We guessed from the headings; check them.</p>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bidik_import_map"><input type="hidden" name="import" value="' . (int) $imp['id'] . '">' . wp_nonce_field( 'bidik_import', '_wpnonce', true, false )
			. '<table class="widefat striped bd-form-table"><thead><tr><th>Bidik field</th><th>Column in your file</th><th>First rows</th></tr></thead><tbody>';
		foreach ( self::LABELS as $f => $label ) {
			$req = in_array( $f, [ 'email', 'level' ], true );
			echo '<tr><th scope="row"><label for="bd-col-' . esc_attr( $f ) . '">' . esc_html( $label ) . ( $req ? ' <span class="bd-fail">required</span>' : '' ) . '</label></th><td><select name="col[' . esc_attr( $f ) . ']" id="bd-col-' . esc_attr( $f ) . '"><option value="">Not in my file</option>';
			foreach ( $header as $i => $h ) {
				echo '<option value="' . (int) $i . '"' . selected( $saved[ $f ] ?? null, $i, false ) . '>' . esc_html( $h ) . '</option>';
			}
			echo '</select></td><td class="bd-sub">' . esc_html( implode( ' · ', array_map( static fn( $r ) => (string) ( ( json_decode( $r['data'], true ) ?: [] )[ $saved[ $f ] ?? -1 ] ?? '' ), $first ) ) ) . '</td></tr>';
		}
		echo '</tbody></table><p><label><input type="checkbox" name="welcome" value="1"' . checked( ! empty( $imp['mapping']['welcome'] ), true, false ) . '> Email each new member a link to set their password</label></p>'
			. '<p><button class="button button-primary" type="submit">Check the file (dry run)</button> <a class="button" href="' . esc_url( self::url() ) . '">Start over</a></p></form></div>';
	}

	private static function review( array $imp ): void {
		global $wpdb;
		$c  = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . $wpdb->prefix . 'bidik_import_rows WHERE import_id = %d GROUP BY status', $imp['id'] ), OBJECT_K );
		$n  = static fn( string $s ) => (int) ( $c[ $s ]->n ?? 0 );
		$ok = $n( 'valid' ) + $n( 'warning' );
		echo self::steps( 3 ) . '<div class="bd-kv"><div class="bd-card"><p class="bd-card__label">Ready to import</p><p class="bd-card__value bd-ok">' . $ok . '</p><p class="bd-card__note">' . $n( 'warning' ) . ' with a note</p></div>'
			. '<div class="bd-card"><p class="bd-card__label">Will be skipped</p><p class="bd-card__value ' . ( $n( 'failed' ) ? 'bd-fail' : '' ) . '">' . $n( 'failed' ) . '</p><p class="bd-card__note">See the reasons below</p></div></div>';
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT line_no, data, status, message FROM ' . $wpdb->prefix . 'bidik_import_rows WHERE import_id = %d AND status <> %s ORDER BY (status = %s) DESC, line_no LIMIT 100', $imp['id'], 'valid', 'failed' ), ARRAY_A );
		$ei   = $imp['mapping']['fields']['email'] ?? 0;
		echo '<div class="bd-box"><h2>Rows to look at</h2>';
		if ( ! $rows ) {
			echo '<p class="bd-ok">Every row is clean.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>Line</th><th>Email</th><th>Result</th><th>Why</th></tr></thead><tbody>';
			foreach ( $rows as $r ) {
				echo '<tr><td>' . (int) $r['line_no'] . '</td><td>' . esc_html( (string) ( ( json_decode( $r['data'], true ) ?: [] )[ $ei ] ?? '' ) ) . '</td><td class="' . ( 'failed' === $r['status'] ? 'bd-fail' : 'bd-warn' ) . '">' . ( 'failed' === $r['status'] ? 'Skipped' : 'Note' ) . '</td><td>' . esc_html( $r['message'] ) . '</td></tr>';
			}
			echo '</tbody></table><p class="bd-sub">Showing up to 100. Skipped rows come first.</p>';
		}
		echo '</div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bidik_import_start"><input type="hidden" name="import" value="' . (int) $imp['id'] . '">' . wp_nonce_field( 'bidik_import', '_wpnonce', true, false )
			. '<p><button class="button button-primary" type="submit"' . ( $ok ? '' : ' disabled' ) . '>Import ' . $ok . ' members</button> <a class="button" href="' . esc_url( self::url( [ 'import' => $imp['id'] ] ) ) . '">Change the columns</a>';
		if ( $n( 'failed' ) ) {
			echo ' <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bidik_import_failed&import=' . (int) $imp['id'] ), 'bidik_import_failed_' . (int) $imp['id'] ) ) . '">Download the skipped rows (CSV)</a>';
		}
		echo '</p></form>';
	}

	private static function run_view( array $imp ): void {
		$p = 'running' === $imp['status'] ? Importer::run_batch( (int) $imp['id'], 8.0 ) : Importer::progress( (int) $imp['id'] );
		$imp = Importer::get( (int) $imp['id'] );
		$done = 'done' === $imp['status'];
		if ( ! $done ) {
			echo '<meta http-equiv="refresh" content="1">'; // keeps the import moving while this page is open
		}
		$total = $p['imported'] + $p['failed'] + $p['left'];
		echo self::steps( 4 ) . '<div class="bd-box"><h2>' . ( $done ? 'Import finished' : 'Importing…' ) . '</h2><progress max="' . max( 1, $total ) . '" value="' . ( $p['imported'] + $p['failed'] ) . '" style="width:100%"></progress>'
			. '<p>' . (int) $p['imported'] . ' imported · ' . (int) $p['failed'] . ' not imported · ' . (int) $p['left'] . ' to go</p>';
		if ( $done ) {
			global $wpdb;
			$skipped = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'bidik_import_rows WHERE import_id = %d AND status = %s', $imp['id'], 'failed' ) );
			echo '<p>' . (int) $imp['total'] . ' rows in the file: ' . (int) $p['imported'] . ' imported, ' . $skipped . ' skipped in the dry run, ' . ( $p['failed'] - $skipped ) . ' failed while importing.</p><p>';
			if ( $p['failed'] ) {
				echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bidik_import_failed&import=' . (int) $imp['id'] ), 'bidik_import_failed_' . (int) $imp['id'] ) ) . '">Download the rows that did not import (CSV)</a> ';
			}
			echo '<a class="button button-primary" href="' . esc_url( add_query_arg( 'page', 'bidik-members', admin_url( 'admin.php' ) ) ) . '">See the members</a> <a class="button" href="' . esc_url( self::url() ) . '">Import another file</a></p>';
		}
		echo '</div>';
	}
}
