<?php
namespace Bidik\Import;

use Bidik\Billing\MembershipSync;
use Bidik\Billing\WebhookProcessor;
use Bidik\Mail\Mailer;
use Bidik\Pricing;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * Bring members over from another platform. Upload keeps the file and its rows; mapping says which column is which;
 * the dry run judges every row and writes nothing else; the import then works through the good rows in batches of 50
 * (the page keeps going while it is open, and a cron event covers the case where nobody is watching).
 */
final class Importer {
	public const BATCH = 50;

	private static function t( string $name ): string {
		global $wpdb;
		return $wpdb->prefix . 'bidik_' . $name;
	}

	public static function dir(): string {
		return trailingslashit( wp_upload_dir()['basedir'] ) . 'bidik-imports';
	}

	/** @return array<string,mixed>|null */
	public static function get( int $id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'imports' ) . ' WHERE id = %d', $id ), ARRAY_A );
		if ( $r ) {
			$r['mapping'] = json_decode( (string) $r['mapping'], true ) ?: [];
		}
		return $r ?: null;
	}

	/** Keeps the file, stores its rows as pending, and returns the import id. @throws \DomainException */
	public static function create( string $name, string $text ): int {
		global $wpdb;
		$csv = Csv::parse( $text );
		if ( ! $csv['header'] || ! $csv['rows'] ) {
			throw new \DomainException( 'That file has no rows. It needs a header line and at least one member.' );
		}
		wp_mkdir_p( self::dir() );
		file_put_contents( self::dir() . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		$file = wp_generate_password( 10, false ) . '-' . sanitize_file_name( $name );
		file_put_contents( self::dir() . '/' . $file, $text );
		$wpdb->insert( self::t( 'imports' ), [ 'file' => $file, 'mapping' => wp_json_encode( [ 'header' => $csv['header'] ] ), 'status' => 'uploaded', 'total' => count( $csv['rows'] ), 'created_at' => Clock::mysql() ] );
		$id = (int) $wpdb->insert_id;
		foreach ( array_chunk( $csv['rows'], 250 ) as $chunk ) {
			$vals = [];
			foreach ( $chunk as $r ) {
				$vals[] = $wpdb->prepare( '(%d,%d,%s,%s)', $id, $r['line'], wp_json_encode( $r['cells'] ), 'pending' );
			}
			$wpdb->query( 'INSERT INTO ' . self::t( 'import_rows' ) . ' (import_id,line_no,data,status) VALUES ' . implode( ',', $vals ) );
		}
		return $id;
	}

	/** @param array<string,?int> $fields field => column index @throws \DomainException */
	public static function map( int $id, array $fields, bool $welcome ): void {
		global $wpdb;
		$imp = self::get( $id ) ?? throw new \DomainException( 'Import not found.' );
		foreach ( [ 'email', 'level' ] as $need ) {
			if ( ! isset( $fields[ $need ] ) || null === $fields[ $need ] ) {
				throw new \DomainException( "Choose which column holds the member's $need." );
			}
		}
		$wpdb->update( self::t( 'imports' ), [ 'mapping' => wp_json_encode( [ 'header' => $imp['mapping']['header'], 'fields' => $fields, 'welcome' => $welcome ] ), 'status' => 'mapped' ], [ 'id' => $id ] );
	}

	/** @return array<string,string> the row as field => text, using the saved mapping */
	private static function mapped( array $cells, array $fields ): array {
		$out = [];
		foreach ( RowValidator::FIELDS as $f ) {
			$i       = $fields[ $f ] ?? null;
			$out[ $f ] = null === $i ? '' : (string) ( $cells[ $i ] ?? '' );
		}
		return $out;
	}

	/**
	 * Judges every row. Nothing but the import's own row statuses is written: no users, no subscriptions, no email.
	 *
	 * @return array{valid:int,warning:int,failed:int}
	 */
	public static function dry_run( int $id ): array {
		global $wpdb;
		$imp    = self::get( $id ) ?? throw new \DomainException( 'Import not found.' );
		$fields = $imp['mapping']['fields'] ?? throw new \DomainException( 'Map the columns first.' );
		$rows   = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT line_no, data FROM ' . self::t( 'import_rows' ) . ' WHERE import_id = %d ORDER BY line_no', $id ), ARRAY_A );
		$emails = [];
		$subs   = [];
		$mapped = [];
		foreach ( $rows as $r ) {
			$m                    = self::mapped( json_decode( $r['data'], true ) ?: [], $fields );
			$mapped[ $r['line_no'] ] = $m;
			if ( '' !== trim( $m['email'] ) ) {
				$emails[] = strtolower( trim( $m['email'] ) );
			}
			if ( '' !== trim( $m['stripe_subscription_id'] ) ) {
				$subs[] = trim( $m['stripe_subscription_id'] );
			}
		}
		$existing_emails = [];
		foreach ( array_chunk( array_unique( $emails ), 300 ) as $chunk ) {
			$in = implode( ',', array_map( static fn( $e ) => $wpdb->prepare( '%s', $e ), $chunk ) );
			foreach ( (array) $wpdb->get_col( "SELECT LOWER(user_email) FROM {$wpdb->users} WHERE LOWER(user_email) IN ($in)" ) as $e ) {
				$existing_emails[ $e ] = true;
			}
		}
		$existing_subs = [];
		foreach ( array_chunk( array_unique( $subs ), 300 ) as $chunk ) {
			$in = implode( ',', array_map( static fn( $e ) => $wpdb->prepare( '%s', $e ), $chunk ) );
			foreach ( (array) $wpdb->get_results( "SELECT s.gateway_subscription_id g, LOWER(u.user_email) e FROM " . self::t( 'subscriptions' ) . " s JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE s.gateway_subscription_id IN ($in)", ARRAY_A ) as $x ) {
				$existing_subs[ $x['g'] ] = $x['e'];
			}
		}
		$seen_emails = [];
		$seen_subs   = [];
		$count       = [ 'valid' => 0, 'warning' => 0, 'failed' => 0 ];
		$now         = Clock::now();
		foreach ( $rows as $r ) {
			$line = (int) $r['line_no'];
			$v    = RowValidator::validate( $mapped[ $line ], compact( 'line', 'now', 'seen_emails', 'seen_subs', 'existing_emails', 'existing_subs' ) );
			$e    = $v['clean']['email'];
			if ( '' !== $e && ! isset( $seen_emails[ $e ] ) ) {
				$seen_emails[ $e ] = $line;
			}
			$s = $v['clean']['subscription'];
			if ( '' !== $s && ! isset( $seen_subs[ $s ] ) && 'failed' !== $v['status'] ) {
				$seen_subs[ $s ] = $line;
			}
			++$count[ $v['status'] ];
			$wpdb->update( self::t( 'import_rows' ), [ 'status' => $v['status'], 'message' => mb_substr( implode( '; ', $v['messages'] ), 0, 255 ) ], [ 'import_id' => $id, 'line_no' => $line ] );
		}
		$wpdb->update( self::t( 'imports' ), [ 'status' => 'dryrun', 'ok' => $count['valid'] + $count['warning'], 'failed' => $count['failed'] ], [ 'id' => $id ] );
		return $count;
	}

	public static function start( int $id ): void {
		global $wpdb;
		$imp = self::get( $id );
		if ( ! $imp || ! in_array( $imp['status'], [ 'dryrun', 'running' ], true ) ) {
			throw new \DomainException( 'Run the dry run first.' );
		}
		$wpdb->update( self::t( 'imports' ), [ 'status' => 'running' ], [ 'id' => $id ] );
		wp_schedule_single_event( time() + 30, 'bidik_import_batch', [ $id ] );
	}

	/** @return array{imported:int,failed:int,left:int} */
	public static function progress( int $id ): array {
		global $wpdb;
		$c = $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) n FROM ' . self::t( 'import_rows' ) . ' WHERE import_id = %d GROUP BY status', $id ), OBJECT_K );
		$n = static fn( string $s ) => (int) ( $c[ $s ]->n ?? 0 );
		return [ 'imported' => $n( 'imported' ), 'failed' => $n( 'failed' ) + $n( 'import_failed' ), 'left' => $n( 'valid' ) + $n( 'warning' ) ];
	}

	/** Works through pending good rows, 50 at a time, until the time budget is used. @return array{imported:int,failed:int,left:int} */
	public static function run_batch( int $id, float $budget = 8.0 ): array {
		global $wpdb;
		$imp = self::get( $id );
		if ( ! $imp || 'running' !== $imp['status'] ) {
			return self::progress( $id );
		}
		$fields = $imp['mapping']['fields'];
		$began  = microtime( true );
		// members set their own password, so do not spend a full-strength hash on every row (lowest bcrypt cost; only while importing)
		$cheap = static fn( $options ) => [ 'cost' => 4 ];
		add_filter( 'wp_hash_password_options', $cheap );
		try {
			self::work( $id, $imp, $fields, $began, $budget );
		} finally {
			remove_filter( 'wp_hash_password_options', $cheap );
		}
		$p = self::progress( $id );
		if ( 0 === $p['left'] ) {
			$wpdb->update( self::t( 'imports' ), [ 'status' => 'done', 'ok' => $p['imported'], 'failed' => $p['failed'] ], [ 'id' => $id ] );
		} elseif ( ! wp_next_scheduled( 'bidik_import_batch', [ $id ] ) ) {
			wp_schedule_single_event( time() + 30, 'bidik_import_batch', [ $id ] );
		}
		return $p;
	}

	/** @param array<string,mixed> $imp @param array<string,?int> $fields */
	private static function work( int $id, array $imp, array $fields, float $began, float $budget ): void {
		global $wpdb;
		do {
			$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT line_no, data FROM ' . self::t( 'import_rows' ) . " WHERE import_id = %d AND status IN ('valid','warning') ORDER BY line_no LIMIT %d", $id, self::BATCH ), ARRAY_A );
			foreach ( $rows as $r ) {
				$line  = (int) $r['line_no'];
				$clean = RowValidator::validate( self::mapped( json_decode( $r['data'], true ) ?: [], $fields ), [ 'line' => $line, 'now' => Clock::now(), 'seen_emails' => [], 'seen_subs' => [], 'existing_emails' => [], 'existing_subs' => [] ] )['clean'];
				try {
					$what = self::import_row( $clean, $id, $line, ! empty( $imp['mapping']['welcome'] ) );
					$wpdb->update( self::t( 'import_rows' ), [ 'status' => 'imported', 'message' => $what ], [ 'import_id' => $id, 'line_no' => $line ] );
				} catch ( \Throwable $e ) {
					$wpdb->update( self::t( 'import_rows' ), [ 'status' => 'import_failed', 'message' => mb_substr( $e->getMessage(), 0, 255 ) ], [ 'import_id' => $id, 'line_no' => $line ] );
				}
				if ( microtime( true ) - $began > $budget ) {
					return;
				}
			}
		} while ( $rows );
	}

	/** Creates or updates the member and gives them the plan. @param array<string,mixed> $c clean row @return string "created" or "updated" */
	private static function import_row( array $c, int $import_id, int $line, bool $welcome ): string {
		global $wpdb;
		$user    = get_user_by( 'email', $c['email'] );
		$created = ! $user;
		$parts   = preg_split( '/\s+/', $c['name'] ?: '', 2 ) ?: [ '' ];
		if ( $created ) {
			$base = sanitize_user( strstr( $c['email'], '@', true ), true ) ?: 'member';
			$login = $base;
			for ( $i = 2; username_exists( $login ); $i++ ) {
				$login = $base . $i;
			}
			$uid = wp_insert_user( [ 'user_login' => $login, 'user_pass' => wp_generate_password( 20 ), 'user_email' => $c['email'], 'display_name' => $c['name'] ?: $c['email'], 'first_name' => $parts[0], 'last_name' => $parts[1] ?? '', 'role' => 'subscriber' ] );
			if ( is_wp_error( $uid ) ) {
				throw new \RuntimeException( $uid->get_error_message() );
			}
			$user = get_userdata( $uid );
		} elseif ( $c['name'] ) {
			wp_update_user( [ 'ID' => $user->ID, 'display_name' => $c['name'], 'first_name' => $parts[0], 'last_name' => $parts[1] ?? '' ] );
		}
		update_user_meta( $user->ID, 'bidik_imported', $import_id );
		self::plan( $user->ID, $c, $import_id, $line );
		update_user_meta( $user->ID, 'bidik_member_since', (int) $c['started'] );
		if ( $welcome && $created ) {
			$key = get_password_reset_key( $user );
			if ( ! is_wp_error( $key ) ) {
				Mailer::send( $user, 'import_welcome', 'Your Bidik account is ready', 'Welcome to Bidik', [ 'We moved your membership over from our old site. Choose a password to sign in; your plan and dates came with you.' ], 'Set your password', network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $user->user_login ), 'login' ), [ 'import' => $import_id ] );
			}
		}
		return $created ? 'created' : 'updated';
	}

	private static function plan( int $uid, array $c, int $import_id, int $line ): void {
		global $wpdb;
		if ( 'free' === $c['tier'] ) {
			MembershipSync::set_level( $uid, (int) ( Pricing::levels()['free']['month']['id'] ?? 0 ) );
			return;
		}
		$level = (int) ( Pricing::levels()[ $c['tier'] ][ $c['interval'] ]['id'] ?? 0 );
		if ( ! $level ) {
			throw new \RuntimeException( 'No such plan on this site.' );
		}
		$gsub  = $c['subscription'] ?: "sub_imp_u$uid"; // per member, so the same file imported twice finds the same subscription
		$now   = Clock::now();
		$span  = 'year' === $c['interval'] ? '+1 year' : '+1 month';
		$start = (int) $c['started'];
		if ( $c['expires'] ) {
			$end   = (int) $c['expires'];
			$start = ( new \DateTimeImmutable( '@' . $end ) )->modify( 'year' === $c['interval'] ? '-1 year' : '-1 month' )->getTimestamp();
		} else {
			$end = ( new \DateTimeImmutable( '@' . $start ) )->modify( $span )->getTimestamp();
			while ( $end <= $now && 'canceled' !== $c['status'] ) { // the current period, not the first
				$start = $end;
				$end   = ( new \DateTimeImmutable( '@' . $start ) )->modify( $span )->getTimestamp();
			}
		}
		$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'subscriptions' ) . ' WHERE gateway_subscription_id = %s OR user_id = %d ORDER BY id DESC LIMIT 1', $gsub, $uid ), ARRAY_A );
		if ( $existing && 'canceled' === $existing['status'] ) {
			if ( 'canceled' === $c['status'] ) {
				return; // already imported as gone: nothing to change
			}
			$existing = null; // they are coming back: a new subscription
			$gsub     = $c['subscription'] ? $gsub . '_r' . $import_id : "sub_imp_u{$uid}_r$import_id";
		}
		$id    = "evt_imp_{$import_id}_$line";
		$trial = 'trialing' === $c['status'];
		if ( ! $existing ) {
			WebhookProcessor::handle( 'import', [ 'id' => "{$id}_c", 'type' => 'customer.subscription.created', 'data' => [ 'object' => [ 'id' => $gsub, 'customer' => $c['customer'] ?: "cus_imp_$uid", 'status' => $trial ? 'trialing' : 'active',
				'current_period_start' => $start, 'current_period_end' => $end, 'trial_end' => $trial ? $end : null, 'metadata' => [ 'user_id' => $uid, 'level_id' => $level ] ] ] ] );
		} else {
			$gsub = (string) $existing['gateway_subscription_id'];
			WebhookProcessor::handle( 'import', [ 'id' => "{$id}_u", 'type' => 'customer.subscription.updated', 'data' => [ 'object' => [ 'id' => $gsub, 'metadata' => [ 'level_id' => $level ], 'current_period_start' => $start, 'current_period_end' => $end ] ] ] );
		}
		if ( 'past_due' === $c['status'] ) {
			WebhookProcessor::handle( 'import', [ 'id' => "{$id}_f", 'type' => 'invoice.payment_failed', 'data' => [ 'object' => [ 'id' => "in_imp_{$import_id}_$line", 'subscription' => $gsub, 'amount_due' => 0, 'currency' => 'usd', 'lines' => [] ] ] ] );
		} elseif ( 'paused' === $c['status'] ) {
			WebhookProcessor::handle( 'import', [ 'id' => "{$id}_p", 'type' => 'customer.subscription.updated', 'data' => [ 'object' => [ 'id' => $gsub, 'status' => 'paused', 'pause_until' => $end ] ] ] );
		} elseif ( 'canceled' === $c['status'] ) {
			WebhookProcessor::handle( 'import', [ 'id' => "{$id}_x", 'type' => 'customer.subscription.deleted', 'data' => [ 'object' => [ 'id' => $gsub, 'metadata' => [ 'churn_type' => 'voluntary' ] ] ] ] );
			$wpdb->update( self::t( 'subscriptions' ), [ 'canceled_at' => gmdate( 'Y-m-d H:i:s', min( $now, $c['expires'] ?: $now ) ) ], [ 'gateway_subscription_id' => $gsub ] );
		}
		// moved over from Stripe: the card stays with the customer there. On the sandbox gateway a demo card stands in so renewals can run.
		if ( ! get_user_meta( $uid, 'bidik_card', true ) ) {
			update_user_meta( $uid, 'bidik_card', [ 'brand' => 'Visa', 'last4' => '4242', 'exp' => '12/' . ( (int) gmdate( 'Y' ) + 2 ), 'renews' => true ] );
		}
	}

	/** Every row that did not make it, with the original cells and the reason. */
	public static function failed_csv( int $id ): string {
		global $wpdb;
		$imp  = self::get( $id );
		$out  = Csv::line( array_merge( [ 'line' ], $imp['mapping']['header'] ?? [], [ 'reason' ] ) );
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT line_no, data, message FROM ' . self::t( 'import_rows' ) . " WHERE import_id = %d AND status IN ('failed','import_failed') ORDER BY line_no", $id ), ARRAY_A ) as $r ) {
			$out .= Csv::line( array_merge( [ (string) $r['line_no'] ], json_decode( $r['data'], true ) ?: [], [ (string) $r['message'] ] ) );
		}
		return $out;
	}

	public static function register(): void {
		add_action( 'bidik_import_batch', static fn( $id ) => self::run_batch( (int) $id, 15.0 ) );
	}
}
