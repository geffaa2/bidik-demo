<?php
namespace Bidik\Demo;

use Bidik\Admin\Data;
use Bidik\Billing\Renewals;
use Bidik\Chrome;
use Bidik\Courses\DripJob;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * Everything that only makes sense on a demo site, and so exists only when BIDIK_DEMO is set: the bar with the test cards,
 * the Demo clock (move time forward and the site does what it would really do), "view as" for the made-up people, and a reset.
 * Never set BIDIK_DEMO on a real site: it lets any visitor move time and sign in as the demo accounts.
 */
final class Demo {
	/** persona key => [login, label, where to land] */
	public const PERSONAS = [
		'free'   => [ 'demo-free', 'Free member', 'Dewi', 'overview' ],
		'member' => [ 'demo-member', 'Member', 'Rani', 'overview' ],
		'pro'    => [ 'demo-pro', 'Pro', 'Bayu', 'overview' ],
		'late'   => [ 'demo-late', 'Payment problem', 'Maya', 'billing' ],
		'owner'  => [ 'admin', 'Owner (wp-admin)', '', 'admin' ],
	];

	public static function enabled(): bool {
		return Clock::demo();
	}

	public static function register(): void {
		if ( ! self::enabled() ) {
			return;
		}
		add_action( 'wp_body_open', [ self::class, 'bar' ] );
		add_action( 'wp_enqueue_scripts', [ self::class, 'assets' ], 20 );
		add_action( 'rest_api_init', [ self::class, 'routes' ] );
	}

	public static function assets(): void {
		$dir = dirname( __DIR__, 2 ) . '/assets/';
		wp_enqueue_style( 'bidik-demo', plugins_url( 'assets/demo.css', BIDIK_FILE ), [ 'bidik-site' ], (string) filemtime( $dir . 'demo.css' ) );
		wp_enqueue_script( 'bidik-demo', plugins_url( 'assets/demo.js', BIDIK_FILE ), [], (string) filemtime( $dir . 'demo.js' ), true );
		wp_localize_script( 'bidik-demo', 'bidikDemo', [ 'root' => esc_url_raw( rest_url( 'bidik/v1/demo/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ) ] );
	}

	public static function bar(): void {
		$me    = wp_get_current_user();
		$items = '';
		foreach ( self::PERSONAS as $key => [ $login, $label, $name ] ) {
			$here   = $me->ID && $me->user_login === $login;
			$items .= '<li><button type="button" data-demo-as="' . esc_attr( $key ) . '"' . ( $here ? ' aria-current="true"' : '' ) . '><b>' . esc_html( $label ) . '</b>' . ( $name ? '<span>' . esc_html( $name ) . '</span>' : '' ) . '</button></li>';
		}
		$items = '<li><button type="button" data-demo-as="visitor"' . ( $me->ID ? '' : ' aria-current="true"' ) . '><b>Visitor</b><span>signed out</span></button></li>' . $items;
		echo '<div class="bd-demobar" role="region" aria-label="Demo controls"><p class="bd-demobar__msg">' . Chrome::icon( 'info', 'icon sm' ) // phpcs:ignore WordPress.Security.EscapeOutput
			. '<span><b>Demo school.</b> Everyone, every price and every invoice here is made up. Test card <code>4242 4242 4242 4242</code>; <code>4000 0000 0000 0341</code> works now and fails on renewal.</span></p>'
			. '<div class="bd-demobar__tools"><span class="bd-demobar__date">Demo date <time datetime="' . esc_attr( gmdate( 'Y-m-d', Clock::now() ) ) . '">' . esc_html( wp_date( 'D j M Y', Clock::now() ) ) . '</time></span>'
			. '<button type="button" class="bd-demobar__btn" aria-expanded="false" aria-controls="bd-demo-clock" data-demo-open="clock">' . Chrome::icon( 'clock', 'icon sm' ) . 'Demo clock</button>'
			. '<button type="button" class="bd-demobar__btn" aria-expanded="false" aria-controls="bd-demo-as" data-demo-open="as">' . Chrome::icon( 'user-round', 'icon sm' ) . 'View as</button></div>'
			. '<div class="bd-demopanel" id="bd-demo-clock" hidden><p>Move time forward and the site does what it would really do: renewals are charged, cards fail, grace periods run out, modules open and the emails go out.</p>'
			. '<div class="bd-demopanel__row"><button type="button" data-demo-days="1">+1 day</button><button type="button" data-demo-days="3">+3 days</button><button type="button" data-demo-days="7">+7 days</button><button type="button" data-demo-days="0">Back to today</button></div>'
			. '<p class="bd-demopanel__note" role="status" aria-live="polite"></p></div>'
			. '<div class="bd-demopanel" id="bd-demo-as" hidden><p>Sign in as one of the made-up people, or look at the owner\'s side.</p><ul class="bd-demopanel__list">' . $items . '</ul>' // phpcs:ignore WordPress.Security.EscapeOutput
			. '<div class="bd-demopanel__foot"><button type="button" data-demo-reset>Reset the whole demo</button><span>Puts the clock, the people and the history back as they started. Takes a little while.</span></div></div></div>';
	}

	public static function routes(): void {
		$open = static fn() => self::enabled();
		register_rest_route( 'bidik/v1', '/demo/clock', [ 'methods' => 'POST', 'permission_callback' => $open, 'callback' => static fn( \WP_REST_Request $r ) => self::guard( static fn() => self::move( (int) $r->get_param( 'days' ) ) ) ] );
		register_rest_route( 'bidik/v1', '/demo/login', [ 'methods' => 'POST', 'permission_callback' => $open, 'callback' => static fn( \WP_REST_Request $r ) => self::guard( static fn() => self::login( (string) $r->get_param( 'persona' ) ) ) ] );
		register_rest_route( 'bidik/v1', '/demo/reset', [ 'methods' => 'POST', 'permission_callback' => $open, 'callback' => static fn() => self::guard( static fn() => self::reset() ) ] );
	}

	/** @param callable():mixed $fn */
	private static function guard( callable $fn ) {
		try {
			return $fn();
		} catch ( \DomainException $e ) {
			return new \WP_Error( 'bidik_demo', $e->getMessage(), [ 'status' => 422 ] );
		}
	}

	/**
	 * Moves the demo date forward by 1 to 7 days (0 goes back to today) and runs what would have run by then.
	 *
	 * @return array{date:string,message:string,stats:array<string,int>}
	 */
	public static function move( int $days ): array {
		if ( ! self::enabled() ) {
			throw new \DomainException( 'The demo clock is only available on the demo site.' );
		}
		if ( 0 === $days ) {
			Clock::reset();
			return [ 'date' => wp_date( 'D j M Y', Clock::now() ), 'message' => 'Back to today.', 'stats' => [] ];
		}
		if ( $days < 1 || $days > 7 ) {
			throw new \DomainException( 'Move the clock by 1, 3 or 7 days.' );
		}
		$last = (int) get_option( 'bidik_drip_last_run', Clock::now() - DAY_IN_SECONDS );
		Clock::advance( $days * DAY_IN_SECONDS );
		$s            = Renewals::run();
		$s['modules'] = DripJob::run( Clock::now(), $last );
		update_option( 'bidik_drip_last_run', Clock::now(), false );
		Data::snapshot_today();
		$bits = [];
		foreach ( [ 'renewed' => 'renewals charged', 'failed' => 'payments failed', 'expired' => 'plans ended after the grace period', 'ended' => 'cancellations took effect', 'resumed' => 'pauses ended', 'dunning' => 'payment reminders sent', 'trial_notices' => 'trial warnings sent', 'modules' => 'module emails sent' ] as $k => $label ) {
			if ( ! empty( $s[ $k ] ) ) {
				$bits[] = $s[ $k ] . ' ' . $label;
			}
		}
		return [ 'date' => wp_date( 'D j M Y', Clock::now() ), 'message' => 'Moved to ' . wp_date( 'D j M', Clock::now() ) . ( $bits ? ': ' . implode( ', ', $bits ) . '.' : '. Nothing was due.' ), 'stats' => $s ];
	}

	/** @return array{login:string,url:string}|null only the listed demo accounts, nobody else */
	public static function target( string $persona ): ?array {
		if ( 'visitor' === $persona ) {
			return [ 'login' => '', 'url' => home_url( '/' ) ];
		}
		$p = self::PERSONAS[ $persona ] ?? null;
		if ( ! $p ) {
			return null;
		}
		$url = 'admin' === $p[3] ? admin_url( 'admin.php?page=bidik' ) : \Bidik\Account\Account::url( $p[3] );
		return [ 'login' => $p[0], 'url' => $url ];
	}

	/** @return array{url:string} */
	public static function login( string $persona ): array {
		if ( ! self::enabled() ) {
			throw new \DomainException( 'Signing in as a demo account is only available on the demo site.' );
		}
		$t = self::target( $persona ) ?? throw new \DomainException( 'That is not one of the demo accounts.' );
		if ( '' === $t['login'] ) {
			wp_logout();
			return [ 'url' => $t['url'] ];
		}
		$u = get_user_by( 'login', $t['login'] ) ?: throw new \DomainException( 'That demo account is missing. Reset the demo to bring it back.' );
		wp_set_current_user( $u->ID );
		wp_set_auth_cookie( $u->ID, false );
		return [ 'url' => $t['url'] ];
	}

	/** The clock, the made-up people and the history back to how they started; visitors' sign-ups and imports removed. @return array{ok:bool,message:string,url:string} */
	public static function reset(): array {
		global $wpdb;
		if ( ! self::enabled() ) {
			throw new \DomainException( 'Reset is only available on the demo site.' );
		}
		require_once ABSPATH . 'wp-admin/includes/user.php';
		require_once dirname( __DIR__, 2 ) . '/seed/personas.php';
		require_once dirname( __DIR__, 2 ) . '/seed/history.php';
		wp_set_current_user( 0 );
		Clock::reset();
		$p = $wpdb->prefix . 'bidik_';
		// anyone who is not the owner, a demo persona or part of the seeded history signed up during the demo
		$strays = array_map( 'intval', (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->users} WHERE user_login NOT LIKE 'hist\\_%' AND user_login NOT LIKE 'demo-%' AND ID NOT IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities' AND meta_value LIKE '%administrator%')" ) );
		foreach ( $strays as $id ) {
			foreach ( [ 'subscriptions', 'invoices', 'progress', 'cancel_feedback', 'email_log', 'esp_log', 'drip_notices' ] as $t ) {
				$wpdb->delete( $p . $t, [ 'user_id' => $id ] );
			}
			$wpdb->delete( $wpdb->pmpro_membership_orders, [ 'user_id' => $id ] );
			$wpdb->delete( $wpdb->pmpro_memberships_users, [ 'user_id' => $id ] );
			wp_delete_user( $id );
		}
		$wpdb->query( "DELETE FROM {$p}import_rows" );
		$wpdb->query( "DELETE FROM {$p}imports" );
		$wpdb->query( "DELETE FROM {$p}events WHERE gateway IN ('sandbox','import') AND event_id NOT LIKE 'evt_seed_%'" );
		foreach ( (array) glob( \Bidik\Import\Importer::dir() . '/*.csv' ) as $f ) {
			@unlink( $f );
		}
		delete_option( 'bidik_drip_last_run' );
		delete_option( 'bidik_esp' );
		delete_option( 'bidik_esp_mock_fail' );
		$ids = [];
		foreach ( pmpro_getAllLevels( true, false, true ) as $l ) {
			$ids[ $l->name ] = (int) $l->id;
		}
		bidik_seed_personas( $ids );
		$wpdb->query( "DELETE FROM {$p}email_log WHERE user_id IN (SELECT ID FROM {$wpdb->users} WHERE user_login LIKE 'hist\\_%')" );
		bidik_history_seed( true );
		Data::snapshot_today();
		return [ 'ok' => true, 'message' => 'The demo is back to how it started.', 'url' => home_url( '/' ) ];
	}
}
