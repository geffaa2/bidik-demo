<?php
namespace Bidik\Content;

defined( 'ABSPATH' ) || exit;

/** wp-admin editing: the module list with "opens N days after joining", and the per-post fields. Plain wp-admin controls on purpose. */
final class MetaBoxes {
	public static function register(): void {
		add_action( 'add_meta_boxes', [ self::class, 'boxes' ] );
		add_action( 'save_post', [ self::class, 'save' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', static function ( string $hook ): void {
			$screen = get_current_screen();
			if ( $screen && PostTypes::COURSE === $screen->post_type && in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
				wp_enqueue_script( 'bidik-admin', plugins_url( 'assets/admin.js', BIDIK_FILE ), [], (string) filemtime( dirname( __DIR__, 2 ) . '/assets/admin.js' ), true );
			}
		} );
	}

	public static function boxes(): void {
		add_meta_box( 'bidik_article', 'Access and listing', [ self::class, 'article' ], PostTypes::ARTICLE, 'side' );
		add_meta_box( 'bidik_course', 'Course settings', [ self::class, 'course' ], PostTypes::COURSE, 'normal', 'high' );
		add_meta_box( 'bidik_modules', 'Modules', [ self::class, 'modules' ], PostTypes::COURSE, 'normal', 'high' );
		add_meta_box( 'bidik_lesson', 'Lesson settings', [ self::class, 'lesson' ], PostTypes::LESSON, 'side', 'high' );
	}

	private static function field( string $label, string $html ): void {
		echo '<p><label><strong>' . esc_html( $label ) . '</strong><br>' . $html . '</label></p>'; // $html is built below with escaping
	}

	private static function select( string $name, array $options, string $current ): string {
		$out = '<select name="' . esc_attr( $name ) . '">';
		foreach ( $options as $value => $label ) {
			$out .= '<option value="' . esc_attr( (string) $value ) . '"' . selected( $current, (string) $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		return $out . '</select>';
	}

	private static function input( string $name, string $value, string $type = 'text' ): string {
		return '<input class="widefat" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}

	public static function article( \WP_Post $p ): void {
		wp_nonce_field( 'bidik_meta', 'bidik_meta_nonce' );
		self::field( 'Who can read it', self::select( 'bidik[tier]', [ 'open' => 'Everyone (open)', 'member' => 'Members only' ], (string) PostTypes::meta( $p->ID, 'tier', 'member' ) ) );
		self::field( 'Kind', self::select( 'bidik[kind]', [ 'Article' => 'Article', 'Field guide' => 'Field guide' ], (string) PostTypes::meta( $p->ID, 'kind', 'Article' ) ) );
		self::field( 'Minutes to read', self::input( 'bidik[read]', (string) PostTypes::meta( $p->ID, 'read', '5' ), 'number' ) );
		self::field( 'Summary (shown to everyone, so keep it spoiler-free)', '<textarea class="widefat" rows="3" name="bidik[summary]">' . esc_textarea( (string) PostTypes::meta( $p->ID, 'summary', '' ) ) . '</textarea>' );
		self::field( 'Cover image file (in the plugin, assets/img), used when there is no featured image', self::input( 'bidik[cover]', (string) PostTypes::meta( $p->ID, 'cover', '' ) ) );
	}

	public static function course( \WP_Post $p ): void {
		wp_nonce_field( 'bidik_meta', 'bidik_meta_nonce' );
		self::field( 'Plan that opens this course', self::select( 'bidik[tier]', [ 'member' => 'Member and Pro', 'pro' => 'Pro only' ], (string) PostTypes::meta( $p->ID, 'tier', 'member' ) ) );
		self::field( 'Summary', '<textarea class="widefat" rows="3" name="bidik[summary]">' . esc_textarea( (string) PostTypes::meta( $p->ID, 'summary', '' ) ) . '</textarea>' );
		self::field( 'Cover image file (in the plugin, assets/img)', self::input( 'bidik[cover]', (string) PostTypes::meta( $p->ID, 'cover', '' ) ) );
		self::field( 'Demo video file (in the plugin, assets/video), optional', self::input( 'bidik[video]', (string) PostTypes::meta( $p->ID, 'video', '' ) ) );
	}

	public static function modules( \WP_Post $p ): void {
		$mods = json_decode( (string) PostTypes::meta( $p->ID, 'modules', '[]' ), true );
		$mods = is_array( $mods ) && $mods ? $mods : [ [ 'title' => '', 'days' => 0 ] ];
		echo '<p class="description">Modules open in this order. Each opens the given number of days after the member joined (0 = open straight away). Pro members see every module open.</p>';
		echo '<table class="widefat striped" id="bidik-modules"><thead><tr><th>Module title</th><th style="width:150px">Opens after (days)</th><th style="width:80px"></th></tr></thead><tbody>';
		foreach ( $mods as $m ) {
			self::module_row( (string) ( $m['title'] ?? '' ), (int) ( $m['days'] ?? 0 ) );
		}
		echo '</tbody></table><p><button type="button" class="button" id="bidik-add-module">Add module</button></p>';
		echo '<template id="bidik-module-template">';
		self::module_row( '', 0 );
		echo '</template>';
	}

	private static function module_row( string $title, int $days ): void {
		echo '<tr><td><input class="widefat" type="text" name="bidik_modules[title][]" value="' . esc_attr( $title ) . '"></td>'
			. '<td><input type="number" min="0" name="bidik_modules[days][]" value="' . esc_attr( (string) $days ) . '"></td>'
			. '<td><button type="button" class="button-link-delete bidik-remove-module">Remove</button></td></tr>';
	}

	public static function lesson( \WP_Post $p ): void {
		wp_nonce_field( 'bidik_meta', 'bidik_meta_nonce' );
		$courses = [ 0 => 'Choose a course' ];
		foreach ( get_posts( [ 'post_type' => PostTypes::COURSE, 'numberposts' => -1, 'post_status' => 'any', 'suppress_filters' => true ] ) as $c ) {
			$courses[ $c->ID ] = $c->post_title;
		}
		$course = (int) PostTypes::meta( $p->ID, 'course_id', 0 );
		$mods   = [];
		foreach ( \Bidik\Courses\Catalog::modules( $course ) as $i => $m ) {
			$mods[ $i ] = 'Module ' . ( $i + 1 ) . ': ' . $m['title'];
		}
		self::field( 'Course', self::select( 'bidik[course_id]', $courses, (string) $course ) );
		self::field( 'Module (save the course first to list its modules)', self::select( 'bidik[module]', $mods ?: [ 0 => 'Module 1' ], (string) PostTypes::meta( $p->ID, 'module', 0 ) ) );
		self::field( 'Minutes', self::input( 'bidik[minutes]', (string) PostTypes::meta( $p->ID, 'minutes', '10' ), 'number' ) );
		self::field( 'Open to', self::select( 'bidik[tier]', [ '' => 'Same as the course', 'free' => 'Any Free account (a free lesson)' ], (string) PostTypes::meta( $p->ID, 'tier', '' ) ) );
		$have = (array) json_decode( (string) PostTypes::meta( $p->ID, 'files', '[]' ), true );
		echo '<p><strong>Files</strong></p>';
		foreach ( Downloads::FILES as $key => $f ) {
			echo '<p style="margin:2px 0"><label><input type="checkbox" name="bidik_files[]" value="' . esc_attr( $key ) . '"' . checked( in_array( $key, $have, true ), true, false ) . '> ' . esc_html( $f[0] ) . '</label></p>';
		}
		echo '<p class="description">The lesson notes are the editor above. Use a list for bullet points.</p>';
	}

	public static function save( int $post_id, \WP_Post $post ): void {
		if ( ! PostTypes::is_bidik( $post ) || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id )
			|| ! isset( $_POST['bidik_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bidik_meta_nonce'] ) ), 'bidik_meta' )
			|| ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$in    = isset( $_POST['bidik'] ) && is_array( $_POST['bidik'] ) ? wp_unslash( $_POST['bidik'] ) : [];
		$plain = [ 'tier', 'kind', 'cover', 'video' ];
		foreach ( $plain as $k ) {
			if ( isset( $in[ $k ] ) ) {
				update_post_meta( $post_id, "bidik_$k", sanitize_text_field( $in[ $k ] ) );
			}
		}
		foreach ( [ 'read', 'minutes', 'course_id', 'module' ] as $k ) {
			if ( isset( $in[ $k ] ) ) {
				update_post_meta( $post_id, "bidik_$k", max( 0, (int) $in[ $k ] ) );
			}
		}
		if ( isset( $in['summary'] ) ) {
			update_post_meta( $post_id, 'bidik_summary', sanitize_textarea_field( $in['summary'] ) );
		}
		if ( PostTypes::COURSE === $post->post_type && isset( $_POST['bidik_modules']['title'] ) ) {
			$titles = array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['bidik_modules']['title'] ) );
			$days   = (array) wp_unslash( $_POST['bidik_modules']['days'] ?? [] );
			$mods   = [];
			foreach ( $titles as $i => $t ) {
				if ( '' !== $t ) {
					$mods[] = [ 'title' => $t, 'days' => max( 0, (int) ( $days[ $i ] ?? 0 ) ) ];
				}
			}
			update_post_meta( $post_id, 'bidik_modules', wp_json_encode( $mods ) );
		}
		if ( PostTypes::LESSON === $post->post_type ) {
			$keys = array_values( array_intersect( array_map( 'sanitize_key', (array) wp_unslash( $_POST['bidik_files'] ?? [] ) ), array_keys( Downloads::FILES ) ) );
			update_post_meta( $post_id, 'bidik_files', wp_json_encode( $keys ) );
		}
	}
}
