<?php
namespace Bidik\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Articles, courses and lessons. They are custom post types without taxonomies (PMPro's own queries
 * stay simple) and without REST routes, so there is no second door to the full text.
 */
final class PostTypes {
	public const ARTICLE = 'bidik_article', COURSE = 'bidik_course', LESSON = 'bidik_lesson';
	private const REWRITE_VERSION = '3';

	public static function register(): void {
		$common = [ 'public' => true, 'show_in_rest' => false, 'has_archive' => false, 'exclude_from_search' => true, 'show_in_nav_menus' => false, 'menu_position' => 26 ];
		register_post_type( self::ARTICLE, $common + [
			'labels'    => [ 'name' => 'Articles', 'singular_name' => 'Article', 'add_new_item' => 'Add article', 'edit_item' => 'Edit article' ],
			'rewrite'   => [ 'slug' => 'library', 'with_front' => false ],
			'supports'  => [ 'title', 'editor', 'thumbnail' ],
			'menu_icon' => 'dashicons-media-text',
		] );
		register_post_type( self::COURSE, $common + [
			'labels'    => [ 'name' => 'Courses', 'singular_name' => 'Course', 'add_new_item' => 'Add course', 'edit_item' => 'Edit course' ],
			'rewrite'   => [ 'slug' => 'courses', 'with_front' => false ],
			'supports'  => [ 'title', 'editor', 'thumbnail' ],
			'menu_icon' => 'dashicons-welcome-learn-more',
		] );
		register_post_type( self::LESSON, $common + [
			'labels'    => [ 'name' => 'Lessons', 'singular_name' => 'Lesson', 'add_new_item' => 'Add lesson', 'edit_item' => 'Edit lesson' ],
			'rewrite'   => [ 'slug' => 'lesson', 'with_front' => false ],
			'supports'  => [ 'title', 'editor', 'page-attributes' ],
			'menu_icon' => 'dashicons-video-alt3',
		] );
		Downloads::rewrite();

		// after every other init callback has added its rules (downloads, invoices)
		add_action( 'init', static function (): void {
			if ( get_option( 'bidik_rewrite_version' ) !== self::REWRITE_VERSION ) {
				flush_rewrite_rules( false );
				update_option( 'bidik_rewrite_version', self::REWRITE_VERSION, false );
			}
		}, 99 );
		MetaBoxes::register();
	}

	public static function is_bidik( ?\WP_Post $post ): bool {
		return $post && in_array( $post->post_type, [ self::ARTICLE, self::COURSE, self::LESSON ], true );
	}

	/** @param mixed $default */
	public static function meta( int $post_id, string $key, $default = '' ) {
		$v = get_post_meta( $post_id, "bidik_$key", true );
		return '' === $v || false === $v ? $default : $v;
	}

	private const ALT = [
		'golden-hour-savanna.jpg'    => 'Savanna at golden hour with acacia trees backlit by a low sun',
		'mekong-golden-hour.jpg'     => 'Stormy clouds and a wooden boat on the Mekong at golden hour',
		'milky-way-copper-breaks.jpg' => 'The Milky Way rising over a rocky ridge at night',
		'window-light-portrait.jpg'  => 'A portrait lit by one small window, with deep shadows',
	];

	public static function cover_alt( \WP_Post $post ): string {
		return self::ALT[ basename( (string) self::meta( $post->ID, 'cover', '' ) ) ] ?? '';
	}

	/** Cover image: the featured image if there is one, otherwise a file shipped in the plugin. */
	public static function cover( \WP_Post $post, string $size = 'large' ): string {
		$thumb = get_the_post_thumbnail_url( $post, $size );
		if ( $thumb ) {
			return $thumb;
		}
		$file = (string) self::meta( $post->ID, 'cover', 'golden-hour-savanna.jpg' );
		return plugins_url( 'assets/img/' . basename( $file ), BIDIK_FILE );
	}
}
