<?php
namespace Bidik\Content;

defined( 'ABSPATH' ) || exit;

/** Pure: short-lived, signed download links. A token is only a claim; the download still re-checks access. */
final class Token {
	public static function make( int $user, string $file, int $expires, string $secret ): string {
		$body = rtrim( strtr( base64_encode( "$user|$file|$expires" ), '+/', '-_' ), '=' );
		return $body . '.' . substr( hash_hmac( 'sha256', $body, $secret ), 0, 32 );
	}

	/** @return array{user:int,file:string}|null */
	public static function read( string $token, int $now, string $secret ): ?array {
		[ $body, $sig ] = array_pad( explode( '.', $token, 2 ), 2, '' );
		if ( '' === $body || ! hash_equals( substr( hash_hmac( 'sha256', $body, $secret ), 0, 32 ), $sig ) ) {
			return null;
		}
		$parts = explode( '|', (string) base64_decode( strtr( $body, '-_', '+/' ), true ) );
		if ( 3 !== count( $parts ) || (int) $parts[2] < $now ) {
			return null;
		}
		return [ 'user' => (int) $parts[0], 'file' => $parts[1] ];
	}
}
