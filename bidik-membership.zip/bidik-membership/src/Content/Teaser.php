<?php
namespace Bidik\Content;

defined( 'ABSPATH' ) || exit;

/** Pure: the first N words of an article, as plain paragraphs. Markup is dropped, so nothing hidden can ride along. */
final class Teaser {
	public static function cut( string $html, int $words = 120 ): string {
		$html  = preg_replace( '#</(p|h[1-6]|li|blockquote)>#i', "\n\n", $html ) ?? $html;
		$text  = html_entity_decode( strip_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$out   = [];
		$count = 0;
		foreach ( preg_split( '/\n\s*\n/', trim( $text ) ) ?: [] as $para ) {
			$para = trim( preg_replace( '/\s+/', ' ', $para ) ?? '' );
			if ( '' === $para ) {
				continue;
			}
			$w = explode( ' ', $para );
			if ( $count + count( $w ) > $words ) {
				$keep = array_slice( $w, 0, max( 0, $words - $count ) );
				if ( $keep ) {
					$out[] = rtrim( implode( ' ', $keep ), ',;:—-' ) . '…';
				}
				break;
			}
			$out[]  = $para;
			$count += count( $w );
		}
		return implode( '', array_map( static fn( $p ) => '<p>' . htmlspecialchars( $p, ENT_QUOTES, 'UTF-8' ) . '</p>', $out ) );
	}
}
