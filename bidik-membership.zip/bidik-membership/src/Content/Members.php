<?php
namespace Bidik\Content;

defined( 'ABSPATH' ) || exit;

/** What the current visitor is allowed to see, read from their PMPro level (meta bidik_rank, drip_bypass). */
final class Members {
	/** @return array{user:int,rank:int,bypass:bool,since:int,admin:bool,tier:string} rank: -1 guest, 0 Free, 1 Member, 2 Pro */
	public static function context( ?int $user_id = null ): array {
		$user_id ??= get_current_user_id();
		$guest = [ 'user' => 0, 'rank' => -1, 'bypass' => false, 'since' => time(), 'admin' => false, 'tier' => 'guest' ];
		$u     = $user_id ? get_userdata( $user_id ) : false;
		if ( ! $u ) {
			return $guest;
		}
		if ( user_can( $u, 'manage_options' ) ) {
			return [ 'user' => $user_id, 'rank' => 99, 'bypass' => true, 'since' => 0, 'admin' => true, 'tier' => 'admin' ];
		}
		$rank = 0;
		$bypass = false;
		$tier = 'free';
		foreach ( function_exists( 'pmpro_getMembershipLevelsForUser' ) ? (array) pmpro_getMembershipLevelsForUser( $user_id ) : [] as $level ) {
			$r = (int) get_pmpro_membership_level_meta( (int) $level->id, 'bidik_rank', true );
			if ( $r >= $rank ) {
				$rank = $r;
				$tier = (string) get_pmpro_membership_level_meta( (int) $level->id, 'bidik_tier', true ) ?: 'free';
			}
			$bypass = $bypass || (bool) get_pmpro_membership_level_meta( (int) $level->id, 'drip_bypass', true );
		}
		$since = (int) get_user_meta( $user_id, 'bidik_member_since', true ) ?: ( strtotime( $u->user_registered . ' UTC' ) ?: time() );
		return [ 'user' => $user_id, 'rank' => $rank, 'bypass' => $bypass, 'since' => $since, 'admin' => false, 'tier' => $tier ];
	}
}
