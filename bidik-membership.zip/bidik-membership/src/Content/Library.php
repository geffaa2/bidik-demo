<?php
namespace Bidik\Content;

use Bidik\Chrome;
use Bidik\Courses\Access;

defined( 'ABSPATH' ) || exit;

/** [bidik_library] (the article index) and the single-article page around the gated body. */
final class Library {
	public static function register(): void {
		add_shortcode( 'bidik_library', [ self::class, 'index' ] );
	}

	private static function style(): void {
		wp_enqueue_style( 'bidik-courses', plugins_url( 'assets/courses.css', BIDIK_FILE ), [ 'bidik-site' ], (string) filemtime( dirname( __DIR__, 2 ) . '/assets/courses.css' ) );
	}

	/** @return \WP_Post[] */
	private static function articles(): array {
		return get_posts( [ 'post_type' => PostTypes::ARTICLE, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => [ 'date' => 'DESC', 'ID' => 'DESC' ], 'suppress_filters' => true ] );
	}

	public static function index(): string {
		self::style();
		$all  = self::articles();
		$open = array_filter( $all, static fn( $p ) => 'open' === PostTypes::meta( $p->ID, 'tier', 'member' ) );
		$show = isset( $_GET['show'] ) && 'open' === $_GET['show'] ? 'open' : ( isset( $_GET['show'] ) && 'member' === $_GET['show'] ? 'member' : 'all' ); // phpcs:ignore WordPress.Security.NonceVerification
		$base = (string) get_permalink( get_queried_object_id() );
		$tabs = [ 'all' => 'All ' . count( $all ), 'open' => 'Open ' . count( $open ), 'member' => 'Members ' . ( count( $all ) - count( $open ) ) ];
		$nav  = '';
		foreach ( $tabs as $key => $label ) {
			$nav .= '<a href="' . esc_url( 'all' === $key ? $base : add_query_arg( 'show', $key, $base ) ) . '"' . ( $key === $show ? ' aria-current="true"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		$ctx   = Members::context();
		$cards = '';
		foreach ( $all as $p ) {
			$tier = (string) PostTypes::meta( $p->ID, 'tier', 'member' );
			if ( 'all' !== $show && $tier !== $show ) {
				continue;
			}
			$locked = Access::rank_for_tier( $tier ) > $ctx['rank'] && ! $ctx['admin'];
			$chip   = 'open' === $tier ? '<span class="badge badge-paid">Open</span>' : '<span class="badge ' . ( $locked ? 'badge-neutral' : 'badge-cyan' ) . '">' . ( $locked ? Chrome::icon( 'lock', 'icon sm' ) : '' ) . 'Member</span>';
			$cards .= '<li><a class="art-card" href="' . esc_url( (string) get_permalink( $p ) ) . '">'
				. '<span class="art-card__img"><img src="' . esc_url( PostTypes::cover( $p, 'medium_large' ) ) . '" alt="" loading="lazy" width="1200" height="800"></span>'
				. '<span class="art-card__body"><span class="art-card__meta">' . esc_html( (string) PostTypes::meta( $p->ID, 'kind', 'Article' ) ) . ' · ' . (int) PostTypes::meta( $p->ID, 'read', 5 ) . ' min' . $chip . '</span>'
				. '<h2>' . esc_html( get_the_title( $p ) ) . '</h2><span class="art-card__sum">' . esc_html( (string) PostTypes::meta( $p->ID, 'summary', '' ) ) . '</span></span></a></li>';
		}
		$lead = '<p class="bd-lead">' . count( $open ) . ' articles are open to everyone. The other ' . ( count( $all ) - count( $open ) ) . ' are for members.</p>';
		return $lead . '<div class="bd-lib"><nav class="seg" aria-label="Filter the library">' . $nav . '</nav><ul class="art-grid">' . $cards . '</ul></div>';
	}

	/** @param string $body the already-guarded body (a teaser when locked) */
	public static function article( \WP_Post $p, string $body ): string {
		self::style();
		$decision = Gate::decide( $p );
		$locked   = Access::OPEN !== $decision['state'];
		$library  = (int) get_option( 'bidik_page_library' );
		return '<article class="art"><header class="art-head"><p class="art-kind"><a href="' . esc_url( (string) ( $library ? get_permalink( $library ) : home_url( '/' ) ) ) . '">Library</a>'
			. Chrome::icon( 'chevron-right', 'icon sm' ) . esc_html( (string) PostTypes::meta( $p->ID, 'kind', 'Article' ) ) . ' · ' . (int) PostTypes::meta( $p->ID, 'read', 5 ) . ' min read</p>'
			. '<h1>' . esc_html( get_the_title( $p ) ) . '</h1><p class="art-sum">' . esc_html( (string) PostTypes::meta( $p->ID, 'summary', '' ) ) . '</p></header>'
			. '<figure class="art-cover"><img src="' . esc_url( PostTypes::cover( $p ) ) . '" alt="' . esc_attr( PostTypes::cover_alt( $p ) ) . '" width="1200" height="800"></figure>'
			. '<div class="art-body' . ( $locked ? ' is-cut' : '' ) . '">' . $body . '</div>'
			. ( $locked ? Gate::card( $p, $decision ) : '' ) . '</article>';
	}
}
