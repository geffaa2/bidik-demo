<?php
namespace Bidik\Content;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * Downloadable files live in uploads/bidik-protected under unguessable names and are served only through a
 * signed link that lasts ten minutes. The link is a claim; the download checks the member's level again.
 */
final class Downloads {
	/** key => [file name, what it is, rank needed, mime] */
	public const FILES = [
		'dark-sky-planner'      => [ 'dark-sky-planner.pdf', '1 page', 0, 'application/pdf' ],
		'histogram-cheatsheet'  => [ 'histogram-cheatsheet.pdf', '1 page', 1, 'application/pdf' ],
		'histogram-practice'    => [ 'histogram-practice-files.zip', '3 sample images', 1, 'application/zip' ],
		'window-light-brief'    => [ 'window-light-brief.pdf', '1 page', 1, 'application/pdf' ],
		'bidik-preset-pack'     => [ 'bidik-preset-pack.zip', '24 Lightroom presets', 2, 'application/zip' ],
	];

	public static function rewrite(): void {
		add_rewrite_rule( '^bidik-download/([^/]+)/?$', 'index.php?bidik_dl=$matches[1]', 'top' );
		add_filter( 'query_vars', static fn( array $v ): array => array_merge( $v, [ 'bidik_dl' ] ) );
		add_action( 'template_redirect', [ self::class, 'serve' ] );
	}

	private static function secret(): string {
		return wp_salt( 'auth' ) . 'bidik-download';
	}

	public static function dir(): string {
		return trailingslashit( wp_upload_dir()['basedir'] ) . 'bidik-protected';
	}

	public static function path( string $key ): string {
		$name = self::FILES[ $key ][0] ?? 'missing';
		return self::dir() . '/' . substr( hash_hmac( 'sha256', $key, self::secret() ), 0, 12 ) . '-' . $name;
	}

	public static function url( string $key, int $user_id ): string {
		return home_url( '/bidik-download/' . Token::make( $user_id, $key, Clock::now() + 600, self::secret() ) );
	}

	/** @return array{key:string,name:string,meta:string,rank:int,size:string}|null */
	public static function describe( string $key ): ?array {
		if ( ! isset( self::FILES[ $key ] ) ) {
			return null;
		}
		[ $name, $meta, $rank ] = self::FILES[ $key ];
		$path = self::path( $key );
		$size = is_readable( $path ) ? size_format( (int) filesize( $path ), 0 ) : '';
		return [ 'key' => $key, 'name' => $name, 'meta' => $meta, 'rank' => $rank, 'size' => $size ];
	}

	/** @return array{code:int,path?:string,name?:string,mime?:string} */
	public static function resolve( string $token, int $current_user, ?int $now = null ): array {
		$claim = Token::read( $token, $now ?? Clock::now(), self::secret() );
		if ( ! $claim || ! $current_user || $claim['user'] !== $current_user ) {
			return [ 'code' => 403 ];
		}
		$file = self::FILES[ $claim['file'] ] ?? null;
		if ( ! $file ) {
			return [ 'code' => 404 ];
		}
		$ctx = Members::context( $current_user );
		if ( ! $ctx['admin'] && $ctx['rank'] < $file[2] ) {
			return [ 'code' => 403 ];
		}
		$path = self::path( $claim['file'] );
		return is_readable( $path ) ? [ 'code' => 200, 'path' => $path, 'name' => $file[0], 'mime' => $file[3] ] : [ 'code' => 404 ];
	}

	public static function serve(): void {
		$token = (string) get_query_var( 'bidik_dl' );
		if ( '' === $token ) {
			return;
		}
		$r = self::resolve( $token, get_current_user_id() );
		if ( 200 !== $r['code'] ) {
			wp_die( 403 === $r['code'] ? 'This download link has expired or is not for your plan. Open the lesson again to get a fresh one.' : 'That file is not available.', 'Not available', [ 'response' => $r['code'], 'back_link' => true ] );
		}
		nocache_headers();
		header( 'Content-Type: ' . $r['mime'] );
		header( 'Content-Disposition: attachment; filename="' . $r['name'] . '"' );
		header( 'Content-Length: ' . filesize( $r['path'] ) );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $r['path'] );
		exit;
	}
}
