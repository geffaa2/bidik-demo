<?php
namespace Bidik\Content;

use Bidik\Chrome;
use Bidik\Courses\Access;
use Bidik\Courses\Catalog;
use Bidik\Courses\Drip;
use Bidik\Courses\Views;
use Bidik\Pricing;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * One place that decides who sees what, and the filters that make the decision hold everywhere the text
 * could leak: the page, feeds, excerpts and search. Full text of a locked post is never handed to a filter chain.
 */
final class Gate {
	public static function register(): void {
		add_filter( 'the_content', [ self::class, 'guard' ], 1 );
		add_filter( 'the_content', [ self::class, 'view' ], 20 );
		add_filter( 'get_the_excerpt', [ self::class, 'excerpt' ], 1, 2 );
		add_filter( 'show_admin_bar', static fn( $show ) => $show && current_user_can( 'manage_options' ) ); // members never see the WordPress toolbar
		add_filter( 'body_class', static function ( array $c ): array {
			if ( is_singular( PostTypes::LESSON ) ) {
				$c[] = 'bd-player';
			}
			return $c;
		} );
	}

	public static function required_rank( \WP_Post $p ): int {
		switch ( $p->post_type ) {
			case PostTypes::ARTICLE:
				return Access::rank_for_tier( (string) PostTypes::meta( $p->ID, 'tier', 'member' ) );
			case PostTypes::LESSON:
				return Catalog::lesson_rank( $p );
			default:
				return -1;
		}
	}

	/** When this lesson's module opens for this member (null: it is not dripped). */
	public static function opens_at( \WP_Post $p, array $ctx ): ?int {
		if ( PostTypes::LESSON !== $p->post_type ) {
			return null;
		}
		$mods = Catalog::modules( Catalog::lesson_course( $p ) );
		$days = $mods[ (int) PostTypes::meta( $p->ID, 'module', 0 ) ]['days'] ?? 0;
		return $days > 0 ? Drip::opens_at( $ctx['since'], $days, wp_timezone() ) : null;
	}

	/** @return array{state:string,required:int,opens:?int} */
	public static function decide( \WP_Post $p, ?array $ctx = null, ?int $now = null ): array {
		$ctx      ??= Members::context();
		$now      ??= Clock::now();
		$required = self::required_rank( $p );
		$opens    = self::opens_at( $p, $ctx );
		$state    = $ctx['admin'] ? Access::OPEN : Access::decide( $ctx['rank'], $required, $ctx['bypass'], $opens, $now );
		return [ 'state' => $state, 'required' => $required, 'opens' => $opens ];
	}

	public static function can_view( \WP_Post $p, ?array $ctx = null ): bool {
		return Access::OPEN === self::decide( $p, $ctx )['state'];
	}

	/** Runs first: whatever the context (page, feed, excerpt, search), a post the visitor may not read is cut before any other filter sees it. */
	public static function guard( string $content ): string {
		$p = get_post();
		if ( ! PostTypes::is_bidik( $p ) ) {
			return $content;
		}
		if ( PostTypes::LESSON === $p->post_type ) {
			return ''; // lesson notes are only ever drawn by the player view, after its own check
		}
		if ( PostTypes::ARTICLE === $p->post_type && ! self::can_view( $p ) ) {
			return Teaser::cut( $content );
		}
		return $content;
	}

	/** Runs last, on the single page only: the page chrome around the (already guarded) content. */
	public static function view( string $content ): string {
		$p = get_post();
		if ( ! PostTypes::is_bidik( $p ) || ! is_singular( $p->post_type ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		switch ( $p->post_type ) {
			case PostTypes::ARTICLE:
				return Library::article( $p, $content );
			case PostTypes::COURSE:
				return Views::course( $p );
			default:
				return Views::lesson( $p );
		}
	}

	/** An excerpt of a locked post is its hand-written summary, never a slice of the body. */
	public static function excerpt( string $excerpt, $post = null ): string {
		$post = get_post( $post );
		if ( PostTypes::is_bidik( $post ) && ! self::can_view( $post ) ) {
			return (string) PostTypes::meta( $post->ID, 'summary', '' );
		}
		return $excerpt;
	}

	public static function checkout_url( string $tier ): string {
		$id = Pricing::levels()[ $tier ]['month']['id'] ?? 0;
		return $id ? add_query_arg( 'pmpro_level', $id, (string) get_permalink( (int) get_option( 'pmpro_checkout_page_id' ) ) ) : (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) );
	}

	/** The card that replaces locked content, worded for exactly why it is locked. */
	public static function card( \WP_Post $p, array $decision, ?array $ctx = null ): string {
		$ctx    ??= Members::context();
		$state    = $decision['state'];
		$required = $decision['required'];
		$what     = PostTypes::LESSON === $p->post_type ? 'lesson' : 'article';
		$pricing  = (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) );
		$login    = wp_login_url( (string) get_permalink( $p ) );
		$tier     = [ 0 => 'a Free account', 1 => 'Member', 2 => 'Pro' ][ $required ] ?? 'Member';

		if ( Access::DRIP === $state ) {
			$title = 'This module is not open yet';
			$text  = Drip::opens_label( (int) $decision['opens'], Clock::now(), wp_timezone() ) . '. One new module opens each week, and we email you the day it does.';
			$btns  = '';
		} elseif ( Access::LOGIN === $state ) {
			if ( 0 === $required ) {
				$title = 'Create a free account to watch this lesson';
				$text  = 'Lesson 1 of every course is free. No card needed.';
				$btns  = '<a class="btn btn-primary" href="' . esc_url( self::free_url() ) . '">Join free</a><a class="btn btn-secondary" href="' . esc_url( $login ) . '">Log in</a>';
			} else {
				$title = 'Read the rest as a Member';
				$text  = "This $what is part of $tier. Start a 7-day trial and you are not charged before day 8.";
				$btns  = '<a class="btn btn-primary" href="' . esc_url( self::checkout_url( 'member' ) ) . '">Start 7-day trial</a><a class="btn btn-secondary" href="' . esc_url( $login ) . '">Log in</a>';
			}
		} elseif ( 2 === $required ) {
			$title = 'This ' . $what . ' is for Pro';
			$text  = 'Pro opens Night & Astro, the preset pack and every module from day one. Already a Member? You pay only for the days left in your period.';
			$btns  = '<a class="btn btn-primary" href="' . esc_url( $pricing ) . '">See Pro</a>';
		} else {
			$title = 'Read the rest as a Member';
			$text  = 'Your Free account opens ' . ( PostTypes::LESSON === $p->post_type ? 'lesson 1 of every course' : 'the open articles' ) . '. Member opens the rest, with a 7-day trial.';
			$btns  = '<a class="btn btn-primary" href="' . esc_url( self::checkout_url( 'member' ) ) . '">Start 7-day trial</a><a class="btn btn-secondary" href="' . esc_url( $pricing ) . '">Compare plans</a>';
		}
		return '<aside class="gate-card" aria-labelledby="gate-h">' . Chrome::icon( 'lock' )
			. '<div><h2 id="gate-h">' . esc_html( $title ) . '</h2><p>' . esc_html( $text ) . '</p>' . ( $btns ? '<div class="gate-actions">' . $btns . '</div>' : '' ) . '</div></aside>';
	}

	private static function free_url(): string {
		$id = Pricing::levels()['free']['month']['id'] ?? 0;
		return $id ? add_query_arg( 'pmpro_level', $id, (string) get_permalink( (int) get_option( 'pmpro_checkout_page_id' ) ) ) : wp_registration_url();
	}
}
