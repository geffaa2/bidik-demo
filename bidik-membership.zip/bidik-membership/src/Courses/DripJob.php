<?php
namespace Bidik\Courses;

use Bidik\Content\Members;
use Bidik\Content\PostTypes;
use Bidik\Mail\Mailer;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Daily at 07:00 site time: tell each member about the modules that opened for them since the last run, once. */
final class DripJob {
	private const HOOK = 'bidik_daily_drip';

	public static function register(): void {
		add_action( self::HOOK, [ self::class, 'scheduled' ] );
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			$next = ( new \DateTimeImmutable( 'today 07:00', wp_timezone() ) );
			$next = $next->getTimestamp() <= time() ? $next->modify( '+1 day' ) : $next;
			wp_schedule_event( $next->getTimestamp(), 'daily', self::HOOK );
		}
	}

	public static function scheduled(): void {
		$now  = Clock::now();
		$last = (int) get_option( 'bidik_drip_last_run', $now - DAY_IN_SECONDS );
		self::run( $now, $last );
		update_option( 'bidik_drip_last_run', $now, false );
	}

	/** @return int emails sent (one per member) for modules that opened in ($after, $now] */
	public static function run( int $now, int $after ): int {
		global $wpdb;
		$sent  = 0;
		$tz    = wp_timezone();
		$notes = $wpdb->prefix . 'bidik_drip_notices';
		$users = array_map( 'intval', (array) $wpdb->get_col( "SELECT DISTINCT user_id FROM {$wpdb->pmpro_memberships_users} WHERE status = 'active'" ) );
		foreach ( $users as $uid ) {
			$ctx = Members::context( $uid );
			if ( $ctx['rank'] < 1 || $ctx['bypass'] || $ctx['admin'] ) {
				continue; // Pro has every module open from day one: nothing "opens" for them
			}
			$user   = get_userdata( $uid );
			$opened = [];
			foreach ( Catalog::courses() as $course ) {
				if ( Catalog::course_rank( $course->ID ) > $ctx['rank'] ) {
					continue;
				}
				foreach ( Catalog::structure( $course->ID )['modules'] as $mod ) {
					if ( $mod['days'] < 1 ) {
						continue;
					}
					$opens = Drip::opens_at( $ctx['since'], $mod['days'], $tz );
					if ( $opens <= $after || $opens > $now ) {
						continue;
					}
					// the primary key makes "tell them once" hold even if the job runs twice
					if ( $wpdb->insert( $notes, [ 'user_id' => $uid, 'module_key' => $course->ID . ':' . $mod['index'], 'sent_at' => Clock::mysql( $now ) ] ) ) {
						$opened[] = [ $course, $mod ];
					}
				}
			}
			if ( ! $opened ) {
				continue;
			}
			// one email per member per run, however many modules opened
			$lines = [];
			foreach ( $opened as [ $course, $mod ] ) {
				$lines[] = $course->post_title . ', module ' . ( $mod['index'] + 1 ) . ': ' . $mod['title'] . ' (' . count( $mod['lessons'] ) . ' lessons, ' . Catalog::duration( array_sum( array_column( $mod['lessons'], 'minutes' ) ) ) . ').';
			}
			[ $course, $mod ] = $opened[0];
			$one = 1 === count( $opened );
			Mailer::send( $user, 'module_open', $one ? 'Module ' . ( $mod['index'] + 1 ) . ' is open: ' . $mod['title'] : count( $opened ) . ' new modules are open', $one ? 'Module ' . ( $mod['index'] + 1 ) . ' is open' : count( $opened ) . ' new modules are open',
				$lines, 'Start watching', (string) get_permalink( $mod['lessons'][0]['post'] ), [ 'modules' => array_map( static fn( $o ) => $o[0]->ID . ':' . $o[1]['index'], $opened ) ] );
			++$sent;
		}
		return $sent;
	}
}
