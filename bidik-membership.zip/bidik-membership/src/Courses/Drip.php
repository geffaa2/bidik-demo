<?php
namespace Bidik\Courses;

defined( 'ABSPATH' ) || exit;

/**
 * Pure drip arithmetic (no WordPress): a module opens at the start of the site's day,
 * `unlock_after_days` (+ days the membership was paused) after the member joined.
 */
final class Drip {
	/** Midnight, in the site's time zone, on the day the module opens. */
	public static function opens_at( int $since, int $days, \DateTimeZone $tz, int $paused_days = 0 ): int {
		$joined = ( new \DateTimeImmutable( '@' . $since ) )->setTimezone( $tz )->setTime( 0, 0 );
		return $joined->modify( '+' . max( 0, $days ) + max( 0, $paused_days ) . ' days' )->getTimestamp();
	}

	public static function is_open( int $since, int $days, int $now, \DateTimeZone $tz, int $paused_days = 0 ): bool {
		return $now >= self::opens_at( $since, $days, $tz, $paused_days );
	}

	/**
	 * Which date counts as "joined". The date is kept across upgrades; it restarts only when the member
	 * comes back after more than 30 days without a membership.
	 */
	public static function since_on_return( ?int $current_since, ?int $lapsed_at, int $now ): int {
		if ( ! $current_since ) {
			return $now;
		}
		return ( $lapsed_at && $now - $lapsed_at > 30 * 86400 ) ? $now : $current_since;
	}

	/** A pause stops the drip clock: coming back, the joined date moves forward by the days away. */
	public static function shift_since( int $since, int $paused_at, int $now ): int {
		return $since + max( 0, $now - $paused_at );
	}

	/** "Thu 19 Nov · in 4 days" */
	public static function opens_label( int $opens, int $now, \DateTimeZone $tz ): string {
		$day   = ( new \DateTimeImmutable( '@' . $opens ) )->setTimezone( $tz );
		$today = ( new \DateTimeImmutable( '@' . $now ) )->setTimezone( $tz )->setTime( 0, 0 );
		$left  = (int) round( ( $opens - $today->getTimestamp() ) / 86400 );
		$when  = 1 === $left ? 'tomorrow' : ( $left > 1 ? "in $left days" : 'today' );
		return 'Opens ' . $day->format( 'D j M' ) . ' · ' . $when;
	}
}
