<?php
namespace Bidik\Courses;

use Bidik\Chrome;
use Bidik\Content\Downloads;
use Bidik\Content\Gate;
use Bidik\Content\Members;
use Bidik\Content\PostTypes;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Course index, course overview and the lesson player. */
final class Views {
	public static function register(): void {
		add_shortcode( 'bidik_courses', [ self::class, 'index' ] );
		add_action( 'template_redirect', [ self::class, 'handle' ] );
	}

	private static function style(): void {
		wp_enqueue_style( 'bidik-courses', plugins_url( 'assets/courses.css', BIDIK_FILE ), [ 'bidik-site' ], (string) filemtime( dirname( __DIR__, 2 ) . '/assets/courses.css' ) );
	}

	private static function pad( int $n ): string {
		return str_pad( (string) $n, 2, '0', STR_PAD_LEFT );
	}

	private static function tier_name( int $rank ): string {
		return [ 0 => 'Free', 1 => 'Member', 2 => 'Pro' ][ $rank ] ?? 'Member';
	}

	/** @param array<int,array> $struct @return int[] */
	private static function lesson_ids( array $struct ): array {
		return array_map( static fn( $l ) => $l['post']->ID, $struct['lessons'] );
	}

	/** Records progress and "where I stopped"; the Mark complete form posts back to the lesson's own URL. */
	public static function handle(): void {
		if ( ! is_singular( PostTypes::LESSON ) || ! is_user_logged_in() ) {
			return;
		}
		$p   = get_queried_object();
		$ctx = Members::context();
		if ( ! Gate::can_view( $p, $ctx ) ) {
			return;
		}
		Progress::remember( $ctx['user'], $p->ID );
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! isset( $_POST['bidik_complete'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_bidik_nonce'] ?? '' ) ), 'bidik_complete_' . $p->ID ) ) {
			wp_die( 'That form expired. Go back, reload the lesson and try again.', 'Expired', [ 'response' => 403, 'back_link' => true ] );
		}
		Progress::complete( $ctx['user'], $p->ID );
		$next = self::next_open( $p, $ctx );
		wp_safe_redirect( $next ? (string) get_permalink( $next ) : add_query_arg( 'finished', '1', (string) get_permalink( Catalog::lesson_course( $p ) ) ) );
		exit;
	}

	/** The lesson after this one that the member can open right now. */
	public static function next_open( \WP_Post $lesson, array $ctx ): ?\WP_Post {
		$seen = false;
		foreach ( Catalog::structure( Catalog::lesson_course( $lesson ) )['lessons'] as $l ) {
			if ( $seen && Gate::can_view( $l['post'], $ctx ) ) {
				return $l['post'];
			}
			$seen = $seen || $l['post']->ID === $lesson->ID;
		}
		return null;
	}

	/** First open lesson not yet finished; null when everything open is done. */
	public static function resume( int $course_id, array $ctx ): ?\WP_Post {
		$struct = Catalog::structure( $course_id );
		$done   = Progress::done( $ctx['user'], self::lesson_ids( $struct ) );
		foreach ( $struct['lessons'] as $l ) {
			if ( ! in_array( $l['post']->ID, $done, true ) && Gate::can_view( $l['post'], $ctx ) ) {
				return $l['post'];
			}
		}
		return null;
	}

	/** Earliest module (title, label) that is still shut for this member, or null. */
	public static function next_shut( array $struct, array $ctx, int $now ): ?array {
		if ( $ctx['bypass'] || $ctx['admin'] ) {
			return null;
		}
		foreach ( $struct['modules'] as $m ) {
			if ( $m['days'] > 0 ) {
				$opens = Drip::opens_at( $ctx['since'], $m['days'], wp_timezone() );
				if ( $opens > $now ) {
					return [ 'index' => $m['index'], 'title' => $m['title'], 'opens' => $opens ];
				}
			}
		}
		return null;
	}

	/* ---------------------------------------------------------------- course index */

	public static function index(): string {
		self::style();
		$ctx = Members::context();
		$out = '';
		foreach ( Catalog::courses() as $c ) {
			$s      = Catalog::structure( $c->ID );
			$rank   = Catalog::course_rank( $c->ID );
			$has    = $ctx['admin'] || $ctx['rank'] >= $rank;
			$done   = $has ? count( Progress::done( $ctx['user'], self::lesson_ids( $s ) ) ) : 0;
			$total  = count( $s['lessons'] );
			$badge  = '<span class="badge ' . ( 2 === $rank ? 'badge-amber' : 'badge-cyan' ) . '">' . ( $has ? '' : Chrome::icon( 'lock', 'icon sm' ) ) . esc_html( self::tier_name( $rank ) ) . '</span>';
			$prog   = $has && $done ? '<span class="course-prog" role="group" aria-label="Progress"><span class="bar"><span style="width:' . round( 100 * $done / max( 1, $total ) ) . '%"></span></span>' . $done . ' of ' . $total . ' done</span>' : '';
			$out   .= '<li><a class="course-card" href="' . esc_url( (string) get_permalink( $c ) ) . '"><span class="course-card__img"><img src="' . esc_url( PostTypes::cover( $c, 'medium_large' ) ) . '" alt="' . esc_attr( PostTypes::cover_alt( $c ) ) . '" loading="lazy" width="1200" height="800"></span>'
				. '<span class="course-card__body"><span class="course-card__meta">' . $badge . '</span><h2>' . esc_html( get_the_title( $c ) ) . '</h2>'
				. '<span class="course-card__sum">' . esc_html( (string) PostTypes::meta( $c->ID, 'summary', '' ) ) . '</span>'
				. '<span class="course-card__facts">' . $total . ' lessons · ' . esc_html( Catalog::duration( $s['minutes'] ) ) . ' · ' . count( $s['modules'] ) . ' modules</span>' . $prog . '</span></a></li>';
		}
		return '<p class="bd-lead">Lesson 1 of every course is free with an account. Member opens two courses, Pro opens all three.</p><ul class="course-grid">' . $out . '</ul>';
	}

	/* ---------------------------------------------------------------- course overview */

	public static function course( \WP_Post $c ): string {
		self::style();
		$ctx    = Members::context();
		$now    = Clock::now();
		$s      = Catalog::structure( $c->ID );
		$rank   = Catalog::course_rank( $c->ID );
		$has    = $ctx['admin'] || $ctx['rank'] >= $rank;
		$ids    = self::lesson_ids( $s );
		$done   = $has ? Progress::done( $ctx['user'], $ids ) : [];
		$total  = count( $ids );
		$first  = $s['lessons'][0]['post'] ?? null;
		$resume = $has && $ctx['user'] ? self::resume( $c->ID, $ctx ) : null;
		$list   = (int) get_option( 'bidik_page_courses' );
		$pricing = (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) );

		// the primary action says what happens next for this person
		if ( ! $ctx['user'] ) {
			$cta = '<a class="btn btn-primary lg" href="' . esc_url( Gate::checkout_url( 2 === $rank ? 'pro' : 'member' ) ) . '">' . ( 2 === $rank ? 'Go Pro' : 'Start 7-day trial' ) . '</a>'
				. ( $first ? '<a class="btn btn-secondary lg" href="' . esc_url( (string) get_permalink( $first ) ) . '">Preview lesson 1</a>' : '' );
		} elseif ( ! $has ) {
			$cta = '<a class="btn btn-primary lg" href="' . esc_url( $pricing ) . '">See ' . esc_html( self::tier_name( $rank ) ) . '</a>'
				. ( $first ? '<a class="btn btn-secondary lg" href="' . esc_url( (string) get_permalink( $first ) ) . '">Open lesson 1</a>' : '' );
		} elseif ( $resume ) {
			$n   = 1;
			foreach ( $s['lessons'] as $l ) {
				if ( $l['post']->ID === $resume->ID ) {
					$n = $l['no'];
				}
			}
			$cta = '<a class="btn btn-primary lg" href="' . esc_url( (string) get_permalink( $resume ) ) . '">' . ( $done ? 'Continue' : 'Start' ) . ': lesson ' . $n . Chrome::icon( 'arrow-right', 'icon sm' ) . '</a>';
		} else {
			$cta = $first ? '<a class="btn btn-secondary lg" href="' . esc_url( (string) get_permalink( $first ) ) . '">Review lesson 1</a>' : '';
		}

		$notice = '';
		if ( $has && $ctx['user'] && isset( $_GET['finished'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$shut   = self::next_shut( $s, $ctx, $now );
			$notice = '<p class="co-note" role="status">' . Chrome::icon( 'circle-check' ) . '<span>You have finished everything that is open.'
				. ( $shut ? ' Module ' . ( $shut['index'] + 1 ) . ', ' . esc_html( $shut['title'] ) . ', ' . esc_html( lcfirst( Drip::opens_label( $shut['opens'], $now, wp_timezone() ) ) ) . '. We will email you.' : '' ) . '</span></p>';
		}

		$progress = $has && $ctx['user'] && $total
			? '<div class="co-prog" role="group" aria-label="Course progress"><span class="bar"><span style="width:' . round( 100 * count( $done ) / $total ) . '%"></span></span><span>' . count( $done ) . ' of ' . $total . ' lessons done</span></div>' : '';

		$mods = '';
		foreach ( $s['modules'] as $m ) {
			$opens = $m['days'] > 0 && ! $ctx['bypass'] && ! $ctx['admin'] ? Drip::opens_at( $ctx['since'], $m['days'], wp_timezone() ) : null;
			$shut  = $has && $ctx['user'] && null !== $opens && $opens > $now;
			$state = $shut ? '<span class="co-mod__state is-shut">' . Chrome::icon( 'lock' ) . esc_html( Drip::opens_label( $opens, $now, wp_timezone() ) ) . '</span>'
				: '';
			$rows  = '';
			foreach ( $m['lessons'] as $l ) {
				$p        = $l['post'];
				$d        = Gate::decide( $p, $ctx, $now );
				$isdone   = in_array( $p->ID, $done, true );
				if ( $isdone ) {
					$icon = Chrome::icon( 'circle-check', 'icon sm st ok', 'Completed' );
				} elseif ( Access::OPEN === $d['state'] ) {
					$icon = '<span class="st"></span>';
				} elseif ( Access::DRIP === $d['state'] ) {
					$icon = Chrome::icon( 'lock', 'icon sm st', 'Locked until the module opens' );
				} else {
					$icon = Chrome::icon( 'lock', 'icon sm st', 'Needs ' . self::tier_name( $d['required'] ) );
				}
				$tag   = '<span class="tag">' . ( Access::OPEN !== $d['state'] && Access::DRIP !== $d['state'] && $d['required'] !== $rank ? '<span class="badge badge-cyan">' . esc_html( self::tier_name( $d['required'] ) ) . '</span>' : '' ) . '</span>';
				$rows .= '<li><a class="co-lesson' . ( $isdone ? ' is-done' : '' ) . ( Access::OPEN === $d['state'] ? '' : ' is-shut' ) . '" href="' . esc_url( (string) get_permalink( $p ) ) . '"><span class="no">' . self::pad( $l['no'] ) . '</span>'
					. '<span class="t">' . esc_html( get_the_title( $p ) ) . '</span><span class="min">' . (int) $l['minutes'] . ' min</span>' . $tag . $icon . '</a></li>';
			}
			$mods .= '<section class="co-mod"><header><h2><span>Module ' . ( $m['index'] + 1 ) . '</span>' . esc_html( $m['title'] ) . '</h2>' . $state . '</header><ol>' . $rows . '</ol></section>';
		}

		return '<article class="co"><header class="co-head"><div><p class="co-crumb"><a href="' . esc_url( (string) ( $list ? get_permalink( $list ) : home_url( '/' ) ) ) . '">Courses</a>' . Chrome::icon( 'chevron-right', 'icon sm' ) . '<span class="badge ' . ( 2 === $rank ? 'badge-amber' : 'badge-cyan' ) . '">' . esc_html( self::tier_name( $rank ) ) . '</span></p>'
			. '<h1>' . esc_html( get_the_title( $c ) ) . '</h1><p class="co-sum">' . esc_html( (string) PostTypes::meta( $c->ID, 'summary', '' ) ) . '</p>'
			. '<ul class="co-facts"><li>' . Chrome::icon( 'video' ) . $total . ' lessons</li><li>' . Chrome::icon( 'clock' ) . esc_html( Catalog::duration( $s['minutes'] ) ) . '</li><li>' . Chrome::icon( 'layers' ) . count( $s['modules'] ) . ' modules</li></ul>'
			. $progress . '<div class="co-cta">' . $cta . '</div></div>'
			. '<figure class="co-cover"><img src="' . esc_url( PostTypes::cover( $c ) ) . '" alt="' . esc_attr( PostTypes::cover_alt( $c ) ) . '" width="1200" height="800"></figure></header>'
			. $notice . '<div class="co-mods">' . $mods . '</div></article>';
	}

	/* ---------------------------------------------------------------- lesson player */

	public static function lesson( \WP_Post $p ): string {
		self::style();
		$ctx      = Members::context();
		$now      = Clock::now();
		$course   = get_post( Catalog::lesson_course( $p ) );
		$s        = Catalog::structure( $course->ID );
		$d        = Gate::decide( $p, $ctx, $now );
		$open     = Access::OPEN === $d['state'];
		$ids      = self::lesson_ids( $s );
		$has      = $ctx['admin'] || $ctx['rank'] >= Catalog::course_rank( $course->ID );
		$done     = $ctx['user'] ? Progress::done( $ctx['user'], $ids ) : [];
		$me       = null;
		$prev     = null;
		$next     = null;
		foreach ( $s['lessons'] as $i => $l ) {
			if ( $l['post']->ID === $p->ID ) {
				$me   = $l;
				$prev = $s['lessons'][ $i - 1 ]['post'] ?? null;
				$next = $s['lessons'][ $i + 1 ]['post'] ?? null;
			}
		}
		$mod_index = (int) PostTypes::meta( $p->ID, 'module', 0 );
		$list      = (int) get_option( 'bidik_page_courses' );
		$count     = count( $done );

		// top bar
		$crumbs = '<a href="' . esc_url( (string) ( $list ? get_permalink( $list ) : home_url( '/' ) ) ) . '">Courses</a>' . Chrome::icon( 'chevron-right', 'icon sm' )
			. '<a href="' . esc_url( (string) get_permalink( $course ) ) . '">' . esc_html( get_the_title( $course ) ) . '</a>' . Chrome::icon( 'chevron-right', 'icon sm' ) . '<span>Module ' . ( $mod_index + 1 ) . '</span>';
		$prog   = $has && $ctx['user'] ? '<div class="prog" role="group" aria-label="Course progress"><span class="bar"><span style="width:' . round( 100 * $count / max( 1, count( $ids ) ) ) . '%"></span></span><span>' . $count . ' of ' . count( $ids ) . ' done</span></div>' : '<div class="prog"></div>';
		$who    = $ctx['user'] ? '<a class="btn btn-gr" href="' . esc_url( (string) get_permalink( (int) get_option( 'pmpro_account_page_id' ) ) ) . '">' . Chrome::icon( 'user-round', 'icon sm' ) . '<span class="hide-s">Account</span></a>'
			: '<a class="btn btn-gr" href="' . esc_url( wp_login_url( (string) get_permalink( $p ) ) ) . '">Log in</a>';
		$top    = '<header class="p-top"><a class="brand" href="' . esc_url( home_url( '/' ) ) . '">' . Chrome::BRAND_MARK . '<span class="sr">Bidik home</span></a><nav class="crumbs" aria-label="Breadcrumb">' . $crumbs . '</nav>' . $prog . $who . '</header>';

		// stage
		$poster = PostTypes::cover( $course );
		$video  = (string) PostTypes::meta( $course->ID, 'video', '' );
		if ( $open ) {
			$stage = $video
				? '<video controls preload="metadata" playsinline poster="' . esc_url( $poster ) . '" aria-label="' . esc_attr( get_the_title( $p ) ) . '"><source src="' . esc_url( plugins_url( 'assets/video/' . basename( $video ), BIDIK_FILE ) ) . '" type="video/mp4"></video><span class="stage-note">Demo clip: the real lessons would play here</span>'
				: '<img src="' . esc_url( $poster ) . '" alt="' . esc_attr( PostTypes::cover_alt( $course ) ) . '">';
		} else {
			$stage = '<img class="is-dim" src="' . esc_url( $poster ) . '" alt="">' . '<span class="stage-lock">' . Chrome::icon( 'lock' ) . '<span class="sr">Locked</span></span>';
		}

		// title row and actions
		$label   = 'Lesson ' . self::pad( $me['no'] ?? 1 ) . ' · Module ' . ( $mod_index + 1 );
		$actions = '';
		if ( $prev ) {
			$actions .= '<a class="btn btn-gr" href="' . esc_url( (string) get_permalink( $prev ) ) . '">' . Chrome::icon( 'chevron-left', 'icon sm' ) . 'Previous</a>';
		}
		if ( $open && $ctx['user'] ) {
			$finished = in_array( $p->ID, $done, true );
			if ( $finished ) {
				$actions .= $next ? '<a class="btn btn-primary" href="' . esc_url( (string) get_permalink( $next ) ) . '">Next lesson' . Chrome::icon( 'arrow-right', 'icon sm' ) . '</a>' : '<span class="p-done">' . Chrome::icon( 'circle-check', 'icon sm' ) . 'Completed</span>';
			} else {
				$actions .= '<form method="post" action="' . esc_url( (string) get_permalink( $p ) ) . '"><input type="hidden" name="_bidik_nonce" value="' . esc_attr( wp_create_nonce( 'bidik_complete_' . $p->ID ) ) . '"><input type="hidden" name="bidik_complete" value="1">'
					. '<button class="btn btn-primary" type="submit">' . Chrome::icon( 'check', 'icon sm' ) . ( $next ? 'Mark complete &amp; next' : 'Mark complete' ) . '</button></form>';
			}
		}

		// body
		if ( $open ) {
			$notes = '<article class="notes"><h2>Lesson notes</h2>' . wp_kses_post( wpautop( $p->post_content ) ) . '</article>';
			$files = '';
			foreach ( (array) json_decode( (string) PostTypes::meta( $p->ID, 'files', '[]' ), true ) as $key ) {
				$f = Downloads::describe( (string) $key );
				if ( ! $f ) {
					continue;
				}
				$may    = $ctx['admin'] || $ctx['rank'] >= $f['rank'];
				$files .= '<li>' . Chrome::icon( 'file-down' ) . '<span><b>' . esc_html( $f['name'] ) . '</b><small>' . esc_html( $f['meta'] . ( $f['size'] ? ' · ' . $f['size'] : '' ) ) . '</small></span>'
					. ( $may && $ctx['user'] ? '<a class="btn btn-gr" href="' . esc_url( Downloads::url( $f['key'], $ctx['user'] ) ) . '">Download</a>' : '<span class="badge badge-pro">' . esc_html( self::tier_name( $f['rank'] ) ) . '</span>' ) . '</li>';
			}
			$shut  = self::next_shut( $s, $ctx, $now );
			$after = $shut ? '<p class="next">' . Chrome::icon( 'calendar-clock', 'icon sm' ) . '<span>Module ' . ( $shut['index'] + 1 ) . ', <b>' . esc_html( $shut['title'] ) . '</b>, ' . esc_html( lcfirst( Drip::opens_label( $shut['opens'], $now, wp_timezone() ) ) ) . '. We will email you.</span></p>' : '';
			$aside = ( $files || $after ) ? '<aside class="files" aria-labelledby="dl-h">' . ( $files ? '<h2 id="dl-h">Files</h2><ul>' . $files . '</ul>' : '' ) . $after . '</aside>' : '';
			$body  = '<div class="p-cols">' . $notes . $aside . '</div>';
		} else {
			$body = '<div class="p-gate">' . Gate::card( $p, $d, $ctx ) . '</div>';
		}

		// contact sheet
		$sheet = '';
		foreach ( $s['modules'] as $m ) {
			$opens = $m['days'] > 0 && ! $ctx['bypass'] && ! $ctx['admin'] ? Drip::opens_at( $ctx['since'], $m['days'], wp_timezone() ) : null;
			$lock  = $ctx['user'] && $has && null !== $opens && $opens > $now ? '<p class="unlock">' . Chrome::icon( 'lock', 'icon sm' ) . esc_html( Drip::opens_label( $opens, $now, wp_timezone() ) ) . '</p>' : '';
			$rows  = '';
			foreach ( $m['lessons'] as $l ) {
				$lp   = $l['post'];
				$ld   = Gate::decide( $lp, $ctx, $now );
				$cur  = $lp->ID === $p->ID;
				$cls  = in_array( $lp->ID, $done, true ) ? 'f-done' : ( Access::OPEN === $ld['state'] ? 'f-open' : ( Access::DRIP === $ld['state'] ? 'f-drip' : 'f-pro' ) );
				$st   = 'f-done' === $cls ? Chrome::icon( 'circle-check', 'icon sm st', 'Completed' ) : ( 'f-open' === $cls ? '' : Chrome::icon( 'lock', 'icon sm st', 'f-drip' === $cls ? 'Locked until the module opens' : 'Needs ' . self::tier_name( $ld['required'] ) ) );
				if ( $cur && 'f-open' === $cls ) {
					$st = Chrome::icon( 'play', 'icon sm st', 'Now playing' );
				}
				$badge = 'f-pro' === $cls && $ld['required'] !== Catalog::course_rank( $course->ID ) ? '<span class="badge badge-pro">' . esc_html( self::tier_name( $ld['required'] ) ) . '</span>' : '';
				$rows .= '<li><a class="frame ' . $cls . '"' . ( $cur ? ' aria-current="page"' : '' ) . ' href="' . esc_url( (string) get_permalink( $lp ) ) . '"><span class="no">' . self::pad( $l['no'] ) . '</span><span class="ft">' . esc_html( get_the_title( $lp ) ) . '<small>' . (int) $l['minutes'] . ' min</small></span>' . $badge . $st . '</a></li>';
			}
			$sheet .= '<section class="mod"><h3><span>Module ' . ( $m['index'] + 1 ) . '</span>' . esc_html( $m['title'] ) . '</h3>' . $lock . '<ol class="frames">' . $rows . '</ol></section>';
		}
		$sheet = '<nav class="sheet" aria-label="Course lessons"><div class="sheet-head"><h2>' . esc_html( get_the_title( $course ) ) . '</h2><span>' . count( $ids ) . ' lessons · ' . esc_html( Catalog::duration( $s['minutes'] ) ) . '</span></div>' . $sheet . '</nav>';

		return '<div class="player">' . $top . '<div class="p-grid"><main class="p-main"><div class="stage">' . $stage . '</div><div class="p-body"><div class="p-title"><div><p class="les-no">' . esc_html( $label ) . '</p><h1>' . esc_html( get_the_title( $p ) ) . '</h1></div>'
			. '<div class="p-actions">' . $actions . '</div></div>' . $body . '</div></main>' . $sheet . '</div></div>';
	}
}
