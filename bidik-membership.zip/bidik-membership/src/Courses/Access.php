<?php
namespace Bidik\Courses;

defined( 'ABSPATH' ) || exit;

/**
 * Pure access decision. Ranks: -1 guest, 0 Free account, 1 Member, 2 Pro (the level meta bidik_rank).
 * A required rank of -1 means the content is open to everyone.
 */
final class Access {
	public const OPEN = 'open', LOGIN = 'login', UPGRADE = 'upgrade', DRIP = 'drip';

	public const TIER_RANK = [ 'open' => -1, 'free' => 0, 'member' => 1, 'pro' => 2 ];

	public static function rank_for_tier( string $tier ): int {
		return self::TIER_RANK[ $tier ] ?? 1;
	}

	/** @param ?int $opens when the module opens for this member (null: no drip) */
	public static function decide( int $user_rank, int $required, bool $bypass, ?int $opens, int $now ): string {
		if ( $required < 0 ) {
			return self::OPEN;
		}
		if ( $user_rank < 0 ) {
			return self::LOGIN;
		}
		if ( $user_rank < $required ) {
			return self::UPGRADE;
		}
		if ( ! $bypass && null !== $opens && $now < $opens ) {
			return self::DRIP;
		}
		return self::OPEN;
	}
}
