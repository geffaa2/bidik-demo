<?php
namespace Bidik\Courses;

use Bidik\Content\PostTypes;

defined( 'ABSPATH' ) || exit;

/** Reads courses: modules (course meta) and lessons (posts) in order, with running lesson numbers. */
final class Catalog {
	/** @return list<array{title:string,days:int}> */
	public static function modules( int $course_id ): array {
		$raw = json_decode( (string) PostTypes::meta( $course_id, 'modules', '[]' ), true );
		$out = [];
		foreach ( is_array( $raw ) ? $raw : [] as $m ) {
			$out[] = [ 'title' => (string) ( $m['title'] ?? '' ), 'days' => max( 0, (int) ( $m['days'] ?? 0 ) ) ];
		}
		return $out;
	}

	public static function course_rank( int $course_id ): int {
		return Access::rank_for_tier( (string) PostTypes::meta( $course_id, 'tier', 'member' ) );
	}

	public static function lesson_course( \WP_Post $lesson ): int {
		return (int) PostTypes::meta( $lesson->ID, 'course_id', 0 );
	}

	/** A lesson can open its course's tier to a lower one (lesson 1 is open to any Free account). */
	public static function lesson_rank( \WP_Post $lesson ): int {
		$own = (string) PostTypes::meta( $lesson->ID, 'tier', '' );
		return '' !== $own ? Access::rank_for_tier( $own ) : self::course_rank( self::lesson_course( $lesson ) );
	}

	/**
	 * @return array{modules:list<array{index:int,title:string,days:int,lessons:list<array{post:\WP_Post,no:int,minutes:int}>}>,lessons:list<array{post:\WP_Post,no:int,minutes:int,module:int}>,minutes:int}
	 */
	public static function structure( int $course_id ): array {
		static $memo = [];
		$key = $course_id . ':' . (string) get_post_modified_time( 'U', true, $course_id );
		if ( isset( $memo[ $key ] ) ) {
			return $memo[ $key ];
		}
		$mods  = [];
		foreach ( self::modules( $course_id ) as $i => $m ) {
			$mods[ $i ] = $m + [ 'index' => $i, 'lessons' => [] ];
		}
		$posts = get_posts( [ 'post_type' => PostTypes::LESSON, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => [ 'menu_order' => 'ASC', 'ID' => 'ASC' ],
			'meta_key' => 'bidik_course_id', 'meta_value' => $course_id, 'suppress_filters' => true ] );
		$flat = [];
		$no   = 0;
		$mins = 0;
		foreach ( $posts as $p ) {
			$mi = (int) PostTypes::meta( $p->ID, 'module', 0 );
			if ( ! isset( $mods[ $mi ] ) ) {
				continue;
			}
			$row = [ 'post' => $p, 'no' => ++$no, 'minutes' => (int) PostTypes::meta( $p->ID, 'minutes', 0 ) ];
			$mods[ $mi ]['lessons'][] = $row;
			$flat[] = $row + [ 'module' => $mi ];
			$mins  += $row['minutes'];
		}
		return $memo[ $key ] = [ 'modules' => array_values( array_filter( $mods, static fn( $m ) => $m['lessons'] ) ), 'lessons' => $flat, 'minutes' => $mins ];
	}

	/** @return list<\WP_Post> */
	public static function courses(): array {
		return get_posts( [ 'post_type' => PostTypes::COURSE, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => [ 'menu_order' => 'ASC', 'ID' => 'ASC' ], 'suppress_filters' => true ] );
	}

	public static function duration( int $minutes ): string {
		$h = intdiv( $minutes, 60 );
		$m = $minutes % 60;
		return $h ? ( $m ? sprintf( '%d h %02d m', $h, $m ) : "$h h" ) : "$m m";
	}
}
