<?php
namespace Bidik\Courses;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Which lessons a member has finished, and where they stopped (user meta bidik_last_lesson). */
final class Progress {
	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'bidik_progress';
	}

	/** @return bool true when this call is the one that recorded it */
	public static function complete( int $user_id, int $lesson_id ): bool {
		global $wpdb;
		if ( in_array( $lesson_id, self::done( $user_id, [ $lesson_id ] ), true ) ) {
			return false;
		}
		return (bool) $wpdb->insert( self::table(), [ 'user_id' => $user_id, 'lesson_id' => $lesson_id, 'completed_at' => Clock::mysql() ] );
	}

	/** @param int[] $lesson_ids @return int[] the ones this member finished */
	public static function done( int $user_id, array $lesson_ids ): array {
		global $wpdb;
		$lesson_ids = array_values( array_unique( array_map( 'intval', $lesson_ids ) ) );
		if ( ! $user_id || ! $lesson_ids ) {
			return [];
		}
		$in = implode( ',', $lesson_ids );
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT lesson_id FROM ' . self::table() . " WHERE user_id = %d AND lesson_id IN ($in)", $user_id ) ) );
	}

	public static function remember( int $user_id, int $lesson_id ): void {
		if ( $user_id ) {
			update_user_meta( $user_id, 'bidik_last_lesson', $lesson_id );
		}
	}

	public static function last( int $user_id ): int {
		return (int) get_user_meta( $user_id, 'bidik_last_lesson', true );
	}
}
