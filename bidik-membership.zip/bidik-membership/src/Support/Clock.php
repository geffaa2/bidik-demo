<?php
namespace Bidik\Support;

defined( 'ABSPATH' ) || exit;

/**
 * The only source of "now" for Bidik code. In demo mode an offset (set by the Demo clock panel)
 * moves time forward, so renewals, drip and dunning can be shown in a few clicks.
 */
final class Clock {
	private const OPTION = 'bidik_demo_offset_seconds';

	public static function now(): int {
		return time() + self::offset();
	}

	public static function offset(): int {
		return self::demo() ? (int) get_option( self::OPTION, 0 ) : 0;
	}

	public static function demo(): bool {
		return defined( 'BIDIK_DEMO' ) && BIDIK_DEMO;
	}

	public static function advance( int $seconds ): int {
		if ( ! self::demo() ) {
			throw new \LogicException( 'The demo clock only moves when BIDIK_DEMO is set.' );
		}
		update_option( self::OPTION, self::offset() + max( 0, $seconds ), false );
		return self::now();
	}

	public static function reset(): void {
		delete_option( self::OPTION );
	}

	public static function mysql( ?int $ts = null ): string {
		return gmdate( 'Y-m-d H:i:s', $ts ?? self::now() );
	}
}
