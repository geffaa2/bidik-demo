<?php
namespace Bidik\Mail;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Branded transactional email. Every message is written to email_log so the demo can show it, whether or not the host can send mail. */
final class Mailer {
	/**
	 * @param array<string,mixed> $sub subscription row (after the event)
	 * @param array<string,mixed> $obj event object
	 * @param ?array{0:string,1:string} $transition status change this event caused, if any
	 */
	public static function for_event( string $type, array $sub, array $obj, ?array $transition = null ): void {
		$user = get_userdata( (int) $sub['user_id'] );
		if ( ! $user ) {
			return;
		}
		if ( 'customer.subscription.created' === $type ) {
			self::welcome( $user, $sub );
		} elseif ( 'invoice.paid' === $type && (int) ( $obj['amount_paid'] ?? 0 ) > 0 ) {
			self::receipt( $user, $sub, $obj );
		}
		if ( ! $transition ) {
			return;
		}
		[ $from, $to ] = $transition;
		if ( 'past_due' === $to && 'invoice.payment_failed' === $type ) {
			self::dunning( $user, $sub, 0, (int) ( $obj['amount_due'] ?? 0 ) );
		} elseif ( 'past_due' === $from && 'active' === $to ) {
			self::recovered( $user, $sub, $obj );
		} elseif ( 'canceled' === $to ) {
			self::ended( $user, $sub );
		} elseif ( 'paused' === $to ) {
			self::paused( $user, $sub );
		} elseif ( 'paused' === $from && 'active' === $to ) {
			self::resumed( $user, $sub, $obj );
		}
	}

	private static function plan( array $sub ): string {
		$l = \Bidik\Billing\PlanChange::level( (int) $sub['level_id'] );
		return $l ? $l['name'] : 'your plan';
	}

	private static function money( int $cents ): string {
		return '$' . number_format( $cents / 100, 2 );
	}

	private static function account( string $view = 'billing' ): string {
		return \Bidik\Account\Account::url( $view );
	}

	/** Day 0, 3 and 6 of the grace period. Day 0 is sent when the payment fails; the renewal job sends the others. */
	public static function dunning( \WP_User $user, array $sub, int $day, int $amount_cents = 0 ): void {
		$n    = array_search( $day, \Bidik\Billing\Renewal::DUNNING_DAYS, true ) + 1;
		$left = max( 0, (int) ceil( ( strtotime( $sub['grace_until'] . ' UTC' ) - Clock::now() ) / DAY_IN_SECONDS ) );
		$card = \Bidik\Billing\Cards::get( (int) $sub['user_id'] );
		$by   = self::date( $sub['grace_until'] );
		$plan = self::plan( $sub );
		$amt  = $amount_cents ? self::money( $amount_cents ) : 'your payment';
		$sets = [
			1 => [ "Your payment didn't go through", [ "We couldn't charge $amt" . ( $card ? ' to ' . $card['brand'] . ' ending ' . $card['last4'] : '' ) . '.', "$plan stays open until $by. Update your card before then and nothing changes for you." ] ],
			2 => [ "Reminder: update your card to keep $plan", [ "Your $plan access ends on $by, in $left " . ( 1 === $left ? 'day' : 'days' ) . '.', 'It takes a minute: add a card and we collect the payment straight away.' ] ],
			3 => [ "Last day soon: $plan ends on $by", [ "This is the last reminder. After $by you move to Free and your plan is canceled.", 'Your progress is kept, and you can rejoin any time.' ] ],
		][ $n ];
		self::send( $user, "dunning_$n", $sets[0], $sets[0], $sets[1], 'Update card', self::account(), [ 'subscription_id' => (int) $sub['id'], 'day' => $day ] );
	}

	private static function recovered( \WP_User $user, array $sub, array $obj ): void {
		self::send( $user, 'recovered', "You're all set: payment received", "You're all set", [ 'We charged ' . self::money( (int) ( $obj['amount_paid'] ?? 0 ) ) . '. ' . self::plan( $sub ) . ' continues as normal.', 'Thanks for updating your card.' ], 'Open your account', self::account( 'overview' ), [ 'subscription_id' => (int) $sub['id'] ] );
	}

	private static function ended( \WP_User $user, array $sub ): void {
		$involuntary = 'involuntary' === ( $sub['churn_type'] ?? '' );
		self::send( $user, 'ended', $involuntary ? "Your membership ended because we couldn't take payment" : 'Your membership has ended', $involuntary ? 'Your membership has ended' : 'Sorry to see you go',
			[ "You are on Free now. Your progress in every course is saved." . ( $involuntary ? ' The last payment did not go through, so we closed the plan.' : '' ), 'Rejoin any time and pick up where you stopped.' ], 'See plans', (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) ), [ 'subscription_id' => (int) $sub['id'], 'churn_type' => $sub['churn_type'] ?? '' ] );
	}

	private static function paused( \WP_User $user, array $sub ): void {
		self::send( $user, 'paused', 'Your membership is paused', 'Your membership is paused', [ 'Billing is stopped until ' . self::date( $sub['pause_until'] ) . '. You are on Free in the meantime.', 'Your progress is kept, and the weekly schedule waits for you.' ], 'Resume now', self::account(), [ 'subscription_id' => (int) $sub['id'] ] );
	}

	private static function resumed( \WP_User $user, array $sub, array $obj ): void {
		$paid = (int) ( $obj['amount_paid'] ?? 0 );
		self::send( $user, 'resumed', 'Welcome back', 'Welcome back', [ self::plan( $sub ) . ' is open again.' . ( $paid ? ' We charged ' . self::money( $paid ) . '.' : '' ), 'Your next payment is on ' . self::date( $sub['current_period_end'] ) . '.' ], 'Keep learning', (string) get_permalink( (int) get_option( 'bidik_page_courses' ) ), [ 'subscription_id' => (int) $sub['id'] ] );
	}

	public static function cancel_scheduled( \WP_User $user, array $sub ): void {
		self::send( $user, 'cancel_scheduled', 'Your cancellation is scheduled', 'Your cancellation is scheduled', [ 'You keep ' . self::plan( $sub ) . ' until ' . self::date( $sub['current_period_end'] ) . '. After that you move to Free and are not charged again.', 'Changed your mind? Resume from Billing before then.' ], 'Resume membership', self::account(), [ 'subscription_id' => (int) $sub['id'] ] );
	}

	public static function trial_ending( \WP_User $user, array $sub ): void {
		$price = '$' . number_format( \Bidik\Billing\MembershipSync::price_for( (int) $sub['user_id'], (int) $sub['level_id'] ), 2 );
		self::send( $user, 'trial_ending', 'Your trial ends in 2 days', 'Your trial ends in 2 days', [ 'The first charge is ' . $price . ' on ' . self::date( $sub['trial_end'] ) . '.', 'Cancel before then and you pay nothing.' ], 'Manage billing', self::account(), [ 'subscription_id' => (int) $sub['id'] ] );
	}

	private static function date( ?string $mysql ): string {
		return $mysql ? ( new \DateTimeImmutable( $mysql, new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( 'D j M Y' ) : '';
	}

	private static function welcome( \WP_User $user, array $sub ): void {
		$level = pmpro_getLevel( (int) $sub['level_id'] );
		$first = $user->first_name ?: $user->display_name;
		$price = '$' . number_format( \Bidik\Billing\MembershipSync::price_for( (int) $sub['user_id'], (int) $sub['level_id'] ), 2 );
		$lines = 'trialing' === $sub['status']
			? [ 'Your 7-day trial of ' . $level->name . ' is running until ' . self::date( $sub['trial_end'] ) . '. You are not charged before then.',
				'The first charge is ' . $price . ' on ' . self::date( $sub['trial_end'] ) . '. Cancel from your account before then and you pay nothing.' ]
			: [ 'Your ' . $level->name . ' membership is active and renews on ' . self::date( $sub['current_period_end'] ) . '.' ];
		self::send( $user, 'welcome', 'Welcome to Bidik, ' . $first, 'Welcome, ' . $first, $lines, 'Open your account', get_permalink( (int) get_option( 'pmpro_account_page_id' ) ), [ 'subscription_id' => (int) $sub['id'] ] );
	}

	private static function receipt( \WP_User $user, array $sub, array $obj ): void {
		global $wpdb;
		$number = (string) $wpdb->get_var( $wpdb->prepare( "SELECT number FROM {$wpdb->prefix}bidik_invoices WHERE gateway_invoice_id = %s", (string) $obj['id'] ) );
		$amount = '$' . number_format( (int) $obj['amount_paid'] / 100, 2 );
		self::send( $user, 'receipt', "Receipt $number from Bidik", "Payment received: $amount",
			[ "Thanks. We charged $amount for " . ( $obj['lines'][0]['description'] ?? 'your membership' ) . '.', "Invoice $number" . ( ! empty( $sub['current_period_end'] ) ? ', next renewal ' . self::date( $sub['current_period_end'] ) : '' ) . '.' ],
			'View invoices', get_permalink( (int) get_option( 'pmpro_account_page_id' ) ), [ 'invoice' => $number, 'amount_cents' => (int) $obj['amount_paid'] ] );
	}

	/** Receipts and billing notices always go out; the rest follow what the member chose on their profile. */
	private const OPTIONAL = [ 'module_open' ];

	public static function wants( int $user_id, string $template ): bool {
		if ( ! in_array( $template, self::OPTIONAL, true ) ) {
			return true;
		}
		$prefs = get_user_meta( $user_id, 'bidik_email_prefs', true );
		return ! is_array( $prefs ) || ( $prefs[ $template ] ?? true );
	}

	public static function plan_changed( \WP_User $user, string $headline, array $lines ): void {
		self::send( $user, 'plan_changed', $headline, $headline, $lines, 'Open billing', add_query_arg( 'view', 'billing', get_permalink( (int) get_option( 'pmpro_account_page_id' ) ) ) );
	}

	/** @param string[] $lines @param array<string,mixed> $context */
	public static function send( \WP_User $user, string $template, string $subject, string $heading, array $lines, string $cta, string $url, array $context = [] ): void {
		global $wpdb;
		if ( ! self::wants( $user->ID, $template ) ) {
			return;
		}
		$body = '<div style="background:#f2f3f1;padding:32px 16px;font-family:Helvetica,Arial,sans-serif;color:#16191d"><div style="max-width:520px;margin:0 auto;background:#fff;border:1px solid #d6d9d5;border-radius:10px;padding:32px">'
			. '<p style="margin:0 0 24px;font-weight:800;font-size:20px;letter-spacing:-.02em">Bidik</p>'
			. '<h1 style="margin:0 0 16px;font-size:24px;line-height:1.2">' . esc_html( $heading ) . '</h1>';
		foreach ( $lines as $line ) {
			$body .= '<p style="margin:0 0 12px;font-size:16px;line-height:1.55;color:#4a515a">' . esc_html( $line ) . '</p>';
		}
		$body .= '<p style="margin:24px 0 0"><a href="' . esc_url( $url ) . '" style="display:inline-block;background:#1f4e8a;color:#fff;text-decoration:none;font-weight:600;padding:12px 18px;border-radius:6px">' . esc_html( $cta ) . '</a></p>'
			. '<p style="margin:32px 0 0;font-size:12px;color:#5c636c">Bidik is a fictional photography school. This is a demo email.</p></div></div>';

		$wpdb->insert( $wpdb->prefix . 'bidik_email_log', [ 'user_id' => $user->ID, 'template' => $template, 'subject' => $subject, 'recipient' => $user->user_email,
			'context' => wp_json_encode( $context + [ 'html' => $body ] ), 'sent_at' => Clock::mysql() ] );
		try {
			wp_mail( $user->user_email, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
		} catch ( \Throwable $e ) {
			error_log( 'Bidik mail: ' . $e->getMessage() );
		}
	}
}
