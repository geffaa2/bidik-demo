<?php
namespace Bidik\Esp;

defined( 'ABSPATH' ) || exit;

/** Mailchimp Marketing API v3. Written from its documentation and tested against recorded request shapes, not a live account. */
final class Mailchimp implements Adapter {
	public function __construct( private string $key, private string $list ) {}

	public function name(): string {
		return 'mailchimp';
	}

	private function call( string $method, string $path, array $body ): array {
		$dc  = substr( strrchr( $this->key, '-' ) ?: '-us1', 1 );
		$res = wp_remote_request( "https://$dc.api.mailchimp.com/3.0$path", [ 'method' => $method, 'timeout' => 15, 'headers' => [ 'Authorization' => 'Basic ' . base64_encode( 'bidik:' . $this->key ), 'Content-Type' => 'application/json' ], 'body' => wp_json_encode( $body ) ] );
		if ( is_wp_error( $res ) ) {
			return [ 'ok' => false, 'response' => $res->get_error_message() ];
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		return [ 'ok' => $code >= 200 && $code < 300, 'response' => "HTTP $code " . mb_substr( wp_remote_retrieve_body( $res ), 0, 200 ) ];
	}

	public function set_tags( string $email, string $name, array $add, array $remove ): array {
		$hash = md5( strtolower( $email ) );
		$put  = $this->call( 'PUT', "/lists/{$this->list}/members/$hash", [ 'email_address' => $email, 'status_if_new' => 'subscribed', 'merge_fields' => [ 'FNAME' => $name ] ] );
		if ( ! $put['ok'] ) {
			return $put;
		}
		$tags = array_merge( array_map( static fn( $t ) => [ 'name' => $t, 'status' => 'active' ], $add ), array_map( static fn( $t ) => [ 'name' => $t, 'status' => 'inactive' ], $remove ) );
		return $this->call( 'POST', "/lists/{$this->list}/members/$hash/tags", [ 'tags' => $tags ] );
	}
}
