<?php
namespace Bidik\Esp;

use Bidik\Billing\PlanChange;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps each member's tags on the email list in step with their plan. A change is written to the log first
 * ("queued"), then sent; if the service fails it is tried again, up to 3 times, a minute, five minutes and half an hour apart.
 */
final class Sync {
	private const OPTION = 'bidik_esp';
	private const DELAYS = [ 60, 300, 1800 ];

	public static function register(): void {
		add_action( 'bidik_esp_sync', [ self::class, 'process' ] );
	}

	/** @return array{adapter:string,mailchimp_key:string,mailchimp_list:string,kit_key:string} */
	public static function settings(): array {
		return array_merge( [ 'adapter' => 'mock', 'mailchimp_key' => '', 'mailchimp_list' => '', 'kit_key' => '' ], (array) get_option( self::OPTION, [] ) );
	}

	public static function adapter(): Adapter {
		$s = self::settings();
		if ( 'mailchimp' === $s['adapter'] && $s['mailchimp_key'] && $s['mailchimp_list'] ) {
			return new Mailchimp( $s['mailchimp_key'], $s['mailchimp_list'] );
		}
		if ( 'kit' === $s['adapter'] && $s['kit_key'] ) {
			return new Kit( $s['kit_key'] );
		}
		return new Mock();
	}

	/** @return array{0:string,1:string} tier and status as the list should see them */
	private static function state( int $uid ): array {
		$sub = PlanChange::subscription( $uid );
		$lvl = $sub ? PlanChange::level( (int) $sub['level_id'] ) : null;
		return $sub && $lvl ? [ $lvl['tier'], (string) $sub['status'] ] : [ 'free', 'active' ];
	}

	/** @return list<string> */
	private static function have( int $uid ): array {
		$m = get_user_meta( $uid, 'bidik_esp_tags', true );
		return is_array( $m ) ? array_values( $m ) : [];
	}

	/** Called whenever a member's plan or status may have changed. Does nothing when the list already agrees. */
	public static function enqueue( int $uid ): void {
		global $wpdb;
		[ $tier, $status ] = self::state( $uid );
		$want = Tags::desired( $tier, $status );
		$diff = Tags::diff( self::have( $uid ), $want );
		if ( ! $diff['add'] && ! $diff['remove'] ) {
			return;
		}
		$log = $wpdb->prefix . 'bidik_esp_log';
		if ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $log WHERE user_id = %d AND status IN ('queued','retry')", $uid ) ) > 0 ) {
			return; // a send is already waiting; it reads the member's state when it runs
		}
		$wpdb->insert( $log, [ 'user_id' => $uid, 'adapter' => self::adapter()->name(), 'action' => 'tags', 'tags' => wp_json_encode( $diff + [ 'want' => $want ] ), 'status' => 'queued', 'attempts' => 0, 'created_at' => Clock::mysql() ] );
		$id = (int) $wpdb->insert_id;
		if ( 'mock' === self::adapter()->name() ) {
			self::process( $id ); // nothing to wait for without a network
		} else {
			wp_schedule_single_event( time(), 'bidik_esp_sync', [ $id ] );
		}
	}

	/** One attempt for one log row. */
	public static function process( int $log_id ): void {
		global $wpdb;
		$log = $wpdb->prefix . 'bidik_esp_log';
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $log WHERE id = %d", $log_id ), ARRAY_A );
		if ( ! $row || ! in_array( $row['status'], [ 'queued', 'retry' ], true ) ) {
			return;
		}
		$uid  = (int) $row['user_id'];
		$user = get_userdata( $uid );
		[ $tier, $status ] = self::state( $uid );
		$want = Tags::desired( $tier, $status );
		$diff = Tags::diff( self::have( $uid ), $want );
		if ( ! $user || ( ! $diff['add'] && ! $diff['remove'] ) ) {
			$wpdb->update( $log, [ 'status' => 'skipped', 'response' => 'Already in step' ], [ 'id' => $log_id ] );
			return;
		}
		$res      = self::adapter()->set_tags( $user->user_email, $user->first_name ?: $user->display_name, $diff['add'], $diff['remove'] );
		$attempts = (int) $row['attempts'] + 1;
		$data     = [ 'attempts' => $attempts, 'response' => mb_substr( $res['response'], 0, 500 ), 'tags' => wp_json_encode( $diff + [ 'want' => $want ] ) ];
		if ( $res['ok'] ) {
			update_user_meta( $uid, 'bidik_esp_tags', $want );
			$data['status'] = 'ok';
		} elseif ( $attempts < 3 ) {
			$data['status'] = 'retry';
			wp_schedule_single_event( time() + self::DELAYS[ $attempts - 1 ], 'bidik_esp_sync', [ $log_id ] );
		} else {
			$data['status'] = 'failed';
		}
		$wpdb->update( $log, $data, [ 'id' => $log_id ] );
	}
}
