<?php
namespace Bidik\Esp;

defined( 'ABSPATH' ) || exit;

/** An email-list service. Bidik only ever sets its own tags. */
interface Adapter {
	public function name(): string;

	/**
	 * @param list<string> $add
	 * @param list<string> $remove
	 * @return array{ok:bool,response:string}
	 */
	public function set_tags( string $email, string $name, array $add, array $remove ): array;
}
