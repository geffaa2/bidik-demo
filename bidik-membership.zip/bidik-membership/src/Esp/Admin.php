<?php
namespace Bidik\Esp;

defined( 'ABSPATH' ) || exit;

/** Bidik › Integrations: choose the email-list service and read what was sent. */
final class Admin {
	public static function register(): void {
		add_action( 'admin_post_bidik_esp_save', [ self::class, 'save' ] );
		Sync::register();
	}

	public static function save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'You do not have permission to change integrations.', 'Not allowed', [ 'response' => 403 ] );
		}
		check_admin_referer( 'bidik_esp' );
		$old = Sync::settings();
		$in  = wp_unslash( $_POST );
		$key = static fn( string $k, string $keep ) => '' !== trim( (string) ( $in[ $k ] ?? '' ) ) ? sanitize_text_field( $in[ $k ] ) : $keep; // a blank key field keeps the saved one
		update_option( 'bidik_esp', [ 'adapter' => in_array( $in['adapter'] ?? '', [ 'mock', 'mailchimp', 'kit' ], true ) ? $in['adapter'] : 'mock', 'mailchimp_key' => $key( 'mailchimp_key', $old['mailchimp_key'] ),
			'mailchimp_list' => sanitize_text_field( $in['mailchimp_list'] ?? '' ), 'kit_key' => $key( 'kit_key', $old['kit_key'] ) ], false );
		wp_safe_redirect( add_query_arg( [ 'page' => 'bidik-integrations', 'saved' => 1 ], admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function mask( string $k ): string {
		return $k ? '••••' . substr( $k, -4 ) : 'not set';
	}

	public static function page(): void {
		global $wpdb;
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'You do not have permission to open this page.', 'Not allowed', [ 'response' => 403 ] );
		}
		$s = Sync::settings();
		echo '<div class="wrap bd-admin"><h1>Bidik › Integrations</h1>';
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<div class="bd-box"><h2>Email list</h2><p class="bd-lead">When a member joins, changes plan, falls behind on payment or leaves, Bidik adds and removes its own tags (<code>bidik-free</code>, <code>bidik-member</code>, <code>bidik-pro</code>, <code>bidik-past-due</code>) on your list. Tags you made yourself are never touched.</p>'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bidik_esp_save">' . wp_nonce_field( 'bidik_esp', '_wpnonce', true, false ) . '<table class="form-table" role="presentation"><tbody>'
			. '<tr><th scope="row"><label for="bd-adapter">Service</label></th><td><select name="adapter" id="bd-adapter">';
		foreach ( [ 'mock' => 'Demo (nothing is sent, the log shows what would be)', 'mailchimp' => 'Mailchimp', 'kit' => 'Kit (ConvertKit)' ] as $v => $l ) {
			echo '<option value="' . esc_attr( $v ) . '"' . selected( $s['adapter'], $v, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></td></tr>'
			. '<tr><th scope="row"><label for="bd-mckey">Mailchimp API key</label></th><td><input class="regular-text" type="password" autocomplete="off" name="mailchimp_key" id="bd-mckey" placeholder="' . esc_attr( self::mask( $s['mailchimp_key'] ) ) . '"> <input class="regular-text" type="text" name="mailchimp_list" aria-label="Mailchimp audience id" placeholder="Audience id" value="' . esc_attr( $s['mailchimp_list'] ) . '"></td></tr>'
			. '<tr><th scope="row"><label for="bd-kitkey">Kit API key</label></th><td><input class="regular-text" type="password" autocomplete="off" name="kit_key" id="bd-kitkey" placeholder="' . esc_attr( self::mask( $s['kit_key'] ) ) . '"></td></tr></tbody></table>'
			. '<p class="description">Mailchimp and Kit are written from their public API documentation and were not run against a live account. Try them with a test list first. Leave a key field empty to keep the saved key.</p><p><button class="button button-primary" type="submit">Save</button></p></form></div>';

		$rows = (array) $wpdb->get_results( "SELECT l.*, u.user_email FROM {$wpdb->prefix}bidik_esp_log l LEFT JOIN {$wpdb->users} u ON u.ID = l.user_id ORDER BY l.id DESC LIMIT 100", ARRAY_A );
		echo '<div class="bd-box"><h2>What was sent</h2><table class="widefat striped"><thead><tr><th>When</th><th>Member</th><th>Service</th><th>Tags</th><th>Result</th><th>Tries</th><th>Response</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$t     = json_decode( (string) $r['tags'], true ) ?: [];
			$delta = implode( ' ', array_merge( array_map( static fn( $x ) => '+' . $x, $t['add'] ?? [] ), array_map( static fn( $x ) => '−' . $x, $t['remove'] ?? [] ) ) );
			$cls   = [ 'ok' => 'bd-ok', 'failed' => 'bd-fail', 'retry' => 'bd-warn' ][ $r['status'] ] ?? '';
			echo '<tr><td>' . esc_html( wp_date( 'j M H:i', strtotime( $r['created_at'] . ' UTC' ) ) ) . '</td><td>' . esc_html( (string) $r['user_email'] ) . '</td><td>' . esc_html( $r['adapter'] ) . '</td><td><code>' . esc_html( $delta ) . '</code></td><td class="' . $cls . '">' . esc_html( $r['status'] ) . '</td><td>' . (int) $r['attempts'] . '</td><td class="bd-sub">' . esc_html( (string) $r['response'] ) . '</td></tr>';
		}
		echo $rows ? '' : '<tr><td colspan="7">Nothing sent yet. It starts when a member joins or changes plan.</td></tr>';
		echo '</tbody></table></div></div>';
	}
}
