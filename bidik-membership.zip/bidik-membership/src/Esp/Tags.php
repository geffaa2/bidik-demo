<?php
namespace Bidik\Esp;

/** Pure: which email-list tags a member should carry, and what to add or remove to get there. */
final class Tags {
	public const ALL = [ 'bidik-free', 'bidik-member', 'bidik-pro', 'bidik-past-due' ];

	/** @return list<string> */
	public static function desired( string $tier, string $status ): array {
		$live = in_array( $status, [ 'trialing', 'active', 'past_due' ], true );
		$tags = [ 'bidik-' . ( $live && in_array( $tier, [ 'member', 'pro' ], true ) ? $tier : 'free' ) ];
		if ( 'past_due' === $status ) {
			$tags[] = 'bidik-past-due';
		}
		return $tags;
	}

	/** @param list<string> $have @param list<string> $want @return array{add:list<string>,remove:list<string>} only Bidik's own tags are ever removed */
	public static function diff( array $have, array $want ): array {
		return [ 'add' => array_values( array_diff( $want, $have ) ), 'remove' => array_values( array_intersect( array_diff( $have, $want ), self::ALL ) ) ];
	}
}
