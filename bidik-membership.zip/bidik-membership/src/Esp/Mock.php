<?php
namespace Bidik\Esp;

defined( 'ABSPATH' ) || exit;

/** Records what it would send. Needs no account, so the demo and the tests can show the whole flow. `bidik_esp_mock_fail` = N makes the next N calls fail. */
final class Mock implements Adapter {
	public function name(): string {
		return 'mock';
	}

	public function set_tags( string $email, string $name, array $add, array $remove ): array {
		$fail = (int) get_option( 'bidik_esp_mock_fail', 0 );
		if ( $fail > 0 ) {
			update_option( 'bidik_esp_mock_fail', $fail - 1, false );
			return [ 'ok' => false, 'response' => 'Mock: simulated 503 from the list service' ];
		}
		return [ 'ok' => true, 'response' => 'Mock: would tag ' . $email . ( $add ? ' +' . implode( ' +', $add ) : '' ) . ( $remove ? ' -' . implode( ' -', $remove ) : '' ) ];
	}
}
