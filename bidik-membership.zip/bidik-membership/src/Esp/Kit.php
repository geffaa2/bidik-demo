<?php
namespace Bidik\Esp;

defined( 'ABSPATH' ) || exit;

/** Kit (ConvertKit) API v4. Written from its documentation and tested against recorded request shapes, not a live account. */
final class Kit implements Adapter {
	public function __construct( private string $key ) {}

	public function name(): string {
		return 'kit';
	}

	/** @return array{ok:bool,code:int,json:array<string,mixed>,error:string} */
	private function call( string $method, string $path, ?array $body = null ): array {
		$res = wp_remote_request( 'https://api.kit.com/v4' . $path, [ 'method' => $method, 'timeout' => 15, 'headers' => [ 'X-Kit-Api-Key' => $this->key, 'Content-Type' => 'application/json' ], 'body' => null === $body ? null : wp_json_encode( $body ) ] );
		if ( is_wp_error( $res ) ) {
			return [ 'ok' => false, 'code' => 0, 'json' => [], 'error' => $res->get_error_message() ];
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		return [ 'ok' => $code >= 200 && $code < 300, 'code' => $code, 'json' => json_decode( wp_remote_retrieve_body( $res ), true ) ?: [], 'error' => "HTTP $code" ];
	}

	/** The tag's id; creates the tag when the account does not have it yet (only when adding). */
	private function tag_id( string $name, bool $create = true ): ?int {
		$list = $this->call( 'GET', '/tags' );
		foreach ( $list['json']['tags'] ?? [] as $t ) {
			if ( ( $t['name'] ?? '' ) === $name ) {
				return (int) $t['id'];
			}
		}
		if ( ! $create ) {
			return null;
		}
		$new = $this->call( 'POST', '/tags', [ 'name' => $name ] );
		return isset( $new['json']['tag']['id'] ) ? (int) $new['json']['tag']['id'] : null;
	}

	public function set_tags( string $email, string $name, array $add, array $remove ): array {
		$sub = $this->call( 'POST', '/subscribers', [ 'email_address' => $email, 'first_name' => $name ] );
		$sid = (int) ( $sub['json']['subscriber']['id'] ?? 0 );
		if ( ! $sub['ok'] || ! $sid ) {
			return [ 'ok' => false, 'response' => 'Subscriber: ' . $sub['error'] ];
		}
		foreach ( $add as $t ) {
			$id = $this->tag_id( $t );
			$r  = $id ? $this->call( 'POST', "/tags/$id/subscribers", [ 'email_address' => $email ] ) : [ 'ok' => false, 'error' => 'tag not found' ];
			if ( ! $r['ok'] ) {
				return [ 'ok' => false, 'response' => "Tag $t: " . $r['error'] ];
			}
		}
		foreach ( $remove as $t ) {
			$id = $this->tag_id( $t, false );
			$r  = $id ? $this->call( 'DELETE', "/tags/$id/subscribers/$sid" ) : [ 'ok' => true, 'error' => '' ];
			if ( ! $r['ok'] ) {
				return [ 'ok' => false, 'response' => "Untag $t: " . $r['error'] ];
			}
		}
		return [ 'ok' => true, 'response' => 'HTTP 2xx' ];
	}
}
