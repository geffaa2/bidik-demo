<?php
namespace Bidik;

defined( 'ABSPATH' ) || exit;

/** Bidik's own tables (TECH-SPEC §3). Installed on activation and whenever VERSION changes. */
final class Schema {
	public const VERSION = '4';
	private const OPTION = 'bidik_schema_version';

	public static function register(): void {
		add_action( 'plugins_loaded', [ self::class, 'maybe_install' ], 5 );
	}

	public static function maybe_install(): void {
		if ( get_option( self::OPTION ) !== self::VERSION ) {
			self::install();
		}
	}

	/** @return string[] table names without the WordPress prefix */
	public static function tables(): array {
		return [ 'subscriptions', 'invoices', 'events', 'progress', 'drip_notices', 'cancel_feedback',
			'mrr_snapshots', 'email_log', 'imports', 'import_rows', 'esp_log' ];
	}

	/** @return string[] full names of Bidik tables that do not exist */
	public static function missing(): array {
		global $wpdb;
		$missing = [];
		foreach ( self::tables() as $table ) {
			$name = $wpdb->prefix . 'bidik_' . $table;
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) !== $name ) {
				$missing[] = $name;
			}
		}
		return $missing;
	}

	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		$p = $wpdb->prefix . 'bidik_';

		$sql = [
"CREATE TABLE {$p}subscriptions (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  level_id bigint(20) unsigned NOT NULL,
  gateway varchar(20) NOT NULL,
  gateway_customer_id varchar(100) NOT NULL DEFAULT '',
  gateway_subscription_id varchar(100) NOT NULL,
  status varchar(20) NOT NULL,
  current_period_start datetime DEFAULT NULL,
  current_period_end datetime DEFAULT NULL,
  trial_end datetime DEFAULT NULL,
  cancel_at_period_end tinyint(1) NOT NULL DEFAULT 0,
  pause_until datetime DEFAULT NULL,
  grace_until datetime DEFAULT NULL,
  scheduled_level_id bigint(20) unsigned DEFAULT NULL,
  churn_type varchar(20) DEFAULT NULL,
  canceled_at datetime DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY gateway_subscription_id (gateway_subscription_id),
  KEY user_id (user_id),
  KEY status (status)
) $c;",
"CREATE TABLE {$p}invoices (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  number varchar(30) NOT NULL,
  user_id bigint(20) unsigned NOT NULL,
  subscription_id bigint(20) unsigned NOT NULL,
  gateway_invoice_id varchar(100) NOT NULL,
  amount_cents int(11) NOT NULL,
  currency char(3) NOT NULL DEFAULT 'USD',
  status varchar(20) NOT NULL,
  line_items longtext NOT NULL,
  paid_at datetime DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY number (number),
  UNIQUE KEY gateway_invoice_id (gateway_invoice_id),
  KEY user_id (user_id),
  KEY subscription_id (subscription_id)
) $c;",
"CREATE TABLE {$p}events (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  gateway varchar(20) NOT NULL,
  event_id varchar(100) NOT NULL,
  type varchar(60) NOT NULL,
  payload longtext NOT NULL,
  processed_at datetime DEFAULT NULL,
  error text DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY gateway_event (gateway,event_id),
  KEY type (type)
) $c;",
"CREATE TABLE {$p}progress (
  user_id bigint(20) unsigned NOT NULL,
  lesson_id bigint(20) unsigned NOT NULL,
  completed_at datetime NOT NULL,
  PRIMARY KEY  (user_id,lesson_id),
  KEY lesson_id (lesson_id)
) $c;",
"CREATE TABLE {$p}drip_notices (
  user_id bigint(20) unsigned NOT NULL,
  module_key varchar(60) NOT NULL,
  sent_at datetime NOT NULL,
  PRIMARY KEY  (user_id,module_key)
) $c;",
"CREATE TABLE {$p}cancel_feedback (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  subscription_id bigint(20) unsigned NOT NULL,
  reason varchar(30) NOT NULL,
  comment text DEFAULT NULL,
  offer_shown varchar(30) DEFAULT NULL,
  offer_accepted tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY user_id (user_id)
) $c;",
"CREATE TABLE {$p}mrr_snapshots (
  day date NOT NULL,
  mrr_cents int(11) NOT NULL,
  active_by_tier longtext NOT NULL,
  trials int(11) NOT NULL DEFAULT 0,
  churned_voluntary int(11) NOT NULL DEFAULT 0,
  churned_involuntary int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (day)
) $c;",
"CREATE TABLE {$p}email_log (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  template varchar(40) NOT NULL,
  subject varchar(200) NOT NULL,
  recipient varchar(200) NOT NULL,
  context longtext DEFAULT NULL,
  sent_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY user_id (user_id),
  KEY template (template)
) $c;",
"CREATE TABLE {$p}imports (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  file varchar(200) NOT NULL,
  mapping longtext DEFAULT NULL,
  status varchar(20) NOT NULL,
  total int(11) NOT NULL DEFAULT 0,
  ok int(11) NOT NULL DEFAULT 0,
  failed int(11) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id)
) $c;",
"CREATE TABLE {$p}import_rows (
  import_id bigint(20) unsigned NOT NULL,
  line_no int(11) NOT NULL,
  data longtext NOT NULL,
  status varchar(20) NOT NULL,
  message varchar(255) DEFAULT NULL,
  PRIMARY KEY  (import_id,line_no)
) $c;",
"CREATE TABLE {$p}esp_log (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  user_id bigint(20) unsigned NOT NULL,
  adapter varchar(20) NOT NULL,
  action varchar(30) NOT NULL,
  tags longtext DEFAULT NULL,
  status varchar(20) NOT NULL,
  attempts tinyint(3) unsigned NOT NULL DEFAULT 1,
  response text DEFAULT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY user_id (user_id)
) $c;",
		];
		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
		// dbDelta fails silently (a reserved word is enough), so check that every table exists.
		$missing = self::missing();
		if ( $missing ) {
			update_option( 'bidik_schema_error', 'Missing tables: ' . implode( ', ', $missing ), false );
			error_log( 'Bidik schema: missing tables ' . implode( ', ', $missing ) );
			return;
		}
		delete_option( 'bidik_schema_error' );
		update_option( self::OPTION, self::VERSION, false );
	}
}
