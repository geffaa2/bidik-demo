<?php
namespace Bidik\Account;

use Bidik\Billing\Cards;
use Bidik\Billing\MembershipSync;
use Bidik\Billing\PlanChange;
use Bidik\Chrome;
use Bidik\Content\Members;
use Bidik\Courses\Catalog;
use Bidik\Courses\Drip;
use Bidik\Courses\Progress;
use Bidik\Courses\Views;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** [bidik_account]: Overview, Billing, and Profile & email for a signed-in member. */
final class Account {
	private const VIEWS = [ 'overview' => [ 'Overview', 'house' ], 'billing' => [ 'Billing', 'credit-card' ], 'profile' => [ 'Profile & email', 'user-round' ] ];

	public static function register(): void {
		add_shortcode( 'bidik_account', [ self::class, 'render' ] );
		add_action( 'admin_post_bidik_profile', [ self::class, 'save_profile' ] );
		InvoicePage::register();
		Rest::register();
	}

	public static function url( string $view = 'overview' ): string {
		$base = (string) get_permalink( (int) get_option( 'pmpro_account_page_id' ) );
		return 'overview' === $view ? $base : add_query_arg( 'view', $view, $base );
	}

	/** The windows (plan change, card) and their script. Loaded on the account and on Pricing for members. */
	public static function assets(): void {
		wp_enqueue_style( 'bidik-account', plugins_url( 'assets/account.css', BIDIK_FILE ), [ 'bidik-site' ], (string) filemtime( dirname( __DIR__, 2 ) . '/assets/account.css' ) );
		wp_enqueue_script( 'bidik-account', plugins_url( 'assets/account.js', BIDIK_FILE ), [], (string) filemtime( dirname( __DIR__, 2 ) . '/assets/account.js' ), true );
		wp_localize_script( 'bidik-account', 'bidikAccount', [ 'root' => esc_url_raw( rest_url( 'bidik/v1/' ) ), 'nonce' => wp_create_nonce( 'wp_rest' ), 'billing' => self::url( 'billing' ) ] );
	}

	private static function date( ?string $mysql, string $fmt = 'D j M Y' ): string {
		return $mysql ? ( new \DateTimeImmutable( $mysql, new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( $fmt ) : '';
	}

	private static function money( float $n ): string {
		return '$' . number_format( $n, 2 );
	}

	public static function render(): string {
		if ( ! is_user_logged_in() ) {
			return '<div class="blk acct-login"><h2>Log in to see your account</h2><p>Your plan, invoices and progress are here once you are signed in.</p><p><a class="btn btn-primary" href="' . esc_url( wp_login_url( self::url() ) ) . '">Log in</a> <a class="btn btn-secondary" href="' . esc_url( (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) ) ) . '">See plans</a></p></div>';
		}
		self::assets();
		$view = isset( $_GET['view'] ) && isset( self::VIEWS[ $_GET['view'] ] ) ? (string) $_GET['view'] : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification
		$nav  = '';
		foreach ( self::VIEWS as $key => [ $label, $icon ] ) {
			$nav .= '<a href="' . esc_url( self::url( $key ) ) . '"' . ( $key === $view ? ' aria-current="page"' : '' ) . '>' . Chrome::icon( $icon ) . esc_html( $label ) . '</a>';
		}
		$uid  = get_current_user_id();
		$body = match ( $view ) { 'billing' => self::billing( $uid ), 'profile' => self::profile( $uid ), default => self::overview( $uid ) };
		return '<div class="acct"><div class="acct-grid"><nav class="subnav" aria-label="Account">' . $nav . '</nav><div class="acct-main">' . $body . '</div></div></div>' . self::dialog_shell();
	}

	public static function dialog_shell(): string {
		return '<div class="scrim" data-bidik-scrim hidden><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="bd-dlg-t" tabindex="-1"><header><div><h2 id="bd-dlg-t"></h2><p class="sub"></p></div>'
			. '<button type="button" class="icon-btn" data-bidik-close aria-label="Close">' . Chrome::icon( 'x' ) . '</button></header><div class="body" aria-live="polite"></div><footer></footer></div></div>';
	}

	/* ------------------------------------------------------------ overview */

	private static function overview( int $uid ): string {
		$u    = get_userdata( $uid );
		$ctx  = Members::context( $uid );
		$sub  = PlanChange::subscription( $uid );
		$now  = Clock::now();
		$name = $u->first_name ?: $u->display_name;
		$plan = self::plan_summary( $uid, $sub, $ctx );

		$cards = '';
		foreach ( Catalog::courses() as $c ) {
			$struct = Catalog::structure( $c->ID );
			$total  = count( $struct['lessons'] );
			$has    = $ctx['admin'] || $ctx['rank'] >= Catalog::course_rank( $c->ID );
			if ( ! $has || ! $total ) {
				continue;
			}
			$done   = count( Progress::done( $uid, array_map( static fn( $l ) => $l['post']->ID, $struct['lessons'] ) ) );
			$resume = Views::resume( $c->ID, $ctx );
			$shut   = Views::next_shut( $struct, $ctx, $now );
			$status = $resume ? ( $done ? 'Continue with ' : 'Start with ' ) . '<b>' . esc_html( get_the_title( $resume ) ) . '</b>' : ( $shut ? 'Caught up. <b>Module ' . ( $shut['index'] + 1 ) . '</b> ' . esc_html( lcfirst( Drip::opens_label( $shut['opens'], $now, wp_timezone() ) ) ) : 'Course complete' );
			$cards .= '<li class="cont"><div><h3>' . esc_html( get_the_title( $c ) ) . '</h3><p>' . $status . '</p><div class="prog-line"><span class="bar"><span style="width:' . round( 100 * $done / $total ) . '%"></span></span><span>' . $done . ' of ' . $total . ' lessons</span></div></div>'
				. '<a class="btn ' . ( $resume ? 'btn-primary' : 'btn-secondary' ) . '" href="' . esc_url( (string) get_permalink( $resume ?: $c ) ) . '">' . ( $resume ? ( $done ? 'Continue' : 'Start' ) : 'Open course' ) . '</a></li>';
		}
		$learn = $cards ? '<section class="blk" aria-labelledby="o-learn"><div class="blk-head"><h2 id="o-learn">Keep learning</h2></div><ul class="cont-list">' . $cards . '</ul></section>'
			: '<section class="blk" aria-labelledby="o-learn"><div class="blk-head"><h2 id="o-learn">Keep learning</h2></div><p class="fine-plain">Courses open with Member. Lesson 1 of every course is free: <a href="' . esc_url( (string) get_permalink( (int) get_option( 'bidik_page_courses' ) ) ) . '">start there</a>.</p></section>';
		return '<p class="hello">Hi, ' . esc_html( $name ) . '.</p>' . $plan . $learn;
	}

	/** The plan card shared by Overview: what you are on and what happens next. */
	private static function plan_summary( int $uid, ?array $sub, array $ctx ): string {
		$pricing = (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) );
		if ( ! $sub ) {
			return '<section class="blk plan-blk" aria-labelledby="o-plan"><div class="blk-head"><h2 id="o-plan">Your plan</h2><a class="btn btn-primary" href="' . esc_url( $pricing ) . '">See Member and Pro</a></div>'
				. '<div class="kv kv-2"><div><span>Plan</span><b>' . ( $ctx['admin'] ? 'Administrator' : 'Free' ) . '</b></div><div><span>What it opens</span><b>Open articles and lesson 1 of every course</b></div></div></section>';
		}
		$lvl   = PlanChange::level( (int) $sub['level_id'] );
		$price = self::money( MembershipSync::price_for( $uid, (int) $sub['level_id'] ) ) . ( 'year' === $lvl['interval'] ? ' a year' : ' a month' );
		[ $badge, $next ] = self::status_bits( $sub, $price );
		return '<section class="blk plan-blk" aria-labelledby="o-plan"><div class="blk-head"><h2 id="o-plan">Your plan ' . $badge . '</h2><a class="btn btn-secondary" href="' . esc_url( self::url( 'billing' ) ) . '">Manage billing</a></div>'
			. '<div class="kv"><div><span>Plan</span><b>' . esc_html( $lvl['name'] ) . '</b></div><div><span>Price</span><b>' . esc_html( $price ) . '</b></div>' . $next . '</div></section>';
	}

	/** @return array{0:string,1:string} badge html, and the "next" cells */
	private static function status_bits( array $sub, string $price ): array {
		$cell = static fn( string $k, string $v ) => '<div><span>' . esc_html( $k ) . '</span><b>' . esc_html( $v ) . '</b></div>';
		switch ( $sub['status'] ) {
			case 'trialing':
				return [ '<span class="badge badge-cyan">Trial</span>', $cell( 'Trial ends', self::date( $sub['trial_end'] ) ) . $cell( 'First charge', $price . ' on ' . self::date( $sub['trial_end'], 'j M' ) ) ];
			case 'past_due':
				return [ '<span class="badge badge-open">Past due</span>', $cell( 'Access until', self::date( $sub['grace_until'] ) ) . $cell( 'Next step', 'Update your card' ) ];
			case 'paused':
				return [ '<span class="badge badge-amber">Paused</span>', $cell( 'Resumes', self::date( $sub['pause_until'] ) ) . $cell( 'Billing', 'Stopped' ) ];
			default:
				return [ '<span class="badge badge-paid">Active</span>', ! empty( $sub['cancel_at_period_end'] )
					? $cell( 'Access until', self::date( $sub['current_period_end'] ) ) . $cell( 'After that', 'Free' )
					: $cell( 'Renews on', self::date( $sub['current_period_end'] ) ) ];
		}
	}

	/* ------------------------------------------------------------ billing */

	private static function billing( int $uid ): string {
		global $wpdb;
		$sub = PlanChange::subscription( $uid );
		$now = Clock::now();
		$out = '';
		if ( isset( $_GET['changed'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$out .= '<p class="co-note" role="status">' . Chrome::icon( 'circle-check' ) . '<span>' . esc_html( [ 'downgrade' => 'Done. Your plan change is scheduled; you keep your current plan until the period ends.', 'trial' => 'Done. Your trial keeps running on the new plan.' ][ $_GET['changed'] ] ?? 'Done. Your new plan is open.' ) . '</span></p>'; // phpcs:ignore
		}
		if ( isset( $_GET['left'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$says = [ 'cancel' => 'Your cancellation is scheduled. You keep your plan until the period ends, and you can resume until then.', 'pause' => 'Your membership is paused. Billing has stopped and you are on Free until it resumes.',
				'discount' => 'Done: 30% off your next two renewals. Thanks for staying.', 'resume' => 'Welcome back. Your plan is open again.' ][ $_GET['left'] ] ?? ''; // phpcs:ignore
			$out .= $says ? '<p class="co-note" role="status">' . Chrome::icon( 'circle-check' ) . '<span>' . esc_html( $says ) . '</span></p>' : '';
		}
		if ( isset( $_GET['card'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$out .= '<p class="co-note" role="status">' . Chrome::icon( 'circle-check' ) . '<span>Card updated.</span></p>';
		}
		if ( ! $sub ) {
			return $out . '<section class="blk"><div class="blk-head"><h2>Billing</h2></div><p class="fine-plain">You are on Free, so there is nothing to pay. Member opens the full library and two courses, with a 7-day trial.</p><p><a class="btn btn-primary" href="' . esc_url( (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) ) ) . '">Compare plans</a></p></section>';
		}
		$lvl   = PlanChange::level( (int) $sub['level_id'] );
		$price = self::money( MembershipSync::price_for( $uid, (int) $sub['level_id'] ) ) . ( 'year' === $lvl['interval'] ? ' a year' : ' a month' );
		[ $badge, $next ] = self::status_bits( $sub, $price );
		$since = (int) get_user_meta( $uid, 'bidik_member_since', true );
		$open  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_invoices WHERE subscription_id = %d AND status = 'open' ORDER BY id DESC LIMIT 1", (int) $sub['id'] ), ARRAY_A );

		if ( 'past_due' === $sub['status'] && $open ) {
			$left  = max( 0, (int) ceil( ( strtotime( $sub['grace_until'] . ' UTC' ) - $now ) / DAY_IN_SECONDS ) );
			$card0 = Cards::get( $uid );
			$out  .= '<div class="dun" role="alert"><span class="dun-ic">' . Chrome::icon( 'triangle-alert' ) . '</span><div class="dun-txt"><h2>Your ' . esc_html( self::money( $open['amount_cents'] / 100 ) ) . ' payment didn\'t go through</h2>'
				. '<p>' . ( $card0 ? esc_html( $card0['brand'] . ' ending ' . $card0['last4'] ) . ' was declined on ' . esc_html( self::date( $open['created_at'], 'j M' ) ) . '. ' : '' ) . esc_html( $lvl['name'] ) . ' stays open until <b>' . esc_html( self::date( $sub['grace_until'], 'D j M' ) ) . '</b>. That\'s ' . $left . ' ' . ( 1 === $left ? 'day' : 'days' ) . ' to update your card.</p></div>'
				. '<div class="dun-act"><button type="button" class="btn btn-primary" data-bidik-card>' . Chrome::icon( 'credit-card', 'icon sm' ) . 'Update card</button></div></div>';
		}

		$sched = '';
		if ( ! empty( $sub['scheduled_level_id'] ) && ( $to = PlanChange::level( (int) $sub['scheduled_level_id'] ) ) ) {
			$sched = '<p class="sched">' . Chrome::icon( 'calendar-clock' ) . '<span>Moves to <b>' . esc_html( $to['name'] ) . '</b> on ' . esc_html( self::date( $sub['current_period_end'] ) ) . '.</span><button type="button" class="btn btn-ghost" data-bidik-undo>' . Chrome::icon( 'undo-2', 'icon sm' ) . 'Undo</button></p>';
		} elseif ( ! empty( $sub['cancel_at_period_end'] ) ) {
			$sched = '<p class="sched">' . Chrome::icon( 'calendar-clock' ) . '<span>Ends on <b>' . esc_html( self::date( $sub['current_period_end'] ) ) . '</b>, then you move to Free.</span><button type="button" class="btn btn-ghost" data-bidik-undo>' . Chrome::icon( 'undo-2', 'icon sm' ) . 'Resume</button></p>';
		}

		$out .= '<section class="blk plan-blk" aria-labelledby="b-plan"><div class="blk-head"><h2 id="b-plan">Plan ' . $badge . '</h2><a class="btn btn-secondary" href="' . esc_url( (string) get_permalink( (int) get_option( 'pmpro_levels_page_id' ) ) ) . '">Change plan</a></div>'
			. '<div class="kv"><div><span>Current plan</span><b>' . esc_html( $lvl['name'] ) . '</b></div><div><span>Price</span><b>' . esc_html( $price ) . '</b></div>'
			. '<div><span>Member since</span><b>' . esc_html( $since ? wp_date( 'j M Y', $since ) : self::date( $sub['created_at'], 'j M Y' ) ) . '</b></div>' . $next . '</div>' . $sched . '</section>';

		// card
		$card = Cards::get( $uid );
		if ( $card ) {
			$state = Cards::expiry_state( $card, $now );
			$warn  = 'expired' === $state ? '<span class="exp bad">' . Chrome::icon( 'triangle-alert', 'icon sm' ) . 'Expired ' . esc_html( $card['exp'] ) . '</span>'
				: ( 'expiring' === $state ? '<span class="exp">' . Chrome::icon( 'info', 'icon sm' ) . 'Expires this month, ' . esc_html( $card['exp'] ) . '</span>' : '<span class="exp ok">Expires ' . esc_html( $card['exp'] ) . '</span>' );
			$row   = '<div class="card-row"><span class="card-chip" aria-hidden="true">' . esc_html( strtoupper( $card['brand'] ) ) . '</span><div><b>' . esc_html( $card['brand'] . ' ending ' . $card['last4'] ) . '</b>' . $warn . '</div><button type="button" class="btn btn-secondary" data-bidik-card>Update card</button></div>';
		} else {
			$row = '<div class="card-row"><span class="card-chip" aria-hidden="true">CARD</span><div><b>No card on file</b></div><button type="button" class="btn btn-primary" data-bidik-card>Add a card</button></div>';
		}
		$out .= '<section class="blk" aria-labelledby="b-card"><div class="blk-head"><h2 id="b-card">Payment method</h2></div>' . $row
			. '<p class="fine">' . Chrome::icon( 'shield-check', 'icon sm' ) . 'Demo site: only test cards work, and only the last 4 digits are kept. With Stripe, card details never touch this site.</p></section>';

		// invoices
		$invs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_invoices WHERE user_id = %d ORDER BY created_at DESC, id DESC", $uid ), ARRAY_A );
		$rows = '';
		foreach ( $invs as $i ) {
			$lines = json_decode( (string) $i['line_items'], true );
			$what  = (string) ( $lines[0]['description'] ?? 'Membership' );
			$st    = 'paid' === $i['status'] ? '<span class="badge badge-paid">Paid</span>' : '<span class="badge badge-open">Unpaid</span>';
			$act   = 'paid' === $i['status'] ? '<a href="' . esc_url( InvoicePage::url( $i['number'] ) ) . '" aria-label="Open ' . esc_attr( $i['number'] ) . ' as a printable PDF">' . Chrome::icon( 'file-down', 'icon sm' ) . 'PDF</a>' : '<a href="#" class="pay-now" data-bidik-card>Pay now</a>';
			$rows .= '<tr><td data-l="Invoice"><span class="mono">' . esc_html( $i['number'] ) . '</span></td><td data-l="Date">' . esc_html( self::date( $i['created_at'], 'j M Y' ) ) . '</td><td data-l="For">' . esc_html( $what ) . '</td>'
				. '<td data-l="Amount" class="num">' . esc_html( self::money( $i['amount_cents'] / 100 ) ) . '</td><td data-l="Status">' . $st . '</td><td class="act">' . $act . '</td></tr>';
		}
		$table = $rows ? '<div class="table-wrap"><table class="inv"><thead><tr><th scope="col">Invoice</th><th scope="col">Date</th><th scope="col">For</th><th scope="col" class="num">Amount</th><th scope="col">Status</th><th scope="col"><span class="sr">Action</span></th></tr></thead><tbody>' . $rows . '</tbody></table></div>'
			: '<p class="fine-plain">No invoices yet. Your first one appears when your trial ends.</p>';
		return $out . '<section class="blk" aria-labelledby="b-inv"><div class="blk-head"><h2 id="b-inv">Invoices</h2><span class="count">' . count( $invs ) . ( 1 === count( $invs ) ? ' invoice' : ' invoices' ) . '</span></div>' . $table . '</section>' . self::leave_block( $sub );
	}

	/** Pause and cancel, worded for where the plan is right now. */
	private static function leave_block( array $sub ): string {
		$cancel = '<button type="button" class="btn btn-danger-text" data-bidik-cancel>Cancel membership</button>';
		$pause  = '<button type="button" class="btn btn-secondary" data-bidik-pause>' . Chrome::icon( 'pause', 'icon sm' ) . 'Pause membership</button>';
		if ( 'paused' === $sub['status'] ) {
			return '<section class="blk leave" aria-labelledby="b-leave"><div><h2 id="b-leave">Your plan is paused</h2><p>Billing is stopped and you are on Free until <b>' . esc_html( self::date( $sub['pause_until'] ) ) . '</b>. Your progress is kept and the weekly schedule waits for you.</p></div>'
				. '<div class="leave-act"><button type="button" class="btn btn-primary" data-bidik-resume>Resume now</button>' . $cancel . '</div></section>';
		}
		if ( ! empty( $sub['cancel_at_period_end'] ) ) {
			return '<section class="blk leave" aria-labelledby="b-leave"><div><h2 id="b-leave">Your plan ends on ' . esc_html( self::date( $sub['current_period_end'] ) ) . '</h2><p>You keep everything until then. Changed your mind? Resume and nothing changes.</p></div>'
				. '<div class="leave-act"><button type="button" class="btn btn-primary" data-bidik-undo>Resume membership</button></div></section>';
		}
		$can_pause = 'active' === $sub['status'];
		return '<section class="blk leave" aria-labelledby="b-leave"><div><h2 id="b-leave">Need a break?</h2><p>' . ( $can_pause ? 'Pause for 1, 2 or 3 months. Billing stops, your progress stays, and the weekly schedule waits for you.' : 'You can cancel any time. You keep access until the end of what you have paid for.' ) . '</p></div>'
			. '<div class="leave-act">' . ( $can_pause ? $pause : '' ) . $cancel . '</div></section>';
	}

	/* ------------------------------------------------------------ profile */

	private static function profile( int $uid ): string {
		$u     = get_userdata( $uid );
		$prefs = get_user_meta( $uid, 'bidik_email_prefs', true );
		$on    = static fn( string $k ) => ! is_array( $prefs ) || ( $prefs[ $k ] ?? true );
		$msg   = '';
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$msg = '<p class="co-note" role="status">' . Chrome::icon( 'circle-check' ) . '<span>Saved.</span></p>';
		} elseif ( isset( $_GET['problem'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$msg = '<p class="form-error" role="alert">' . Chrome::icon( 'triangle-alert', 'icon sm' ) . esc_html( 'email' === $_GET['problem'] ? 'That email address is not valid or belongs to another account.' : 'Something went wrong. Try again.' ) . '</p>'; // phpcs:ignore
		}
		$field = static fn( string $id, string $label, string $value, string $type = 'text', string $auto = '' ) => '<div class="field"><label for="' . $id . '">' . esc_html( $label ) . '</label><div class="input"><input id="' . $id . '" name="' . $id . '" type="' . $type . '" value="' . esc_attr( $value ) . '"' . ( $auto ? ' autocomplete="' . $auto . '"' : '' ) . ' required></div></div>';
		$switch = static fn( string $key, string $label, string $hint, bool $checked ) => '<div class="pref"><div><b id="pf-' . $key . '">' . esc_html( $label ) . '</b><span>' . esc_html( $hint ) . '</span></div>'
			. '<button type="button" class="switch" role="switch" aria-checked="' . ( $checked ? 'true' : 'false' ) . '" aria-labelledby="pf-' . $key . '" data-pref="' . $key . '"><span class="track" aria-hidden="true"></span></button><input type="hidden" name="prefs[' . $key . ']" value="' . ( $checked ? '1' : '0' ) . '"></div>';
		return $msg . '<form class="blk profile-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bidik_profile">' . wp_nonce_field( 'bidik_profile', '_wpnonce', true, false )
			. '<div class="blk-head"><h2>Profile</h2></div><div class="fields">' . $field( 'first_name', 'First name', (string) $u->first_name, 'text', 'given-name' ) . $field( 'last_name', 'Last name', (string) $u->last_name, 'text', 'family-name' )
			. $field( 'display_name', 'Display name', (string) $u->display_name, 'text', 'nickname' ) . $field( 'email', 'Email', (string) $u->user_email, 'email', 'email' ) . '</div>'
			. '<div class="blk-head sub-head"><h2>Email</h2></div>'
			. '<div class="pref"><div><b>Receipts and billing notices</b><span>Always on. We send these when money moves or a payment fails.</span></div><span class="badge badge-neutral">Always on</span></div>'
			. $switch( 'module_open', 'A new module opens', 'One email on the day a module opens for you.', $on( 'module_open' ) )
			. '<div class="form-actions"><button class="btn btn-primary" type="submit">Save changes</button><a class="btn btn-ghost" href="' . esc_url( wp_lostpassword_url( self::url( 'profile' ) ) ) . '">Reset password by email</a></div></form>';
	}

	public static function save_profile(): void {
		if ( ! is_user_logged_in() || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) ), 'bidik_profile' ) ) {
			wp_die( 'That form expired. Go back and try again.', 'Expired', [ 'response' => 403, 'back_link' => true ] );
		}
		$uid   = get_current_user_id();
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$other = $email ? email_exists( $email ) : false;
		if ( ! is_email( $email ) || ( $other && (int) $other !== $uid ) ) {
			wp_safe_redirect( add_query_arg( 'problem', 'email', self::url( 'profile' ) ) );
			exit;
		}
		$res = wp_update_user( [ 'ID' => $uid, 'user_email' => $email, 'first_name' => sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ), 'last_name' => sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ),
			'display_name' => sanitize_text_field( wp_unslash( $_POST['display_name'] ?? '' ) ) ?: $email ] );
		if ( is_wp_error( $res ) ) {
			wp_safe_redirect( add_query_arg( 'problem', 'save', self::url( 'profile' ) ) );
			exit;
		}
		$in = isset( $_POST['prefs'] ) && is_array( $_POST['prefs'] ) ? wp_unslash( $_POST['prefs'] ) : [];
		update_user_meta( $uid, 'bidik_email_prefs', [ 'module_open' => '0' !== ( $in['module_open'] ?? '1' ) ] );
		wp_safe_redirect( add_query_arg( 'saved', '1', self::url( 'profile' ) ) );
		exit;
	}
}
