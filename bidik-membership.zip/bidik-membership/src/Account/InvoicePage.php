<?php
namespace Bidik\Account;

defined( 'ABSPATH' ) || exit;

/** A printable invoice at /bidik-invoice/BDK-2026-000123/. "Print or save as PDF" uses the browser; no PDF library runs on the site. */
final class InvoicePage {
	public static function register(): void {
		add_rewrite_rule( '^bidik-invoice/([A-Z0-9-]+)/?$', 'index.php?bidik_invoice=$matches[1]', 'top' );
		add_filter( 'query_vars', static fn( array $v ): array => array_merge( $v, [ 'bidik_invoice' ] ) );
		add_action( 'template_redirect', [ self::class, 'serve' ] );
	}

	public static function url( string $number ): string {
		return home_url( '/bidik-invoice/' . rawurlencode( $number ) . '/' );
	}

	/** @return array<string,mixed>|null the invoice, only if it belongs to this user (or the user is an administrator) */
	public static function find( string $number, int $user_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_invoices WHERE number = %s", $number ), ARRAY_A );
		if ( ! $row || ! $user_id || ( (int) $row['user_id'] !== $user_id && ! user_can( $user_id, 'manage_options' ) ) ) {
			return null;
		}
		return $row;
	}

	public static function serve(): void {
		$number = (string) get_query_var( 'bidik_invoice' );
		if ( '' === $number ) {
			return;
		}
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( self::url( $number ) ) );
			exit;
		}
		$inv = self::find( $number, get_current_user_id() );
		if ( ! $inv ) {
			wp_die( 'That invoice is not available.', 'Not found', [ 'response' => 404, 'back_link' => true ] );
		}
		nocache_headers();
		header( 'X-Robots-Tag: noindex' );
		header( 'Content-Type: text/html; charset=utf-8' );
		echo self::html( $inv ); // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts
		exit;
	}

	public static function html( array $inv ): string {
		$u     = get_userdata( (int) $inv['user_id'] );
		$meta  = static fn( string $k ) => (string) get_user_meta( (int) $inv['user_id'], 'pmpro_' . $k, true );
		$name  = trim( $meta( 'bfirstname' ) . ' ' . $meta( 'blastname' ) ) ?: ( $u ? $u->display_name : '' );
		$addr  = array_filter( [ $meta( 'baddress1' ), trim( $meta( 'bcity' ) . ' ' . $meta( 'bzipcode' ) ), $meta( 'bstate' ) ] );
		$when  = static fn( ?string $m ) => $m ? ( new \DateTimeImmutable( $m, new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( 'j F Y' ) : '';
		$money = static fn( int $c ) => '$' . number_format( $c / 100, 2 );
		$rows  = '';
		foreach ( (array) json_decode( (string) $inv['line_items'], true ) as $l ) {
			$rows .= '<tr><td>' . esc_html( (string) ( $l['description'] ?? 'Membership' ) ) . '</td><td class="n">' . esc_html( $money( (int) ( $l['amount'] ?? $inv['amount_cents'] ) ) ) . '</td></tr>';
		}
		$paid = 'paid' === $inv['status'];
		return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Invoice ' . esc_html( $inv['number'] ) . '</title><style>'
			. 'body{margin:0;background:#f2f3f1;color:#16191d;font:16px/1.5 "Public Sans",system-ui,-apple-system,"Segoe UI",sans-serif}.sheet{max-width:720px;margin:32px auto;background:#fff;border:1px solid #d6d9d5;border-radius:10px;padding:48px}'
			. 'h1{font:800 28px/1.1 "Schibsted Grotesk","Helvetica Neue",Arial,sans-serif;letter-spacing:-.02em;margin:0 0 4px}.top{display:flex;justify-content:space-between;gap:24px;flex-wrap:wrap;margin-bottom:32px}.brand{font:800 22px "Schibsted Grotesk",Arial,sans-serif}'
			. 'p{margin:0}.muted{color:#4a515a;font-size:14px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:32px}.label{font-size:12px;color:#5c636c;margin-bottom:4px}'
			. 'table{width:100%;border-collapse:collapse}th{text-align:left;font-size:12px;color:#5c636c;padding:0 0 8px;border-bottom:1px solid #d6d9d5}td{padding:12px 0;border-bottom:1px solid #d6d9d5}.n{text-align:right;font-variant-numeric:tabular-nums}'
			. '.total td{border-bottom:0;font-weight:800;font-size:20px;border-top:2px solid #16191d}.badge{display:inline-block;padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600;background:' . ( $paid ? '#e3f1e9;color:#1e6b45' : '#fbebe8;color:#a3261e' ) . '}'
			. '.act{max-width:720px;margin:0 auto 32px;display:flex;gap:12px}button{font-weight:600;font-size:15px;font-family:inherit;padding:11px 18px;border-radius:6px;border:0;background:#1f4e8a;color:#fff;cursor:pointer}a.back{align-self:center;color:#1f4e8a}'
			. '@media print{body{background:#fff}.sheet{border:0;margin:0;padding:0}.act{display:none}}@media(max-width:560px){.sheet{padding:24px;margin:0;border-radius:0}.cols{grid-template-columns:1fr}}</style></head><body>'
			. '<div class="act"><button type="button" onclick="window.print()">Print or save as PDF</button><a class="back" href="' . esc_url( Account::url( 'billing' ) ) . '">Back to billing</a></div>'
			. '<main class="sheet"><div class="top"><div><p class="brand">Bidik</p><p class="muted">A fictional photography school<br>Jl. Kenari 12, Surabaya 60132<br>Demo invoice: no real payment was made</p></div>'
			. '<div style="text-align:right"><h1>Invoice</h1><p class="muted">' . esc_html( $inv['number'] ) . '</p><p style="margin-top:8px"><span class="badge">' . ( $paid ? 'Paid' : 'Unpaid' ) . '</span></p></div></div>'
			. '<div class="cols"><div><p class="label">Billed to</p><p>' . esc_html( $name ) . '</p><p class="muted">' . esc_html( implode( ', ', $addr ) ) . '</p><p class="muted">' . esc_html( $u ? $u->user_email : '' ) . '</p></div>'
			. '<div><p class="label">Issued</p><p>' . esc_html( $when( $inv['created_at'] ) ) . '</p>' . ( $paid ? '<p class="label" style="margin-top:12px">Paid</p><p>' . esc_html( $when( $inv['paid_at'] ) ) . '</p>' : '' ) . '</div></div>'
			. '<table><thead><tr><th>Description</th><th class="n">Amount</th></tr></thead><tbody>' . $rows . '<tr class="total"><td>Total (USD)</td><td class="n">' . esc_html( $money( (int) $inv['amount_cents'] ) ) . '</td></tr></tbody></table></main></body></html>';
	}
}
