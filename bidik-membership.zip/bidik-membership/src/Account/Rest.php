<?php
namespace Bidik\Account;

use Bidik\Billing\Cards;
use Bidik\Billing\Leave;
use Bidik\Billing\PlanChange;

defined( 'ABSPATH' ) || exit;

/** Member-only JSON endpoints behind the plan-change and card windows. Cookie auth + the REST nonce. */
final class Rest {
	public static function register(): void {
		add_action( 'rest_api_init', static function (): void {
			$auth = static fn() => is_user_logged_in();
			register_rest_route( 'bidik/v1', '/plan-change/preview', [ 'methods' => 'GET', 'permission_callback' => $auth, 'callback' => [ self::class, 'preview' ],
				'args' => [ 'level' => [ 'required' => true, 'sanitize_callback' => 'absint' ] ] ] );
			register_rest_route( 'bidik/v1', '/plan-change', [ 'methods' => 'POST', 'permission_callback' => $auth, 'callback' => [ self::class, 'change' ],
				'args' => [ 'level' => [ 'required' => true, 'sanitize_callback' => 'absint' ], 'expected_due' => [ 'required' => true, 'sanitize_callback' => 'absint' ] ] ] );
			register_rest_route( 'bidik/v1', '/plan-change/undo', [ 'methods' => 'POST', 'permission_callback' => $auth, 'callback' => [ self::class, 'undo' ] ] );
			register_rest_route( 'bidik/v1', '/subscription/leave', [ 'methods' => 'GET', 'permission_callback' => $auth, 'callback' => static fn() => self::guard( static fn() => Leave::summary( get_current_user_id() ) ) ] );
			foreach ( [ 'cancel', 'discount', 'pause', 'resume' ] as $verb ) {
				register_rest_route( 'bidik/v1', "/subscription/$verb", [ 'methods' => 'POST', 'permission_callback' => $auth, 'callback' => static fn( \WP_REST_Request $r ) => self::leave( $verb, $r ) ] );
			}
			register_rest_route( 'bidik/v1', '/billing/card', [ 'methods' => 'POST', 'permission_callback' => $auth, 'callback' => [ self::class, 'card' ] ] );
		} );
	}

	private static function fail( \DomainException $e ): \WP_Error {
		return new \WP_Error( 'bidik_refused', $e->getMessage(), [ 'status' => 422 ] );
	}

	/** @param callable():mixed $fn */
	private static function guard( callable $fn ) {
		try {
			return $fn();
		} catch ( \DomainException $e ) {
			return self::fail( $e );
		}
	}

	private static function leave( string $verb, \WP_REST_Request $r ) {
		return self::guard( static function () use ( $verb, $r ) {
			$uid     = get_current_user_id();
			$reason  = sanitize_key( (string) $r->get_param( 'reason' ) );
			$comment = sanitize_textarea_field( (string) $r->get_param( 'comment' ) );
			match ( $verb ) {
				'cancel'   => Leave::cancel( $uid, $reason, $comment, sanitize_key( (string) $r->get_param( 'offer_shown' ) ) ),
				'discount' => Leave::accept_discount( $uid, $reason, $comment ),
				'pause'    => Leave::pause( $uid, (int) $r->get_param( 'months' ), $reason, $comment ),
				'resume'   => Leave::resume( $uid ),
			};
			return [ 'ok' => true, 'redirect' => add_query_arg( [ 'view' => 'billing', 'left' => $verb ], (string) get_permalink( (int) get_option( 'pmpro_account_page_id' ) ) ) ];
		} );
	}

	public static function preview( \WP_REST_Request $r ) {
		try {
			return PlanChange::describe( PlanChange::quote( get_current_user_id(), (int) $r['level'] ) );
		} catch ( \DomainException $e ) {
			return self::fail( $e );
		}
	}

	public static function change( \WP_REST_Request $r ) {
		try {
			$q = PlanChange::apply( get_current_user_id(), (int) $r['level'], (int) $r['expected_due'] );
			return [ 'ok' => true, 'kind' => $q['kind'], 'redirect' => add_query_arg( [ 'view' => 'billing', 'changed' => $q['kind'] ], (string) get_permalink( (int) get_option( 'pmpro_account_page_id' ) ) ) ];
		} catch ( \DomainException $e ) {
			return self::fail( $e );
		}
	}

	public static function undo() {
		try {
			PlanChange::undo( get_current_user_id() );
			return [ 'ok' => true ];
		} catch ( \DomainException $e ) {
			return self::fail( $e );
		}
	}

	public static function card( \WP_REST_Request $r ) {
		try {
			$res = Cards::update( get_current_user_id(), (string) $r->get_param( 'number' ), (string) $r->get_param( 'exp' ), (string) $r->get_param( 'cvc' ) );
			return [ 'ok' => true, 'retried' => $res['retried'] ];
		} catch ( \DomainException $e ) {
			return self::fail( $e );
		}
	}
}
