<?php
namespace Bidik;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * Site chrome and the home page (S01): header, footer and [bidik_home].
 * Everything links through get_permalink()/home_url(), never a hard-coded path, so the site also works
 * when WordPress Playground serves it from a sub-path.
 */
final class Chrome {
	public const BRAND_MARK = '<svg viewBox="0 0 28 28" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M3 9V3h6M19 3h6v6M25 19v6h-6M9 25H3v-6"/></g><circle cx="14" cy="14" r="4" fill="#1f4e8a"/></svg>';

	/** @var array<string,string>|null */
	private static ?array $icons = null;

	public static function register(): void {
		add_shortcode( 'bidik_header', [ self::class, 'header' ] );
		add_shortcode( 'bidik_footer', [ self::class, 'footer' ] );
		add_shortcode( 'bidik_home', [ self::class, 'home' ] );
		add_filter( 'gettext', [ self::class, 'checkout_copy' ], 10, 3 );
		add_filter( 'pmpro_level_cost_text', [ self::class, 'cost_text' ], 10, 2 );
		add_filter( 'login_headerurl', static fn() => home_url( '/' ) );
		add_filter( 'login_headertext', static fn() => 'Bidik' );
		add_action( 'login_enqueue_scripts', [ self::class, 'login_style' ] );
	}

	/** Plain-language labels for PMPro's checkout. */
	public static function checkout_copy( string $text, string $original, string $domain ): string {
		if ( 'paid-memberships-pro' !== $domain ) {
			return $text;
		}
		static $map = [
			'Membership Information' => 'Your plan',
			'Account Information'    => 'Create your account',
			'Payment Information'    => 'Card',
			'Submit and Check Out'   => 'Start my membership',
		];
		return $map[ $original ] ?? $text;
	}

	/**
	 * PMPro words a free-first-payment level as "$0 now, then $12 per Month", which reads as a free month.
	 * Bidik's trial is days, so say that (the billing date itself comes from the subscription, M2).
	 */
	public static function cost_text( string $text, $level ): string {
		$days = (int) get_pmpro_membership_level_meta( (int) ( $level->id ?? 0 ), 'bidik_trial_days', true );
		if ( $days > 0 && (float) $level->billing_amount > 0 ) {
			$per = 'Year' === $level->cycle_period ? 'year' : 'month';
			return '<strong>' . esc_html( $days ) . ' days free</strong>, then <strong>$' . esc_html( number_format( (float) $level->billing_amount, 2 ) ) . ' per ' . $per . '</strong>. Cancel any time before the trial ends and you pay nothing.';
		}
		return $text;
	}

	/** The WordPress login screen, in Bidik's colours. */
	public static function login_style(): void {
		$font = esc_url( get_theme_file_uri( 'assets/fonts/public-sans-latin-wght-normal.woff2' ) );
		$mark = 'data:image/svg+xml,' . rawurlencode( str_replace( 'currentColor', '#16191d', self::BRAND_MARK ) );
		$mark = str_replace( '<svg ', '<svg xmlns="http://www.w3.org/2000/svg" ', rawurldecode( $mark ) );
		$mark = 'data:image/svg+xml,' . rawurlencode( substr( $mark, strlen( 'data:image/svg+xml,' ) ) );
		echo '<style>
@font-face{font-family:"Public Sans";src:url("' . $font . '") format("woff2");font-weight:100 900;font-display:swap}
body.login{background:#f2f3f1;font-family:"Public Sans",system-ui,sans-serif;color:#16191d}
.login h1{margin-bottom:24px}
body.login div#login h1 a{display:block;width:auto;height:32px;margin:0 auto;padding-left:38px;background:url("' . $mark . '") no-repeat left center/28px 28px!important;text-indent:0!important;font:800 1.5rem/32px "Public Sans",sans-serif;letter-spacing:-.02em;color:#16191d;width:fit-content}
.login form{border:1px solid #d6d9d5;border-radius:10px;box-shadow:none;background:#fff;padding:24px}
.login label{font-weight:600;font-size:14px;color:#16191d}
.login form .input,.login input[type=text],.login input[type=password]{min-height:44px;border:1px solid #b9bdb8;border-radius:6px;box-shadow:none;font-size:16px;padding:0 12px}
.login form .input:focus,.login input[type=text]:focus,.login input[type=password]:focus{border-color:#1f4e8a;box-shadow:0 0 0 3px #e4ebf5;outline:0}
.login .button.wp-hide-pw{color:#4a515a}
body.login .wp-core-ui .button-primary,body.login .button-primary{background:#1f4e8a!important;border-color:#1f4e8a!important;border-radius:6px;font-weight:600;min-height:42px;padding:0 18px;text-shadow:none;box-shadow:none}
body.login .button-primary:hover,body.login .button-primary:focus{background:#163b69!important;border-color:#163b69!important}
.login #nav a,.login #backtoblog a{color:#1f4e8a;text-underline-offset:3px}
.login input[type=checkbox]:checked::before{filter:none}
.login .message,.login .notice{border-left-color:#1f4e8a;border-radius:0 6px 6px 0}
</style>';
	}

	public static function icon( string $name, string $class = 'icon', string $label = '' ): string {
		self::$icons ??= require __DIR__ . '/icons.php';
		$aria = $label ? ' role="img" aria-label="' . esc_attr( $label ) . '"' : ' aria-hidden="true"';
		return '<svg class="' . esc_attr( $class ) . '" viewBox="0 0 24 24"' . $aria . '>' . ( self::$icons[ $name ] ?? '' ) . '</svg>';
	}

	private static function page_url( string $slug ): string {
		$id = (int) get_option( "pmpro_{$slug}_page_id" );
		return $id ? (string) get_permalink( $id ) : home_url( '/' );
	}

	private static function trial_url(): string {
		$levels = Pricing::levels();
		$id     = $levels['member']['month']['id'] ?? 0;
		return $id ? add_query_arg( 'pmpro_level', $id, self::page_url( 'checkout' ) ) : self::page_url( 'levels' );
	}

	/** A payment is overdue: say so on every page (the member can dismiss it for this visit). Billing itself already shows the full notice. */
	private static function banner(): string {
		$uid = get_current_user_id();
		$sub = $uid ? \Bidik\Billing\PlanChange::subscription( $uid ) : null;
		if ( ! $sub || 'past_due' !== $sub['status'] || ( isset( $_GET['view'] ) && 'billing' === $_GET['view'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return '';
		}
		$plan = \Bidik\Billing\PlanChange::level( (int) $sub['level_id'] );
		$by   = ( new \DateTimeImmutable( (string) $sub['grace_until'], new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( 'D j M' );
		return '<div class="bd-banner" role="status" data-bd-banner><p>' . self::icon( 'triangle-alert', 'icon sm' ) . '<span>Your payment didn\'t go through. Update your card by <b>' . esc_html( $by ) . '</b> to keep ' . esc_html( ucfirst( $plan['tier'] ) ) . '.</span></p>'
			. '<a class="btn btn-secondary" href="' . esc_url( \Bidik\Account\Account::url( 'billing' ) ) . '">Update card</a>'
			. '<button type="button" class="icon-btn" data-bd-banner-close aria-label="Dismiss this notice">' . self::icon( 'x', 'icon sm' ) . '</button></div>';
	}

	public static function header(): string {
		$current = (int) get_queried_object_id();
		$pages   = [ 'Courses' => (int) get_option( 'bidik_page_courses' ), 'Library' => (int) get_option( 'bidik_page_library' ), 'Pricing' => (int) get_option( 'pmpro_levels_page_id' ), 'Account' => (int) get_option( 'pmpro_account_page_id' ) ];
		$in      = [ 'Courses' => is_singular( [ \Bidik\Content\PostTypes::COURSE, \Bidik\Content\PostTypes::LESSON ] ), 'Library' => is_singular( \Bidik\Content\PostTypes::ARTICLE ) ];
		$nav     = '';
		foreach ( $pages as $label => $id ) {
			if ( ! $id ) {
				continue;
			}
			$is   = ( $current && $current === $id ) || ! empty( $in[ $label ] );
			$nav .= '<a href="' . esc_url( (string) get_permalink( $id ) ) . '"' . ( $is ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		if ( is_user_logged_in() ) {
			$u       = wp_get_current_user();
			$initial = strtoupper( mb_substr( $u->display_name ?: $u->user_login, 0, 1 ) );
			$end     = '<a class="bd-who" href="' . esc_url( self::page_url( 'account' ) ) . '"><span class="bd-avatar" aria-hidden="true">' . esc_html( $initial ) . '</span><span>' . esc_html( $u->display_name ) . '</span></a>';
		} else {
			$end = '<a class="btn btn-ghost" href="' . esc_url( wp_login_url() ) . '">Log in</a><a class="btn btn-primary" href="' . esc_url( self::trial_url() ) . '">Start free trial</a>';
		}
		return self::banner() . '<div class="bd-header"><div class="bd-header__in">'
			. '<a class="bd-brand" href="' . esc_url( home_url( '/' ) ) . '">' . self::BRAND_MARK . '<span>Bidik</span></a>'
			. '<nav class="bd-nav" aria-label="Main">' . $nav . '</nav>'
			. '<div class="bd-header__end">' . $end . '</div></div></div>';
	}

	public static function footer(): string {
		return '<div class="bd-footer"><div class="bd-footer__in">'
			. '<div class="bd-footer__brand"><a class="bd-brand" href="' . esc_url( home_url( '/' ) ) . '">' . self::BRAND_MARK . '<span>Bidik</span></a>'
			. '<p>A fictional photography school. Every member, price and invoice on this site is synthetic demo data.</p></div>'
			. '<nav class="bd-footer__links" aria-label="Footer"><a href="' . esc_url( (string) get_permalink( (int) get_option( 'bidik_page_courses' ) ) ) . '">Courses</a><a href="' . esc_url( (string) get_permalink( (int) get_option( 'bidik_page_library' ) ) ) . '">Library</a><a href="' . esc_url( self::page_url( 'levels' ) ) . '">Pricing</a><a href="' . esc_url( self::page_url( 'account' ) ) . '">Account</a></nav>'
			. '<p class="bd-footer__credit">Photos by Firmansyah Chandra, Matthew T Rader, Basile Morin and Tobias ToMar Maier, <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a>, via Wikimedia Commons.</p>'
			. '</div></div>';
	}

	private static function img( string $file ): string {
		return plugins_url( 'assets/img/' . $file, BIDIK_FILE );
	}

	public static function home(): string {
		wp_enqueue_style( 'bidik-home', plugins_url( 'assets/home.css', BIDIK_FILE ), [ 'bidik-site' ], (string) filemtime( dirname( __DIR__ ) . '/assets/home.css' ) );
		$trial   = esc_url( self::trial_url() );
		$pricing = esc_url( self::page_url( 'levels' ) );
		$tz      = wp_timezone();
		$frames  = [
			[ '05', 'Planning the 40 minutes', '10 min', 'done' ],
			[ '06', 'Backlight without losing the face', '13 min', 'done' ],
			[ '07', 'Reading the histogram outdoors', '11 min', 'current' ],
			[ '08', 'Blue hour on a tripod', '14 min', 'open' ],
			[ '10', 'One window, three looks', '12 min', 'drip' ],
		];
		$rows = '';
		foreach ( $frames as [ $no, $title, $dur, $state ] ) {
			$st  = [ 'done' => self::icon( 'circle-check', 'icon sm st', 'Completed' ), 'current' => self::icon( 'play', 'icon sm st', 'Now playing' ),
				'open' => '', 'drip' => self::icon( 'lock', 'icon sm st', 'Locked until the module opens' ) ][ $state ];
			$sub = 'drip' === $state ? 'Opens in 4 days' : esc_html( $dur ); // an example, not the visitor's own list
			$rows .= '<li class="bs-frame bs-' . $state . '"' . ( 'current' === $state ? ' aria-current="true"' : '' ) . '><span class="bs-no">' . $no . '</span><span class="bs-t">' . esc_html( $title ) . '<small>' . $sub . '</small></span>' . $st . '</li>';
		}
		$cards = '';
		foreach ( \Bidik\Courses\Catalog::courses() as $i => $c ) {
			$st   = \Bidik\Courses\Catalog::structure( $c->ID );
			$pro  = 2 === \Bidik\Courses\Catalog::course_rank( $c->ID );
			$meta = count( $st['lessons'] ) . ' lessons · ' . \Bidik\Courses\Catalog::duration( $st['minutes'] );
			$cards .= '<article class="bc-course ' . ( 0 === $i ? 'lg' : '' ) . '"><img src="' . esc_url( \Bidik\Content\PostTypes::cover( $c, 'medium_large' ) ) . '" alt="" loading="lazy" width="900" height="600">'
				. '<div class="bc-course__body"><span class="badge ' . ( $pro ? 'badge-amber' : 'badge-cyan' ) . '">' . ( $pro ? 'Pro' : 'Member' ) . '</span>'
				. '<h3><a href="' . esc_url( (string) get_permalink( $c ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a></h3><p>' . esc_html( (string) \Bidik\Content\PostTypes::meta( $c->ID, 'summary', '' ) ) . '</p><span class="bc-meta">' . esc_html( $meta ) . '</span></div></article>';
		}
		$rules = [
			[ 'Locked means explained.', 'A lesson you can\'t open says why, whether that is your plan or a date, and what opening it costs today.' ],
			[ 'Upgrades show the bill first.', 'Going from Member to Pro, you see the credit for the days you didn\'t use and the exact amount due before you confirm.' ],
			[ 'A failed card is not the end.', 'You keep access for 7 days, we email you on day 0, 3 and 6, and one tap on Update card puts things right.' ],
			[ 'Leaving is a short conversation.', 'Pause for up to three months, take a discount if price is the reason, or cancel and keep access until the period ends.' ],
		];
		$list = '';
		foreach ( $rules as [ $lead, $body ] ) {
			$list .= '<div><dt>' . esc_html( $lead ) . '</dt><dd>' . esc_html( $body ) . '</dd></div>';
		}
		return '<div class="bh">'
			. '<section class="bh-hero"><div class="bh-hero__copy"><h1>Learn to see light, one module a week.</h1>'
			. '<p class="bh-lead">Photography lessons built around real files you can open. A new module opens every week, and you can always see which one and when.</p>'
			. '<div class="bh-cta"><a class="btn btn-primary lg" href="' . $trial . '">Start 7-day trial</a><a class="btn btn-secondary lg" href="' . $pricing . '">Compare plans</a></div>'
			. '<p class="bh-fine">7 days free, then $12 a month. Cancel any time.</p></div>'
			. '<div class="bh-hero__stage"><img src="' . esc_url( self::img( 'golden-hour-savanna.jpg' ) ) . '" alt="A savanna at golden hour, acacia trees backlit by a low sun" width="1200" height="800">'
			. '<aside class="bs" aria-label="Example lesson list"><div class="bs-head"><b>Light, Explained</b><span>Module 2 · 7 of 18 done</span></div><ol class="bs-frames">' . $rows . '</ol></aside></div></section>'
			. '<section class="bh-courses" aria-labelledby="h-courses"><h2 id="h-courses">Three courses, one library</h2><div class="bc-grid">' . $cards . '</div></section>'
			. '<section class="bh-rules" aria-labelledby="h-rules"><div class="bh-rules__lead"><h2 id="h-rules">What you can count on</h2><p>Membership sites usually hide the rules until something goes wrong. Bidik says them first.</p></div><dl>' . $list . '</dl></section>'
			. '<section class="bh-close"><div><h2>Start with a free week of Member.</h2><p>Open the first modules, download the practice files, and decide after seven days.</p></div>'
			. '<a class="btn btn-primary lg" href="' . $trial . '">Start 7-day trial</a></section></div>';
	}
}
