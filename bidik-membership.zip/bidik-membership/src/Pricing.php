<?php
namespace Bidik;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * [bidik_pricing]: the pricing page (F1). Reads the Free/Member/Pro levels from PMPro by their
 * bidik_tier / bidik_interval meta, so prices are never typed twice.
 */
final class Pricing {
	private const ICONS = [
		'check' => '<path d="M20 6 9 17l-5-5"/>',
		'gift'  => '<path d="M12 7v14"/><path d="M20 11v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8"/><path d="M7.5 7a1 1 0 0 1 0-5A4.8 8 0 0 1 12 7a4.8 8 0 0 1 4.5-5 1 1 0 0 1 0 5"/><rect x="3" y="7" width="18" height="4" rx="1"/>',
		'minus' => '<path d="M5 12h14"/>',
		'lock'  => '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
	];

	private const PLANS = [
		'free'   => [ 'name' => 'Free', 'note' => 'Read the open half of the library.', 'cta' => 'Join free', 'kind' => 'secondary', 'foot' => 'No card needed.',
			'cover' => [ 'mekong-golden-hour.jpg', 'First lesson of every course', 'Free, no card' ],
			'items' => [ '12 open articles and field guides', 'First lesson of every course', 'Monthly newsletter', 'Upgrade any time from your account' ] ],
		'member' => [ 'name' => 'Member', 'note' => '7 days free, then {price}. Cancel any time.', 'cta' => 'Start 7-day trial', 'kind' => 'primary', 'foot' => 'No charge until day 8. Cancel before then and you pay nothing.',
			'cover' => [ 'golden-hour-savanna.jpg', 'Light, Explained', '18 lessons · 3 h 40 m' ],
			'items' => [ 'Full library: 24 articles', 'Course: Light, Explained', 'Course: Composition Without Rules', 'New module every week', 'Lesson notes and practice files' ] ],
		'pro'    => [ 'name' => 'Pro', 'note' => 'Everything open from day one.', 'cta' => 'Go Pro', 'kind' => 'secondary', 'foot' => 'Already a Member? You pay only for the days left in your period.',
			'cover' => [ 'milky-way-copper-breaks.jpg', 'Night & Astro', '10 lessons · 2 h 05 m' ],
			'items' => [ 'Everything in Member', 'Course: Night & Astro', 'All modules unlocked, no weekly wait', 'Preset pack: 24 Lightroom presets', 'Monthly photo critique thread' ] ],
	];

	/** Grouped rows: [label, free, member, pro]. 'yes' and 'no' draw a tick or a dash; any other text is shown as is. */
	private const COMPARE = [
		'Library' => [
			[ 'Articles and field guides', '12', '24', '24' ],
		],
		'Courses' => [
			[ 'Light, Explained · 18 lessons', 'Lesson 1', 'yes', 'yes' ],
			[ 'Composition Without Rules · 12 lessons', 'Lesson 1', 'yes', 'yes' ],
			[ 'Night & Astro · 10 lessons', 'Lesson 1', 'no', 'yes' ],
		],
		'Schedule' => [
			[ 'When modules open', 'no', 'One a week', 'All at once' ],
		],
		'Extras' => [
			[ 'Practice files', 'no', 'yes', 'yes' ],
			[ 'Lightroom preset pack · 24 presets', 'no', 'no', 'yes' ],
			[ 'Monthly photo critique thread', 'no', 'no', 'yes' ],
		],
	];

	/**
	 * Phone version of the comparison: the plans are nested (Free in Member in Pro), so list only what each step adds.
	 * Labels of rows that COMPARE marks 'yes' are reused verbatim; integration.php checks that none is missing.
	 */
	private const LADDER = [
		'free'   => [ 'Free', 'What you get', [ '12 open articles and field guides', 'Lesson 1 of every course', 'Monthly newsletter' ] ],
		'member' => [ 'Member', 'Everything in Free, plus', [ '12 more articles, 24 in all', 'Light, Explained · 18 lessons', 'Composition Without Rules · 12 lessons', 'One new module a week', 'Practice files' ] ],
		'pro'    => [ 'Pro', 'Everything in Member, plus', [ 'Night & Astro · 10 lessons', 'Every module open from day one', 'Lightroom preset pack · 24 presets', 'Monthly photo critique thread' ] ],
	];

	private const FAQ = [
		[ 'Can I cancel?', 'Yes, from your account in two clicks. You keep access until the end of the period you paid for.' ],
		[ 'What happens when I upgrade?', 'Pro opens immediately. You pay only for the days left in your current period, and we show the exact amount before you confirm.' ],
		[ 'Can I pause instead?', 'Pause for 1, 2 or 3 months. Billing stops, your progress stays, and the weekly schedule waits for you.' ],
		[ 'What if my card fails?', 'You keep access for 7 days while you update it. We email you on day 0, 3 and 6.' ],
	];

	public static function register(): void {
		add_shortcode( 'bidik_pricing', [ self::class, 'render' ] );
	}

	private static function icon( string $name, string $label = '' ): string {
		$aria = $label ? ' role="img" aria-label="' . esc_attr( $label ) . '"' : ' aria-hidden="true"';
		return '<svg class="icon sm" viewBox="0 0 24 24"' . $aria . '>' . self::ICONS[ $name ] . '</svg>';
	}

	/** @return array<string, array<string, array{id:int, amount:float}>> tier => interval => level */
	public static function levels(): array {
		$out = [];
		foreach ( pmpro_getAllLevels( false, false, true ) as $level ) {
			$tier     = get_pmpro_membership_level_meta( (int) $level->id, 'bidik_tier', true );
			$interval = get_pmpro_membership_level_meta( (int) $level->id, 'bidik_interval', true );
			if ( $tier && $interval ) {
				$out[ $tier ][ $interval ] = [ 'id' => (int) $level->id, 'amount' => (float) $level->billing_amount ];
			}
		}
		return $out;
	}

	private static function money( float $n ): string {
		return '$' . ( floor( $n ) == $n ? number_format( $n ) : number_format( $n, 2 ) );
	}

	private static function checkout_url( int $level_id ): string {
		return add_query_arg( 'pmpro_level', $level_id, get_permalink( (int) get_option( 'pmpro_checkout_page_id' ) ) );
	}


	/** "How the weeks work": the contact-sheet motif, showing when each module opens for Member and for Pro. */
	private static function drip(): string {
		$tz   = wp_timezone();
		$next = ( new \DateTimeImmutable( '@' . Clock::now() ) )->setTimezone( $tz )->modify( 'next thursday' );
		$mods = [ [ 'Seeing light', 'open' ], [ 'Golden hour & blue hour', 'now' ], [ 'Window light portraits', 0 ], [ 'Mixed light at night', 7 ] ];
		$row  = static function ( bool $pro ) use ( $mods, $next ): string {
			$out = '';
			foreach ( $mods as $i => [ $title, $state ] ) {
				$cls = 'open';
				$sub = 'Open';
				if ( ! $pro && is_int( $state ) ) {
					$cls = 'drip';
					$sub = 'Opens ' . $next->modify( "+$state days" )->format( 'D j M' );
				} elseif ( ! $pro && 'now' === $state ) {
					$cls = 'now';
					$sub = 'Open now';
				}
				$icon = 'drip' === $cls ? self::icon( 'lock', 'Locked until it opens' ) : self::icon( 'check', 'Open' );
				$out .= '<li class="df df-' . $cls . '"><span class="df-no">Week ' . ( $i + 1 ) . '</span><span class="df-t">' . esc_html( $title ) . '</span><span class="df-s">' . $icon . esc_html( $sub ) . '</span></li>';
			}
			return $out;
		};
		return '<section class="drip" aria-labelledby="drip-h"><div class="drip-head"><h2 id="drip-h">How the weeks work</h2>'
			. '<p>Light, Explained has six modules. Member opens one a week from the day you join. Pro opens them all at once.</p></div>'
			. '<div class="drip-row"><h3>Member</h3><ol class="drip-frames">' . $row( false ) . '</ol></div>'
			. '<div class="drip-row"><h3>Pro</h3><ol class="drip-frames">' . $row( true ) . '</ol></div></section>';
	}

	/** @param array<string,array<string,array{id:int,amount:float}>> $levels */
	private static function ladder( array $levels ): string {
		$out = '';
		foreach ( self::LADDER as $key => [ $name, $lead, $items ] ) {
			$m = $levels[ $key ]['month']['amount'] ?? null;
			$y = $levels[ $key ]['year']['amount'] ?? null;
			if ( null === $m || 0.0 === (float) $m ) {
				$price = '$0 forever';
			} else {
				$price = '<span data-interval-view="month">' . esc_html( self::money( (float) $m ) ) . ' a month</span>'
					. ( null !== $y ? '<span data-interval-view="year" hidden>' . esc_html( self::money( (float) $y ) ) . ' a year</span>' : '' );
			}
			$li = '';
			foreach ( $items as $item ) {
				[ $label, $meta ] = array_pad( explode( ' · ', $item, 2 ), 2, '' );
				$li .= '<li><span class="tick" role="img" aria-label="Included">' . self::icon( 'check' ) . '</span><span class="txt">' . esc_html( $label )
					. ( '' !== $meta ? '<span class="meta">' . esc_html( $meta ) . '</span>' : '' ) . '</span></li>';
			}
			$out .= '<li class="step step-' . esc_attr( $key ) . '"><div class="step-head"><h3>' . esc_html( $name ) . '</h3><p class="step-price">' . $price . '</p></div>'
				. '<p class="step-lead">' . esc_html( $lead ) . '</p><ul>' . $li . '</ul></li>';
		}
		return '<ol class="ladder" aria-label="What each plan adds">' . $out . '</ol>';
	}

	public static function render(): string {
		if ( ! function_exists( 'pmpro_getAllLevels' ) ) {
			return '';
		}
		wp_enqueue_style( 'bidik-pricing', plugins_url( 'assets/pricing.css', BIDIK_FILE ), [], '0.1.0' );
		wp_enqueue_script( 'bidik-pricing', plugins_url( 'assets/pricing.js', BIDIK_FILE ), [], '0.1.0', true );

		$levels = self::levels();
		$uid    = get_current_user_id();
		$cur    = $uid ? \Bidik\Billing\PlanChange::current( $uid ) : null;   // a member with a subscription gets plan-change buttons, not checkout links
		$ctx    = \Bidik\Content\Members::context( $uid ?: null );
		if ( $cur ) {
			\Bidik\Account\Account::assets();
		}
		$cols   = '';
		foreach ( self::PLANS as $key => $p ) {
			$m = $levels[ $key ]['month'] ?? null;
			$y = $levels[ $key ]['year'] ?? null;
			if ( 'free' === $key ) {
				$free = pmpro_getAllLevels( false, false, true );
				foreach ( $free as $l ) {
					if ( 'free' === get_pmpro_membership_level_meta( (int) $l->id, 'bidik_tier', true ) ) {
						$m = [ 'id' => (int) $l->id, 'amount' => 0.0 ];
					}
				}
			}
			if ( ! $m ) {
				continue;
			}
			$price_m = self::money( $m['amount'] );
			$price_y = $y ? self::money( $y['amount'] ) : '';
			$note    = str_replace( '{price}', $price_m . ' a month', $p['note'] );
			$note_y  = str_replace( '{price}', $price_y . ' a year', $p['note'] );
			$badge   = 'member' === $key ? '<span class="badge badge-cyan">' . self::icon( 'gift' ) . '7-day free trial</span>' : '';
			$here    = $cur ? $cur['tier'] === $key : ( 'free' === $key && $uid && 0 === $ctx['rank'] );
			if ( $here ) {
				$badge = '<span class="badge badge-neutral">' . self::icon( 'check' ) . 'Your plan</span>';
			}
			$cover   = '';
			if ( ! empty( $p['cover'] ) ) {
				[ $img, $title, $meta ] = $p['cover'];
				$cover = '<figure class="plan-cover"><img src="' . esc_url( plugins_url( 'assets/img/' . $img, BIDIK_FILE ) ) . '" alt="" loading="lazy" width="600" height="262"><figcaption><b>' . esc_html( $title ) . '</b><span>' . esc_html( $meta ) . '</span></figcaption></figure>';
			}
			$items = '';
			foreach ( $p['items'] as $it ) {
				$items .= '<li>' . self::icon( 'check' ) . '<span>' . esc_html( $it ) . '</span></li>';
			}
			$cta_m = self::cta( $key, 'month', $m, $p, $cur, $uid, $ctx, $levels );
			$cta_y = $y ? self::cta( $key, 'year', $y, $p, $cur, $uid, $ctx, $levels ) : $cta_m;
			$per_m = $m['amount'] > 0 ? 'per month' : 'forever';
			$yr_m  = $y ? '<span class="yr">or ' . esc_html( $price_y ) . ' a year</span>' : '<span class="yr">&nbsp;</span>';
			$yr_y  = $y ? '<span class="yr">' . esc_html( self::money( $y['amount'] / 12 ) ) . ' a month, billed yearly</span>' : '<span class="yr">&nbsp;</span>';
			$cols .= '<section class="plan plan-' . esc_attr( $key ) . ( $here ? ' is-current' : '' ) . '" aria-labelledby="pl-' . esc_attr( $key ) . '">' . $cover . '<div class="plan-body">'
				. '<div class="plan-top"><h2 id="pl-' . esc_attr( $key ) . '">' . esc_html( $p['name'] ) . '</h2>' . $badge . '</div>'
				. '<div data-interval-view="month"><p class="price"><span class="amt">' . esc_html( $price_m ) . '</span><span class="per">' . esc_html( $per_m ) . '</span></p>' . $yr_m . '<p class="plan-note">' . esc_html( $note ) . '</p>' . $cta_m . '</div>'
				. '<div data-interval-view="year" hidden><p class="price"><span class="amt">' . esc_html( $y ? $price_y : $price_m ) . '</span><span class="per">' . esc_html( $y ? 'per year' : $per_m ) . '</span></p>' . $yr_y . '<p class="plan-note">' . esc_html( $y ? $note_y : $note ) . '</p>' . $cta_y . '</div>'
				. '<ul class="unlocks">' . $items . '</ul><p class="plan-foot">' . esc_html( $p['foot'] ) . '</p></div></section>';
		}

		$cell = static function ( string $v, string $col ): string {
			if ( 'yes' === $v ) {
				return '<td class="col-' . $col . '"><span class="tick" role="img" aria-label="Included">' . self::icon( 'check' ) . '</span></td>';
			}
			if ( 'no' === $v ) {
				return '<td class="col-' . $col . '"><span class="dash" role="img" aria-label="Not included">' . self::icon( 'minus' ) . '</span></td>';
			}
			return '<td class="col-' . $col . '"><span class="val">' . esc_html( $v ) . '</span></td>';
		};
		$rows = '';
		foreach ( self::COMPARE as $group => $items ) {
			$rows .= '<tr class="grp"><th scope="rowgroup">' . esc_html( $group ) . '</th><td class="col-free"></td><td class="col-member"></td><td class="col-pro"></td></tr>';
			foreach ( $items as [ $label, $f, $m, $pr ] ) {
				[ $name, $meta ] = array_pad( explode( ' · ', $label, 2 ), 2, '' );
				$rows .= '<tr><th scope="row"><span class="name">' . esc_html( $name ) . '</span>' . ( '' !== $meta ? '<span class="meta">' . esc_html( $meta ) . '</span>' : '' ) . '</th>' . $cell( $f, 'free' ) . $cell( $m, 'member' ) . $cell( $pr, 'pro' ) . '</tr>';
			}
		}
		$price = static fn( string $tier ): string => isset( $levels[ $tier ]['month'] ) ? esc_html( self::money( $levels[ $tier ]['month']['amount'] ) ) . '<i class="per"> a month</i>' : 'Free';
		$faq = '';
		foreach ( self::FAQ as [ $q, $a ] ) {
			$faq .= '<div><dt>' . esc_html( $q ) . '</dt><dd>' . esc_html( $a ) . '</dd></div>';
		}

		[ $h1, $lead ] = self::heading( $cur, $uid );
		return '<div class="bidik-pricing"><div class="pr-head"><h1>' . esc_html( $h1 ) . '</h1>'
			. '<p class="lead">' . $lead . '</p></div>'
			. '<div class="pr-bar"><p>Pick a plan. Switch or cancel any time.</p>'
			. '<div class="seg" role="radiogroup" aria-label="Billing interval"><button type="button" role="radio" aria-checked="true" tabindex="0" data-interval="month">Monthly</button>'
			. '<button type="button" role="radio" aria-checked="false" tabindex="-1" data-interval="year">Yearly <span class="save">2 months free</span></button></div></div>'
			. '<div class="plans">' . $cols . '</div>'
			. self::drip()
			. '<section class="compare" aria-labelledby="cmp"><div class="cmp-head"><h2 id="cmp">What each plan opens</h2></div>'
			. '<div class="cmp"><table><thead><tr><th scope="col"><span class="sr">What is included</span></th>'
			. '<th scope="col" class="col-free"><b>Free</b><span>' . $price( 'free' ) . '</span></th><th scope="col" class="col-member"><b>Member</b><span>' . $price( 'member' ) . '</span></th>'
			. '<th scope="col" class="col-pro"><b>Pro</b><span>' . $price( 'pro' ) . '</span></th></tr></thead><tbody>' . $rows . '</tbody></table></div>' . self::ladder( $levels ) . '</section>'
			. '<section class="faq" aria-labelledby="faq"><h2 id="faq">Billing, plainly</h2><dl>' . $faq . '</dl></section></div>' . ( $cur ? \Bidik\Account\Account::dialog_shell() : '' );
	}

	/** @return array{0:string,1:string} headline and lead (the lead may hold markup that is already escaped) */
	private static function heading( ?array $cur, int $uid ): array {
		if ( ! $cur ) {
			return [ 'Learn photography one module at a time.', 'Courses on light, composition and night skies, taught with real files you can open. Start with a free week of Member.' ];
		}
		$sub  = \Bidik\Billing\PlanChange::subscription( $uid );
		$lvl  = \Bidik\Billing\PlanChange::level( $cur['level_id'] );
		$date = static fn( ?string $m ) => $m ? ( new \DateTimeImmutable( $m, new \DateTimeZone( 'UTC' ) ) )->setTimezone( wp_timezone() )->format( 'j M Y' ) : '';
		$paying = '$' . number_format( \Bidik\Billing\MembershipSync::price_for( $uid, $cur['level_id'] ), 2 );
		$lead = match ( $cur['status'] ) {
			'trialing' => 'Your trial ends on <b>' . esc_html( $date( $sub['trial_end'] ) ) . '</b>. Change plan now and nothing is charged until then.',
			'past_due' => 'Your last payment did not go through. <a href="' . esc_url( \Bidik\Account\Account::url( 'billing' ) ) . '">Update your card</a> to change plan.',
			default    => 'Renews on <b>' . esc_html( $date( $sub['current_period_end'] ) ) . '</b> for ' . esc_html( $paying ) . '. Upgrades start today and you only pay for the days left.',
		};
		return [ 'Your plan: ' . $lvl['name'], $lead ];
	}

	/** One plan button. A member gets a window with the exact price; everyone else gets the checkout. */
	private static function cta( string $key, string $interval, array $lvl, array $p, ?array $cur, int $uid, array $ctx, array $levels ): string {
		$kind = $p['kind'];
		if ( ! $cur ) {
			if ( 'free' === $key && $uid && 0 === $ctx['rank'] ) {
				return '<span class="btn btn-secondary block" aria-disabled="true">Your plan</span>';
			}
			return '<a class="btn btn-' . esc_attr( $kind ) . ' block" href="' . esc_url( self::checkout_url( $lvl['id'] ) ) . '">' . esc_html( $p['cta'] ) . '</a>';
		}
		$bill = \Bidik\Account\Account::url( 'billing' );
		if ( $cur['tier'] === $key && ( 'free' === $key || $cur['interval'] === $interval ) ) {
			return '<a class="btn btn-secondary block" href="' . esc_url( $bill ) . '">Manage billing</a>';
		}
		if ( 'past_due' === $cur['status'] ) {
			return '<a class="btn btn-secondary block" href="' . esc_url( $bill ) . '">Update your card first</a>';
		}
		$rank  = [ 'free' => 0, 'member' => 1, 'pro' => 2 ];
		$now   = $rank[ $cur['tier'] ];
		$to    = $rank[ $key ];
		if ( $cur['tier'] === $key ) {
			$label = 'year' === $interval ? 'Switch to yearly' : 'Switch to monthly';
			$cls   = 'year' === $interval ? 'primary' : 'secondary';
		} elseif ( 'free' === $key ) {
			$label = 'Switch to Free';
			$cls   = 'ghost';
		} elseif ( $to > $now ) {
			$label = 'Upgrade to ' . $p['name'];
			$cls   = 'primary';
		} else {
			$label = 'Switch to ' . $p['name'];
			$cls   = 'secondary';
		}
		return '<button type="button" class="btn btn-' . $cls . ' block" data-bidik-change="' . (int) $lvl['id'] . '">' . esc_html( $label ) . '</button>';
	}
}
