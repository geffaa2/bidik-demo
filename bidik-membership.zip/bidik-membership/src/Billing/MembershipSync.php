<?php
namespace Bidik\Billing;

use Bidik\Courses\Drip;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Makes the member's PMPro level match their subscription. Idempotent: it only acts when they differ. */
final class MembershipSync {
	/** @param array<string,mixed> $sub subscription row */
	public static function apply( array $sub ): void {
		self::apply_level( $sub );
		if ( ! empty( $sub['user_id'] ) ) {
			\Bidik\Esp\Sync::enqueue( (int) $sub['user_id'] ); // the email list follows the member (does nothing when it already agrees)
		}
	}

	/** @param array<string,mixed> $sub subscription row */
	private static function apply_level( array $sub ): void {
		$user_id = (int) $sub['user_id'];
		if ( ! $user_id || ! function_exists( 'pmpro_changeMembershipLevel' ) ) {
			return;
		}

		// Trialing, active and past_due (inside the grace period) keep access; the rest fall back to Free.
		$keeps  = in_array( $sub['status'], [ 'trialing', 'active', 'past_due' ], true );
		$target = $keeps ? (int) $sub['level_id'] : 0;

		$have = array_map( static fn( $l ) => (int) $l->id, (array) pmpro_getMembershipLevelsForUser( $user_id ) );
		if ( $target && in_array( $target, $have, true ) ) {
			return;
		}
		if ( ! $target && ! $have ) {
			return;
		}
		self::set_level( $user_id, $target );
		wp_cache_delete( "user_{$user_id}_levels_active", 'pmpro' );
		self::track_since( $user_id, $target );
	}

	/**
	 * Gives the member a level WITH its billing terms. PMPro stores a bare level id as "no billing" (0 a month),
	 * which would make price_for() and every proration read $0, so always pass the terms.
	 */
	public static function set_level( int $user_id, int $level_id ): void {
		$l = $level_id ? pmpro_getLevel( $level_id ) : null;
		if ( ! $l ) {
			pmpro_changeMembershipLevel( 0, $user_id );
			return;
		}
		// PMPro only closes the old level when its level group allows a single choice. Do not depend on that setting: a member holds exactly one plan.
		foreach ( (array) pmpro_getMembershipLevelsForUser( $user_id ) as $old ) {
			if ( (int) $old->id !== $level_id ) {
				pmpro_cancelMembershipLevel( (int) $old->id, $user_id, 'changed' );
			}
		}
		pmpro_changeMembershipLevel( [ 'user_id' => $user_id, 'membership_id' => $level_id, 'code_id' => 0, 'initial_payment' => $l->initial_payment, 'billing_amount' => $l->billing_amount,
			'cycle_number' => $l->cycle_number, 'cycle_period' => $l->cycle_period, 'billing_limit' => $l->billing_limit, 'trial_amount' => 0, 'trial_limit' => 0,
			'expiration_number' => 0, 'expiration_period' => '' ], $user_id );
	}

	/**
	 * Drip counts from the day the member joined. Upgrading keeps that day; coming back after more than
	 * 30 days without a paid plan starts it again (F5).
	 */
	private static function track_since( int $user_id, int $level_id ): void {
		$now  = Clock::now();
		$rank = $level_id ? (int) get_pmpro_membership_level_meta( $level_id, 'bidik_rank', true ) : -1;
		$had  = (int) get_user_meta( $user_id, 'bidik_member_since', true ) ?: null;
		if ( $rank >= 1 ) {
			$lapsed = (int) get_user_meta( $user_id, 'bidik_lapsed_at', true ) ?: null;
			update_user_meta( $user_id, 'bidik_member_since', Drip::since_on_return( $had, $lapsed, $now ) );
			delete_user_meta( $user_id, 'bidik_lapsed_at' );
		} elseif ( $had && ! get_user_meta( $user_id, 'bidik_lapsed_at', true ) ) {
			update_user_meta( $user_id, 'bidik_lapsed_at', $now );
		}
	}

	/** What this member pays per period: their own level row (after any discount code), else the level's list price. */
	public static function price_for( int $user_id, int $level_id ): float {
		$mine = function_exists( 'pmpro_getMembershipLevelForUser' ) ? pmpro_getMembershipLevelForUser( $user_id, true ) : null;
		if ( $mine && (int) $mine->id === $level_id ) {
			return (float) $mine->billing_amount;
		}
		$level = pmpro_getLevel( $level_id );
		return $level ? (float) $level->billing_amount : 0.0;
	}

	/** The amount of the member's latest invoice, in dollars (what they were really charged). */
	public static function last_charge( int $subscription_id ): float {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT amount_cents FROM {$wpdb->prefix}bidik_invoices WHERE subscription_id = %d ORDER BY id DESC LIMIT 1", $subscription_id ) ) / 100;
	}
}
