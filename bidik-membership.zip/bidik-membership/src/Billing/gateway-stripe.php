<?php
/**
 * PMPro gateway "bidik_stripe": the checkout form collects the account only, then the member goes to Stripe Checkout to pay (the same shape as
 * PMPro's own PayPal Standard). Loaded after PMPro, which defines PMProGateway. Selected with `node scripts/wp.mjs gateway stripe`.
 */
defined( 'ABSPATH' ) || exit;

use Bidik\Billing\Stripe\Checkout;
use Bidik\Billing\Stripe\Config;

class PMProGateway_bidik_stripe extends PMProGateway {
	public function __construct( $gateway = null ) {
		$this->gateway = $gateway;
		return $this->gateway;
	}

	public static function init(): void {
		add_filter( 'pmpro_gateways', static function ( $gateways ) {
			$gateways['bidik_stripe'] = 'Stripe Checkout (Bidik, test mode)';
			return $gateways;
		} );
		add_filter( 'pmpro_payment_options', static fn( $options ) => array_merge( [ 'gateway_environment', 'currency' ], $options ) );
		add_filter( 'pmpro_is_ready', static function ( $ready ) {
			global $pmpro_gateway_ready, $pmpro_pages_ready;
			if ( 'bidik_stripe' === get_option( 'pmpro_gateway' ) ) {
				$pmpro_gateway_ready = Config::enabled();
				return $pmpro_gateway_ready && (bool) $pmpro_pages_ready;
			}
			return $ready;
		} );
		if ( 'bidik_stripe' === get_option( 'pmpro_gateway' ) ) {
			add_filter( 'pmpro_include_payment_information_fields', '__return_false' );
			add_filter( 'pmpro_include_billing_address_fields', '__return_false' );
			add_filter( 'pmpro_required_billing_fields', static fn() => [] );
			add_filter( 'pmpro_checkout_default_submit_button', static fn() => '<span id="pmpro_submit_span"><input type="hidden" name="submit-checkout" value="1" /><input type="submit" class="pmpro_btn pmpro_btn-submit-checkout" value="Continue to Stripe to pay" /></span>' );
			add_filter( 'pmpro_checkout_before_change_membership_level', [ self::class, 'to_stripe' ], 10, 2 );
		}
	}

	/** The account exists and the order is saved: leave for Stripe. PMPro changes the level only if we come back, and we do not (the subscription events do it). */
	public static function to_stripe( $user_id, $order ): void {
		if ( 'bidik_stripe' !== ( $order->gateway ?? '' ) ) {
			return;
		}
		try {
			$url = Checkout::start( (int) $user_id, $order );
		} catch ( \RuntimeException $e ) {
			wp_die( esc_html( 'Stripe could not start the payment: ' . $e->getMessage() ), 'Payment not started', [ 'response' => 502, 'back_link' => true ] );
		}
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect -- Stripe's hosted page, returned by their API
		exit;
	}

	public function process( &$order ) {
		if ( empty( $order->code ) ) {
			$order->code = $order->getRandomCode();
		}
		$order->payment_type = 'Stripe Checkout';
		$order->cardtype     = '';
		$order->status       = 'review'; // the member will pay on Stripe's page
		$order->saveOrder();
		return true;
	}

	public function cancel( &$order ) {
		return true;
	}

	public function update( &$order ) {
		return true;
	}
}
