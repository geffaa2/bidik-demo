<?php
namespace Bidik\Billing;

/**
 * The one place that decides how a subscription changes when a billing event arrives.
 * Pure PHP (no WordPress): it takes the current row and a Stripe-shaped event and returns the fields to write.
 * Stripe, the sandbox gateway, the demo clock and the importer all feed it, so they behave the same.
 */
final class SubscriptionMachine {
	public const GRACE_DAYS = 7;
	private const DAY = 86400;

	/** Allowed status changes. Anything else is ignored, never applied. */
	private const ALLOWED = [
		'trialing' => [ 'active', 'past_due', 'canceled' ],
		'active'   => [ 'past_due', 'paused', 'canceled' ],
		'past_due' => [ 'active', 'canceled' ],
		'paused'   => [ 'active', 'canceled' ],
		'canceled' => [],
	];

	public static function can_transition( string $from, string $to ): bool {
		return in_array( $to, self::ALLOWED[ $from ] ?? [], true );
	}

	/**
	 * @param array<string,mixed>|null $sub   current subscription row, or null when none exists yet
	 * @param array<string,mixed>      $event Stripe-shaped event: id, type, data.object
	 * @return array{fields:array<string,mixed>, transition:?array{0:string,1:string}, ignored:?string}
	 */
	public static function apply( ?array $sub, array $event, int $now ): array {
		$type = (string) ( $event['type'] ?? '' );
		$obj  = $event['data']['object'] ?? null;
		if ( '' === $type || ! is_array( $obj ) ) {
			throw new \InvalidArgumentException( 'Event needs a type and data.object.' );
		}
		return match ( $type ) {
			'customer.subscription.created' => self::created( $sub, $obj, $now ),
			'invoice.paid'                  => self::paid( $sub, $obj ),
			'invoice.payment_failed'        => self::failed( $sub, $now ),
			'customer.subscription.deleted' => self::deleted( $sub, $obj, $now ),
			'customer.subscription.updated' => self::updated( $sub, $obj ),
			default                         => self::ignore( 'Event type ' . $type . ' is not handled.' ),
		};
	}

	private static function ignore( string $why ): array {
		return [ 'fields' => [], 'transition' => null, 'ignored' => $why ];
	}

	private static function ts( $value ): ?string {
		return is_numeric( $value ) && (int) $value > 0 ? gmdate( 'Y-m-d H:i:s', (int) $value ) : null;
	}

	private static function created( ?array $sub, array $obj, int $now ): array {
		if ( null !== $sub ) {
			return self::ignore( 'Subscription already exists.' );
		}
		foreach ( [ 'id', 'status' ] as $key ) {
			if ( empty( $obj[ $key ] ) ) {
				throw new \InvalidArgumentException( "Subscription needs {$key}." );
			}
		}
		if ( ! in_array( $obj['status'], [ 'trialing', 'active' ], true ) ) {
			throw new \InvalidArgumentException( 'A new subscription starts as trialing or active.' );
		}
		$meta = $obj['metadata'] ?? [];
		return [
			'fields' => [
				'user_id'                 => (int) ( $meta['user_id'] ?? 0 ),
				'level_id'                => (int) ( $meta['level_id'] ?? 0 ),
				'gateway_customer_id'     => (string) ( $obj['customer'] ?? '' ),
				'gateway_subscription_id' => (string) $obj['id'],
				'status'                  => (string) $obj['status'],
				'current_period_start'    => self::ts( $obj['current_period_start'] ?? null ),
				'current_period_end'      => self::ts( $obj['current_period_end'] ?? null ),
				'trial_end'               => self::ts( $obj['trial_end'] ?? null ),
				'cancel_at_period_end'    => 0,
				'created_at'              => gmdate( 'Y-m-d H:i:s', $now ),
			],
			'transition' => [ 'none', (string) $obj['status'] ],
			'ignored'    => null,
		];
	}

	private static function paid( ?array $sub, array $obj ): array {
		if ( null === $sub ) {
			return self::ignore( 'Invoice for an unknown subscription.' );
		}
		$fields = [ 'grace_until' => null ];
		if ( isset( $obj['period_start'], $obj['period_end'] ) ) {
			$fields['current_period_start'] = self::ts( $obj['period_start'] );
			$fields['current_period_end']   = self::ts( $obj['period_end'] );
		}
		// A $0 invoice during a trial is not the end of the trial.
		if ( 'trialing' === $sub['status'] && 0 === (int) ( $obj['amount_paid'] ?? 0 ) ) {
			return [ 'fields' => $fields, 'transition' => null, 'ignored' => null ];
		}
		if ( 'active' === $sub['status'] ) {
			return [ 'fields' => $fields, 'transition' => null, 'ignored' => null ];
		}
		return self::move( $sub, 'active', $fields );
	}

	private static function failed( ?array $sub, int $now ): array {
		if ( null === $sub ) {
			return self::ignore( 'Failed invoice for an unknown subscription.' );
		}
		if ( 'past_due' === $sub['status'] ) {
			return self::ignore( 'Already past due; the grace period is not extended.' );
		}
		return self::move( $sub, 'past_due', [ 'grace_until' => gmdate( 'Y-m-d H:i:s', $now + self::GRACE_DAYS * self::DAY ) ] );
	}

	/** Records why they left (voluntary: they cancelled; involuntary: the grace period ran out) only on the real change. */
	private static function deleted( ?array $sub, array $obj, int $now ): array {
		$r = self::move( $sub, 'canceled', [] );
		if ( $r['transition'] ) {
			$r['fields']['churn_type']  = 'involuntary' === ( $obj['metadata']['churn_type'] ?? '' ) ? 'involuntary' : 'voluntary';
			$r['fields']['canceled_at'] = gmdate( 'Y-m-d H:i:s', $now );
		}
		return $r;
	}

	private static function updated( ?array $sub, array $obj ): array {
		if ( null === $sub ) {
			return self::ignore( 'Update for an unknown subscription.' );
		}
		$fields = [];
		if ( array_key_exists( 'cancel_at_period_end', $obj ) ) {
			$fields['cancel_at_period_end'] = $obj['cancel_at_period_end'] ? 1 : 0;
		}
		foreach ( [ 'current_period_start', 'current_period_end', 'trial_end' ] as $key ) {
			if ( isset( $obj[ $key ] ) ) {
				$fields[ $key ] = self::ts( $obj[ $key ] );
			}
		}
		if ( ! empty( $obj['metadata']['level_id'] ) ) {
			$fields['level_id'] = (int) $obj['metadata']['level_id']; // a plan change that applies now
		}
		if ( isset( $obj['metadata']['scheduled_level_id'] ) ) {
			$fields['scheduled_level_id'] = (int) $obj['metadata']['scheduled_level_id'] ?: null;
		}
		if ( array_key_exists( 'pause_until', $obj ) ) {
			$fields['pause_until'] = self::ts( $obj['pause_until'] );
		}
		if ( ! empty( $obj['status'] ) && $obj['status'] !== $sub['status'] ) {
			return self::move( $sub, (string) $obj['status'], $fields );
		}
		return [ 'fields' => $fields, 'transition' => null, 'ignored' => null ];
	}

	/** @param array<string,mixed> $extra */
	private static function move( ?array $sub, string $to, array $extra ): array {
		if ( null === $sub ) {
			return self::ignore( 'No subscription to change.' );
		}
		$from = (string) $sub['status'];
		if ( $from === $to ) {
			return [ 'fields' => $extra, 'transition' => null, 'ignored' => null ];
		}
		if ( ! self::can_transition( $from, $to ) ) {
			return self::ignore( "Cannot go from {$from} to {$to}." );
		}
		if ( 'canceled' === $to ) {
			$extra['grace_until'] = null;
		}
		return [ 'fields' => $extra + [ 'status' => $to ], 'transition' => [ $from, $to ], 'ignored' => null ];
	}
}
