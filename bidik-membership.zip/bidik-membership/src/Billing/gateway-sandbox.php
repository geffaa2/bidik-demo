<?php
/** PMPro gateway "bidik_sandbox": accepts Stripe's documented test cards. Loaded after PMPro, which defines PMProGateway. */
defined( 'ABSPATH' ) || exit;

use Bidik\Billing\Sandbox;

class PMProGateway_bidik_sandbox extends PMProGateway {
	public function __construct( $gateway = null ) {
		$this->gateway = $gateway;
		return $this->gateway;
	}

	public static function init(): void {
		add_filter( 'pmpro_gateways', static function ( $gateways ) {
			$gateways['bidik_sandbox'] = 'Bidik sandbox (test cards)';
			return $gateways;
		} );
		add_filter( 'pmpro_payment_options', static fn( $options ) => array_merge( [ 'gateway_environment', 'currency' ], $options ) );
		// PMPro only knows its own gateways when it decides whether setup is finished.
		add_filter( 'pmpro_is_ready', static function ( $ready ) {
			global $pmpro_gateway_ready, $pmpro_pages_ready;
			if ( 'bidik_sandbox' === get_option( 'pmpro_gateway' ) ) {
				$pmpro_gateway_ready = true;
				return (bool) $pmpro_pages_ready;
			}
			return $ready;
		} );
	}

	/** @param object $order */
	public function process( &$order ) {
		$card = Sandbox::card( (string) ( $order->accountnumber ?? '' ) );
		if ( ! $card['ok'] ) {
			$order->error      = $card['error'];
			$order->shorterror = $card['error'];
			return false;
		}
		$suffix = strtolower( wp_generate_password( 14, false, false ) );
		$order->payment_type                = 'Card';
		$order->cardtype                    = $card['brand'];
		$order->accountnumber               = 'XXXX XXXX XXXX ' . $card['last4'];
		$order->payment_transaction_id      = 'ch_sbx_' . $suffix;
		$order->subscription_transaction_id = pmpro_isLevelRecurring( $order->membership_level ) ? 'sub_sbx_' . $suffix : '';
		$order->status                      = 'success';
		return true;
	}

	public function cancel( &$order ) {
		return ! empty( $order->subscription_transaction_id );
	}

	public function update( &$order ) {
		return true;
	}
}
