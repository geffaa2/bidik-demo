<?php
namespace Bidik\Billing;

use Bidik\Mail\Mailer;
use Bidik\Pricing;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** A member moves between plans. Prices come from the same place the checkout reads; the arithmetic is Proration's. */
final class PlanChange {
	/** The member's live subscription (anything not canceled), or null. @return array<string,mixed>|null */
	public static function subscription( int $user_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_subscriptions WHERE user_id = %d AND status <> 'canceled' ORDER BY id DESC LIMIT 1", $user_id ), ARRAY_A );
		return $row ?: null;
	}

	/** @return array{id:int,name:string,tier:string,interval:string,rank:int,price:int}|null price in cents, the list price */
	public static function level( int $level_id ): ?array {
		$l = $level_id ? pmpro_getLevel( $level_id ) : null;
		if ( ! $l ) {
			return null;
		}
		$tier = (string) get_pmpro_membership_level_meta( $level_id, 'bidik_tier', true );
		return [
			'id' => $level_id, 'tier' => $tier, 'interval' => (string) get_pmpro_membership_level_meta( $level_id, 'bidik_interval', true ) ?: 'month',
			'rank' => (int) get_pmpro_membership_level_meta( $level_id, 'bidik_rank', true ), 'price' => (int) round( (float) $l->billing_amount * 100 ),
			'name' => self::label( (string) $l->name ),
		];
	}

	/** "Member (monthly)" is how the level is stored; people read "Member, monthly". */
	public static function label( string $stored ): string {
		return (string) preg_replace( '/ \((\w+)\)$/', ', $1', $stored );
	}

	private static function ts( ?string $mysql ): ?int {
		return $mysql ? ( new \DateTimeImmutable( $mysql, new \DateTimeZone( 'UTC' ) ) )->getTimestamp() : null;
	}

	/** @throws \DomainException @return array<string,mixed> */
	public static function quote( int $user_id, int $target_level ): array {
		$sub = self::subscription( $user_id );
		if ( ! $sub ) {
			throw new \DomainException( 'You do not have a plan to change yet. Pick one on the Pricing page.' );
		}
		$to   = self::level( $target_level );
		$from = self::level( (int) $sub['level_id'] );
		if ( ! $to || ! $from || ! in_array( $to['tier'], [ 'free', 'member', 'pro' ], true ) ) {
			throw new \DomainException( 'That plan does not exist.' );
		}
		$paying = (int) round( MembershipSync::price_for( $user_id, (int) $sub['level_id'] ) * 100 ); // what this member really pays, after any code
		$q      = Proration::quote( [
			'status' => (string) $sub['status'], 'old_price' => $paying, 'new_price' => $to['price'], 'old_rank' => $from['rank'], 'new_rank' => $to['rank'],
			'old_interval' => $from['interval'], 'new_interval' => $to['interval'],
			'period_start' => self::ts( $sub['current_period_start'] ) ?? Clock::now(), 'period_end' => self::ts( $sub['current_period_end'] ) ?? Clock::now(),
			'trial_end' => self::ts( $sub['trial_end'] ), 'now' => Clock::now(),
		] );
		$card = get_user_meta( $user_id, 'bidik_card', true );
		return $q + [ 'from' => $from, 'to' => $to, 'to_free' => 'free' === $to['tier'], 'card' => is_array( $card ) ? $card : null, 'subscription_id' => (int) $sub['id'], 'level_id' => $target_level ];
	}

	/**
	 * Confirms the change. `$expected_due` is the amount the member saw; if the price moved since, nothing happens.
	 *
	 * @throws \DomainException @return array<string,mixed> the quote that was applied
	 */
	public static function apply( int $user_id, int $target_level, int $expected_due ): array {
		$q = self::quote( $user_id, $target_level );
		if ( $q['due'] !== $expected_due ) {
			throw new \DomainException( 'The price changed while this window was open. Review the new amount and confirm again.' );
		}
		$sub = self::subscription( $user_id );
		$gid = (string) $sub['gateway_subscription_id'];
		$uid = substr( wp_generate_uuid4(), 0, 8 );
		$obj = [ 'id' => $gid, 'metadata' => [] ];

		if ( 'downgrade' === $q['kind'] ) {
			if ( $q['to_free'] ) {
				$obj['cancel_at_period_end'] = true;
				$obj['metadata']['scheduled_level_id'] = 0;
			} else {
				$obj['cancel_at_period_end'] = false;
				$obj['metadata']['scheduled_level_id'] = $target_level;
			}
		} else {
			$obj['metadata']['level_id']           = $target_level;
			$obj['metadata']['scheduled_level_id'] = 0;
			$obj['cancel_at_period_end']           = false;
			if ( $q['restarts'] ) {
				$obj['current_period_start'] = Clock::now();
				$obj['current_period_end']   = $q['next_at'];
			}
		}
		WebhookProcessor::handle( 'sandbox', [ 'id' => "evt_sbx_chg_$uid", 'type' => 'customer.subscription.updated', 'data' => [ 'object' => $obj ] ] );

		if ( $q['due'] > 0 ) {
			$tt   = ucfirst( $q['to']['tier'] );
			$what = $q['restarts'] ? $tt . ', ' . ( 'year' === $q['to']['interval'] ? 'yearly' : 'monthly' ) . ' (new period starts today, credit applied)'
				: 'Upgrade to ' . $tt . ', prorated (' . $q['remaining_days'] . ' days)';
			$inv  = [ 'id' => "in_sbx_chg_$uid", 'subscription' => $gid, 'amount_paid' => $q['due'], 'currency' => 'usd', 'billing_reason' => 'subscription_update', 'created' => Clock::now(),
				'lines' => [ [ 'description' => $what, 'amount' => $q['due'] ] ] ];
			if ( $q['restarts'] ) {
				$inv['period_start'] = Clock::now();
				$inv['period_end']   = $q['next_at'];
			}
			WebhookProcessor::handle( 'sandbox', [ 'id' => "evt_sbx_chginv_$uid", 'type' => 'invoice.paid', 'data' => [ 'object' => $inv ] ] );
		}
		self::notify( $user_id, $q );
		return $q;
	}

	/** Takes back a scheduled downgrade, or an "ends on" date set by switching to Free. */
	public static function undo( int $user_id ): void {
		$sub = self::subscription( $user_id );
		if ( ! $sub ) {
			throw new \DomainException( 'There is nothing to undo.' );
		}
		WebhookProcessor::handle( 'sandbox', [ 'id' => 'evt_sbx_undo_' . substr( wp_generate_uuid4(), 0, 8 ), 'type' => 'customer.subscription.updated',
			'data' => [ 'object' => [ 'id' => (string) $sub['gateway_subscription_id'], 'cancel_at_period_end' => false, 'metadata' => [ 'scheduled_level_id' => 0 ] ] ] ] );
	}

	private static function notify( int $user_id, array $q ): void {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}
		$date = static fn( int $ts ) => ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( wp_timezone() )->format( 'D j M Y' );
		$then = '$' . number_format( $q['next_amount'] / 100, 2 );
		if ( 'downgrade' === $q['kind'] ) {
			Mailer::plan_changed( $user, 'Your plan change is scheduled', [ 'You keep ' . $q['from']['name'] . ' until ' . $date( $q['next_at'] ) . '.', $q['to_free'] ? 'After that you move to Free and are not charged again.' : 'Then you move to ' . $q['to']['name'] . ' at ' . $then . '.', 'Changed your mind? Undo it from Billing before then.' ] );
		} elseif ( 'trial' === $q['kind'] ) {
			Mailer::plan_changed( $user, 'You are trying ' . $q['to']['name'], [ 'Your trial keeps running, and nothing is charged today.', 'The first charge is ' . $then . ' on ' . $date( $q['next_at'] ) . '.' ] );
		} else {
			Mailer::plan_changed( $user, 'You are on ' . $q['to']['name'], [ 'It is open now.' . ( $q['due'] ? ' We charged $' . number_format( $q['due'] / 100, 2 ) . ' today.' : '' ), 'Next: ' . $then . ' on ' . $date( $q['next_at'] ) . '.' ] );
		}
	}

	/** The plan the Pricing page should mark as the member's own. @return array{level_id:int,tier:string,interval:string,status:string}|null */
	public static function current( int $user_id ): ?array {
		$sub = $user_id ? self::subscription( $user_id ) : null;
		$lvl = $sub ? self::level( (int) $sub['level_id'] ) : null;
		return $sub && $lvl ? [ 'level_id' => (int) $sub['level_id'], 'tier' => $lvl['tier'], 'interval' => $lvl['interval'], 'status' => (string) $sub['status'] ] : null;
	}

	private static function money( int $cents ): string {
		return '$' . number_format( $cents / 100, 2 );
	}

	private static function per( array $level ): string {
		return self::money( $level['price'] ) . ( 'year' === $level['interval'] ? ' a year' : ' a month' );
	}

	/** Everything the confirmation window shows, already worded. The browser only draws it. @return array<string,mixed> */
	public static function describe( array $q ): array {
		$tz   = wp_timezone();
		$d    = static fn( int $ts ) => ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( $tz )->format( 'j M Y' );
		$short = static fn( int $ts ) => ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( $tz )->format( 'j M' );
		[ $from, $to ] = [ $q['from'], $q['to'] ];
		[ $tf, $tt ]   = [ ucfirst( $from['tier'] ), ucfirst( $to['tier'] ) ];
		$card  = $q['card'] ? $q['card']['brand'] . ' ending ' . $q['card']['last4'] : '';
		$rows  = [];
		$out   = [ 'swap' => [ $from['name'] . ' · ' . self::per( $from ), $to['name'] . ' · ' . ( $to['price'] ? self::per( $to ) : 'free' ) ], 'level' => $q['level_id'], 'due' => $q['due'], 'kind' => $q['kind'], 'card' => $card ];

		if ( 'trial' === $q['kind'] ) {
			$out += [ 'title' => 'Switch to ' . $tt, 'sub' => 'Your free trial keeps running.', 'rows' => [], 'total' => [ 'Due today', '$0.00' ],
				'then' => 'The first charge is ' . self::money( $q['next_amount'] ) . ' on ' . $d( $q['next_at'] ) . '. Cancel before then and you pay nothing.', 'confirm' => 'Switch plan', 'card' => '' ];
		} elseif ( 'downgrade' === $q['kind'] ) {
			$out += [ 'title' => $q['to_free'] ? 'Move to Free' : 'Switch to ' . $tt, 'sub' => 'Nothing is charged, and nothing changes today.', 'rows' => [], 'total' => [ 'Due today', '$0.00' ],
				'then' => 'You keep ' . $tf . ' until ' . $d( $q['next_at'] ) . '. ' . ( $q['to_free'] ? 'After that you move to Free and are not charged again.' : 'Then you move to ' . $to['name'] . ' at ' . self::per( $to ) . '.' ),
				'confirm' => 'Schedule the change', 'card' => '' ];
		} else {
			$unlock = [ 'pro' => 'Night & Astro and every module open right away.', 'member' => 'The full library and two courses open right away.' ][ $to['tier'] ] ?? 'Your new plan opens right away.';
			if ( $q['restarts'] ) {
				$rows[] = [ $tt . ' for a new ' . ( 'year' === $to['interval'] ? 'year' : 'month' ) . ' from today', $short( Clock::now() ) . ' – ' . $short( $q['next_at'] ), self::money( $q['charge'] ), '' ];
			} else {
				$rows[] = [ $tt . ' for the ' . $q['remaining_days'] . ' days left in this period', $short( Clock::now() ) . ' – ' . $short( $q['next_at'] ), self::money( $q['charge'] ), '' ];
			}
			if ( $q['credit'] > 0 ) {
				$rows[] = [ 'Credit for unused ' . $tf . ' days', $q['remaining_days'] . ' of ' . $q['period_days'] . ' days', '−' . self::money( $q['credit'] ), 'credit' ];
			}
			$same = $from['tier'] === $to['tier'];
			$out += [ 'title' => $same ? 'Switch to ' . ( 'year' === $to['interval'] ? 'yearly' : 'monthly' ) . ' billing' : 'Upgrade to ' . $tt, 'sub' => $same ? 'Pay once for the year and save two months.' : $unlock, 'rows' => $rows,
				'total' => [ 'Due today', self::money( $q['due'] ) ], 'then' => 'Then ' . self::per( $to ) . ' from ' . $d( $q['next_at'] ) . '.',
				'confirm' => $q['due'] > 0 ? 'Pay ' . self::money( $q['due'] ) . ' and ' . ( $same ? 'switch' : 'upgrade' ) : ( $same ? 'Switch now' : 'Upgrade now' ) ];
		}
		return $out;
	}
}
