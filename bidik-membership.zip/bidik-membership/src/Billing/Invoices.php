<?php
namespace Bidik\Billing;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

final class Invoices {
	private const SEQ = 'bidik_invoice_seq';

	/** BDK-2026-000123. One running sequence; the year is the year it was issued. */
	public static function next_number(): string {
		global $wpdb;
		add_option( self::SEQ, 0, '', false );
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = option_value + 1 WHERE option_name = %s", self::SEQ ) );
		wp_cache_delete( self::SEQ, 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		$seq = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::SEQ ) );
		return sprintf( 'BDK-%s-%06d', gmdate( 'Y', Clock::now() ), $seq );
	}

	/**
	 * Inserts or updates the invoice for a gateway invoice id. Safe to call twice with the same event.
	 *
	 * @param array<string,mixed> $obj Stripe-shaped invoice object
	 * @return int invoice row id
	 */
	public static function upsert( array $obj, int $user_id, int $subscription_id, string $status ): int {
		global $wpdb;
		$t   = $wpdb->prefix . 'bidik_invoices';
		$gid = (string) $obj['id'];
		$at  = Clock::mysql( isset( $obj['created'] ) ? (int) $obj['created'] : null ); // Stripe invoices carry their creation time
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $t WHERE gateway_invoice_id = %s", $gid ), ARRAY_A );
		if ( $row ) {
			$wpdb->update( $t, [ 'status' => $status, 'paid_at' => 'paid' === $status ? $at : null ], [ 'id' => (int) $row['id'] ] );
			return (int) $row['id'];
		}
		$wpdb->insert( $t, [
			'number'             => self::next_number(),
			'user_id'            => $user_id,
			'subscription_id'    => $subscription_id,
			'gateway_invoice_id' => $gid,
			'amount_cents'       => (int) ( $obj['amount_paid'] ?? $obj['amount_due'] ?? 0 ),
			'currency'           => strtoupper( (string) ( $obj['currency'] ?? 'usd' ) ),
			'status'             => $status,
			'line_items'         => wp_json_encode( $obj['lines'] ?? [] ),
			'paid_at'            => 'paid' === $status ? $at : null,
			'created_at'         => $at,
		] );
		return (int) $wpdb->insert_id;
	}
}
