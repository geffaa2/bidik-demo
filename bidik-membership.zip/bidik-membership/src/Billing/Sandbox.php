<?php
namespace Bidik\Billing;

defined( 'ABSPATH' ) || exit;

/** Test cards for the demo gateway, mirroring Stripe's documented numbers. */
final class Sandbox {
	public const OK       = '4242424242424242';
	public const DECLINED = '4000000000009995';
	public const FAILS_ON_RENEWAL = '4000000000000341';

	/** @return array{ok:bool, brand:string, last4:string, renews:bool, error:string} */
	public static function card( string $digits ): array {
		$digits = preg_replace( '/\D/', '', $digits );
		$last4  = substr( $digits, -4 );
		if ( self::DECLINED === $digits ) {
			return [ 'ok' => false, 'brand' => 'Visa', 'last4' => $last4, 'renews' => false, 'error' => 'Your card was declined: insufficient funds. Try another card.' ];
		}
		if ( self::OK === $digits || self::FAILS_ON_RENEWAL === $digits ) {
			return [ 'ok' => true, 'brand' => 'Visa', 'last4' => $last4, 'renews' => self::OK === $digits, 'error' => '' ];
		}
		return [ 'ok' => false, 'brand' => '', 'last4' => $last4, 'renews' => false,
			'error' => 'This is a demo site. Use the test card 4242 4242 4242 4242, with any future expiry date and any 3-digit code.' ];
	}
}
