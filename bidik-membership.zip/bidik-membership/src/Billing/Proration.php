<?php
namespace Bidik\Billing;

/**
 * What a plan change costs. Pure PHP, whole cents, whole days (no WordPress, no gateway).
 *
 *  - Tier up on the same interval: the new plan starts now and the period stays. You pay the new plan for the days
 *    left, minus credit for the unused days of the old one:  due = max(0, round(new × left ÷ days) − round(old × left ÷ days)).
 *  - Anything that changes the interval and moves up (Member monthly → Pro yearly, or monthly → yearly): a new period
 *    starts today, so due = max(0, new price − credit).
 *  - Down (a lower tier, or yearly → monthly): nothing is charged; it applies when the paid period ends.
 *  - During a trial: no charge and the trial keeps running; the first charge is the new plan's price.
 * Stripe's own invoice preview is the source of truth in Stripe mode; this class is what the sandbox charges and
 * what the golden tests pin down.
 */
final class Proration {
	private const DAY = 86400;

	/**
	 * @param array{status:string,old_price:int,new_price:int,old_rank:int,new_rank:int,old_interval:string,new_interval:string,period_start:int,period_end:int,trial_end:?int,now:int} $in prices in cents
	 * @return array{kind:string,effective:string,credit:int,charge:int,due:int,remaining_days:int,period_days:int,next_at:int,next_amount:int,restarts:bool}
	 * @throws \DomainException when the change is not possible right now (message is safe to show)
	 */
	public static function quote( array $in ): array {
		if ( 'past_due' === $in['status'] ) {
			throw new \DomainException( 'Update your card first. Plan changes are paused while a payment is overdue.' );
		}
		if ( ! in_array( $in['status'], [ 'active', 'trialing' ], true ) ) {
			throw new \DomainException( 'Plan changes are only available on an active membership.' );
		}
		$same_interval = $in['old_interval'] === $in['new_interval'];
		if ( $in['old_rank'] === $in['new_rank'] && $same_interval ) {
			throw new \DomainException( 'You are already on this plan.' );
		}

		$days      = max( 1, (int) round( ( $in['period_end'] - $in['period_start'] ) / self::DAY ) );
		$remaining = max( 0, min( $days, (int) ceil( ( $in['period_end'] - $in['now'] ) / self::DAY ) ) );
		$base      = [ 'credit' => 0, 'charge' => 0, 'due' => 0, 'remaining_days' => $remaining, 'period_days' => $days, 'restarts' => false ];

		if ( 'trialing' === $in['status'] ) {
			return $base + [ 'kind' => 'trial', 'effective' => 'now', 'next_at' => (int) $in['trial_end'], 'next_amount' => $in['new_price'] ];
		}

		$up = $in['new_rank'] > $in['old_rank'] || ( $in['new_rank'] === $in['old_rank'] && 'month' === $in['old_interval'] && 'year' === $in['new_interval'] );
		if ( ! $up ) {
			return $base + [ 'kind' => 'downgrade', 'effective' => 'period_end', 'next_at' => $in['period_end'], 'next_amount' => $in['new_price'] ];
		}

		$credit = (int) round( $in['old_price'] * $remaining / $days );
		if ( $same_interval ) {
			$charge = (int) round( $in['new_price'] * $remaining / $days );
			return [ 'kind' => 'upgrade', 'effective' => 'now', 'credit' => $credit, 'charge' => $charge, 'due' => max( 0, $charge - $credit ), 'remaining_days' => $remaining, 'period_days' => $days,
				'next_at' => $in['period_end'], 'next_amount' => $in['new_price'], 'restarts' => false ];
		}
		$next = ( new \DateTimeImmutable( '@' . $in['now'] ) )->modify( 'year' === $in['new_interval'] ? '+1 year' : '+1 month' )->getTimestamp();
		return [ 'kind' => 'upgrade', 'effective' => 'now', 'credit' => $credit, 'charge' => $in['new_price'], 'due' => max( 0, $in['new_price'] - $credit ), 'remaining_days' => $remaining, 'period_days' => $days,
			'next_at' => $next, 'next_amount' => $in['new_price'], 'restarts' => true ];
	}
}
