<?php
namespace Bidik\Billing;

use Bidik\Mail\Mailer;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * The sandbox's "billing day". Every hour (and whenever the demo clock moves) it asks Renewal::decide what is due and
 * turns the answer into the same Stripe-shaped events a real gateway would send. Invoice and event ids are built from the
 * subscription and the period, so running it twice, or after a long gap, never charges twice.
 */
final class Renewals {
	private const HOOK = 'bidik_renewals';

	public static function register(): void {
		add_action( self::HOOK, [ self::class, 'run' ] );
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::HOOK );
		}
	}

	/**
	 * @param int[] $only_users limit the run to these members (tests and one-off tools); empty means everyone
	 * @return array<string,int> what it did, for the log and the tests
	 */
	public static function run( array $only_users = [] ): array {
		global $wpdb;
		$stats = [ 'renewed' => 0, 'failed' => 0, 'ended' => 0, 'expired' => 0, 'resumed' => 0, 'dunning' => 0, 'trial_notices' => 0 ];
		$scope = $only_users ? ' AND user_id IN (' . implode( ',', array_map( 'intval', $only_users ) ) . ')' : '';
		$ids   = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}bidik_subscriptions WHERE status IN ('trialing','active','paused','past_due')$scope ORDER BY id" );
		foreach ( $ids as $id ) {
			self::step( (int) $id, Clock::now(), $stats );
		}
		return $stats;
	}

	private static function row( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_subscriptions WHERE id = %d", $id ), ARRAY_A ) ?: null;
	}

	private static function step( int $id, int $now, array &$stats ): void {
		for ( $i = 0; $i < 36; $i++ ) { // a clock jump of several periods is billed one period at a time
			$sub = self::row( $id );
			if ( ! $sub ) {
				return;
			}
			$d = Renewal::decide( $sub, $now );
			switch ( $d['action'] ) {
				case Renewal::END:
					self::end( $sub, 'voluntary' );
					++$stats['ended'];
					return;
				case Renewal::EXPIRE:
					self::end( $sub, 'involuntary' );
					++$stats['expired'];
					return;
				case Renewal::RESUME:
					Leave::reactivate( $sub );
					++$stats['resumed'];
					continue 2;
				case Renewal::CHARGE:
					$next = $d['apply_schedule'] ? (int) $sub['scheduled_level_id'] : (int) $sub['level_id'];
					if ( $d['apply_schedule'] ) {
						self::event( 'sched_' . $sub['id'] . '_' . strtotime( $sub['current_period_end'] . ' UTC' ), 'customer.subscription.updated', [ 'id' => $sub['gateway_subscription_id'], 'metadata' => [ 'level_id' => $next, 'scheduled_level_id' => 0 ] ] );
					}
					if ( self::bill( $sub, $next, strtotime( $sub['current_period_end'] . ' UTC' ), 'trialing' === $sub['status'] ? 'first charge after trial' : '', $d['apply_schedule'] ) ) {
						++$stats['renewed'];
						continue 2;
					}
					++$stats['failed'];
					return;
				default:
					self::notices( $sub, $now, $stats );
					return;
			}
		}
	}

	/** @param array<string,mixed> $obj */
	private static function event( string $id, string $type, array $obj ): array {
		return WebhookProcessor::handle( 'sandbox', [ 'id' => "evt_sbx_$id", 'type' => $type, 'data' => [ 'object' => $obj ] ] );
	}

	private static function end( array $sub, string $why ): void {
		self::event( 'end_' . $sub['id'], 'customer.subscription.deleted', [ 'id' => $sub['gateway_subscription_id'], 'metadata' => [ 'churn_type' => $why ] ] );
	}

	/** True when this member's card can pay a renewal. The test card 0341 works at checkout and fails here, as Stripe's does. */
	public static function card_ok( int $user_id ): bool {
		$c = Cards::get( $user_id );
		return $c && $c['renews'] && 'expired' !== Cards::expiry_state( $c, Clock::now() );
	}

	/** The price for the next charge, in cents: their own price (after a code), or the plan's list price after a plan change, less any retention offer. */
	public static function price_cents( int $user_id, int $level_id, bool $list ): int {
		$base = $list ? (int) round( (float) pmpro_getLevel( $level_id )->billing_amount * 100 ) : (int) round( MembershipSync::price_for( $user_id, $level_id ) * 100 );
		$off  = get_user_meta( $user_id, 'bidik_retention', true );
		return is_array( $off ) && ( $off['left'] ?? 0 ) > 0 ? (int) round( $base * ( 100 - (int) $off['percent'] ) / 100 ) : $base;
	}

	/**
	 * Charges one period starting at $start. Success: invoice.paid and a new period. Failure: invoice.payment_failed (the machine starts the grace period).
	 * Ids come from the subscription and the period start, so the same period is never billed twice.
	 */
	public static function bill( array $sub, int $level_id, int $start, string $note = '', bool $list = false ): bool {
		$user  = (int) $sub['user_id'];
		$level = PlanChange::level( $level_id );
		$end   = ( new \DateTimeImmutable( '@' . $start ) )->modify( 'year' === $level['interval'] ? '+1 year' : '+1 month' )->getTimestamp();
		$cents = self::price_cents( $user, $level_id, $list );
		$off   = get_user_meta( $user, 'bidik_retention', true );
		$disc  = is_array( $off ) && ( $off['left'] ?? 0 ) > 0 ? ' (' . (int) $off['percent'] . '% off)' : '';
		$what  = $level['name'] . ( $note ? " ($note)" : '' ) . $disc;
		$obj   = [ 'id' => 'in_sbx_ren_' . $sub['id'] . '_' . $start, 'subscription' => $sub['gateway_subscription_id'], 'currency' => 'usd', 'created' => $start, 'lines' => [ [ 'description' => $what, 'amount' => $cents ] ] ];
		if ( ! self::card_ok( $user ) ) {
			self::event( 'renfail_' . $sub['id'] . '_' . $start, 'invoice.payment_failed', $obj + [ 'amount_due' => $cents ] );
			return false;
		}
		self::event( 'renpaid_' . $sub['id'] . '_' . $start, 'invoice.paid', $obj + [ 'amount_paid' => $cents, 'period_start' => $start, 'period_end' => $end, 'billing_reason' => 'subscription_cycle' ] );
		if ( $disc ) {
			$off['left'] = max( 0, (int) $off['left'] - 1 );
			update_user_meta( $user, 'bidik_retention', $off );
		}
		return true;
	}

	/** Trial warning and the dunning reminders that are due. */
	private static function notices( array $sub, int $now, array &$stats ): void {
		global $wpdb;
		$user = get_userdata( (int) $sub['user_id'] );
		if ( ! $user ) {
			return;
		}
		$log = $wpdb->prefix . 'bidik_email_log';
		if ( 'trialing' === $sub['status'] ) {
			$told = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $log WHERE user_id = %d AND template = 'trial_ending' AND sent_at >= %s", $user->ID, $sub['created_at'] ) ) > 0;
			if ( Renewal::trial_ending( $sub, $now, $told ) ) {
				Mailer::trial_ending( $user, $sub );
				++$stats['trial_notices'];
			}
		}
		if ( 'past_due' === $sub['status'] && $sub['grace_until'] ) {
			$grace = strtotime( $sub['grace_until'] . ' UTC' );
			$from  = gmdate( 'Y-m-d H:i:s', $grace - SubscriptionMachine::GRACE_DAYS * DAY_IN_SECONDS );
			$sent  = [];
			foreach ( Renewal::DUNNING_DAYS as $n => $day ) {
				if ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $log WHERE user_id = %d AND template = %s AND sent_at >= %s", $user->ID, 'dunning_' . ( $n + 1 ), $from ) ) > 0 ) {
					$sent[] = $day;
				}
			}
			foreach ( Renewal::dunning_due( $grace, $now, $sent ) as $day ) {
				Mailer::dunning( $user, $sub, $day );
				++$stats['dunning'];
			}
		}
	}
}
