<?php
namespace Bidik\Billing;

use Bidik\Mail\Mailer;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * Receives Stripe-shaped billing events from any gateway. The events table makes it idempotent:
 * the same (gateway, event id) can arrive any number of times and has its effect once.
 */
final class WebhookProcessor {
	/**
	 * @param array<string,mixed> $event
	 * @return array{status:string, detail?:string}  status: processed | duplicate | ignored | error
	 */
	public static function handle( string $gateway, array $event ): array {
		global $wpdb;
		$events = $wpdb->prefix . 'bidik_events';
		$id     = (string) ( $event['id'] ?? '' );
		$type   = (string) ( $event['type'] ?? '' );
		if ( '' === $id || '' === $type ) {
			return [ 'status' => 'error', 'detail' => 'Event needs an id and a type.' ];
		}

		$wpdb->suppress_errors( true );
		$stored = $wpdb->insert( $events, [ 'gateway' => $gateway, 'event_id' => $id, 'type' => $type, 'payload' => wp_json_encode( $event ), 'created_at' => Clock::mysql() ] );
		$wpdb->suppress_errors( false );
		if ( ! $stored ) {
			return [ 'status' => 'duplicate' ];
		}
		$row_id = (int) $wpdb->insert_id;

		try {
			$result = self::process( $gateway, $event );
			$wpdb->update( $events, [ 'processed_at' => Clock::mysql(), 'error' => $result['ignored'] ?? null ], [ 'id' => $row_id ] );
			return isset( $result['ignored'] ) ? [ 'status' => 'ignored', 'detail' => $result['ignored'] ] : [ 'status' => 'processed' ];
		} catch ( \Throwable $e ) {
			$wpdb->update( $events, [ 'error' => $e->getMessage() ], [ 'id' => $row_id ] );
			return [ 'status' => 'error', 'detail' => $e->getMessage() ];
		}
	}

	/** @return array<string,mixed> */
	private static function process( string $gateway, array $event ): array {
		global $wpdb;
		$subs = $wpdb->prefix . 'bidik_subscriptions';
		$obj  = $event['data']['object'] ?? [];
		$type = (string) $event['type'];
		$gsub = (string) ( str_starts_with( $type, 'invoice.' ) ? ( $obj['subscription'] ?? '' ) : ( $obj['id'] ?? '' ) );

		$sub = $gsub ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $subs WHERE gateway_subscription_id = %s", $gsub ), ARRAY_A ) : null;
		$out = SubscriptionMachine::apply( $sub, $event, Clock::now() );

		if ( $out['fields'] ) {
			if ( $sub ) {
				$wpdb->update( $subs, $out['fields'], [ 'id' => (int) $sub['id'] ] );
			} else {
				$wpdb->insert( $subs, $out['fields'] + [ 'gateway' => $gateway ] );
			}
			$sub = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $subs WHERE gateway_subscription_id = %s", $gsub ), ARRAY_A );
		}

		if ( $sub && str_starts_with( $type, 'invoice.' ) ) {
			$status = 'invoice.paid' === $type ? 'paid' : 'open';
			Invoices::upsert( $obj, (int) $sub['user_id'], (int) $sub['id'], $status );
		}
		if ( $sub ) {
			$to = $out['transition'][1] ?? null;
			if ( 'paused' === $to ) {
				\Bidik\Billing\Leave::note_pause( (int) $sub['user_id'] ); // before the level drops to Free and the joined date is touched
			}
			MembershipSync::apply( $sub );
			if ( $out['transition'] && 'paused' === $out['transition'][0] && 'active' === $to ) {
				\Bidik\Billing\Leave::shift_drip( (int) $sub['user_id'] );
			}
			Mailer::for_event( $type, $sub, $obj, $out['transition'] );
		}
		return $out;
	}
}
