<?php
namespace Bidik\Billing;

use Bidik\Courses\Drip;
use Bidik\Mail\Mailer;
use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** Pause, cancel, take the retention offer, come back. Each one is an ordinary billing event, like everything else. */
final class Leave {
	public const REASONS = [
		'too_expensive' => "It's too expensive right now",
		'no_time'       => "I don't have time to practise",
		'finished'      => 'I finished what I came for',
		'not_expected'  => "The lessons weren't what I expected",
		'technical'     => "Something didn't work for me",
		'other'         => 'Something else',
	];
	public const DISCOUNT_PERCENT = 30;
	public const DISCOUNT_RENEWALS = 2;

	private static function sub( int $user_id ): array {
		$sub = PlanChange::subscription( $user_id );
		if ( ! $sub ) {
			throw new \DomainException( 'You do not have a paid plan to change.' );
		}
		return $sub;
	}

	private static function event( string $id, string $type, array $obj ): void {
		WebhookProcessor::handle( 'sandbox', [ 'id' => "evt_sbx_{$id}_" . substr( wp_generate_uuid4(), 0, 8 ), 'type' => $type, 'data' => [ 'object' => $obj ] ] );
	}

	private static function feedback( array $sub, string $reason, string $comment, string $offer, bool $accepted ): void {
		global $wpdb;
		if ( ! isset( self::REASONS[ $reason ] ) ) {
			throw new \DomainException( 'Choose the main reason first.' );
		}
		$wpdb->insert( $wpdb->prefix . 'bidik_cancel_feedback', [ 'user_id' => (int) $sub['user_id'], 'subscription_id' => (int) $sub['id'], 'reason' => $reason,
			'comment' => mb_substr( $comment, 0, 1000 ) ?: null, 'offer_shown' => $offer ?: null, 'offer_accepted' => $accepted ? 1 : 0, 'created_at' => Clock::mysql() ] );
	}

	/** What the windows need: plan, dates, prices, which offers this member may take. @return array<string,mixed> */
	public static function summary( int $user_id ): array {
		$sub   = self::sub( $user_id );
		$lvl   = PlanChange::level( (int) $sub['level_id'] );
		$price = Renewals::price_cents( $user_id, (int) $sub['level_id'], false );
		$d     = static fn( int $ts ) => ( new \DateTimeImmutable( '@' . $ts ) )->setTimezone( wp_timezone() )->format( 'D j M Y' );
		$end   = strtotime( ( 'trialing' === $sub['status'] ? $sub['trial_end'] : $sub['current_period_end'] ) . ' UTC' );
		$used  = (bool) get_user_meta( $user_id, 'bidik_retention_used', true );
		$months = [];
		foreach ( [ 1, 2, 3 ] as $m ) {
			$months[] = [ 'months' => $m, 'label' => $m . ( 1 === $m ? ' month' : ' months' ), 'until' => $d( ( new \DateTimeImmutable( '@' . Clock::now() ) )->modify( "+$m months" )->getTimestamp() ) ];
		}
		return [
			'status' => $sub['status'], 'plan' => $lvl['name'], 'tier' => ucfirst( $lvl['tier'] ), 'ends' => $d( $end ), 'scheduled' => ! empty( $sub['cancel_at_period_end'] ),
			'reasons' => self::REASONS, 'months' => $months, 'can_pause' => 'active' === $sub['status'] && empty( $sub['cancel_at_period_end'] ),
			'discount' => [ 'eligible' => ! $used && 'active' === $sub['status'] && $price > 0, 'percent' => self::DISCOUNT_PERCENT, 'renewals' => self::DISCOUNT_RENEWALS,
				'price' => '$' . number_format( $price * ( 100 - self::DISCOUNT_PERCENT ) / 10000, 2 ) ],
		];
	}

	/** Cancel at the end of what they paid for (or the trial). A paused plan ends now: there is nothing left to keep. */
	public static function cancel( int $user_id, string $reason, string $comment, string $offer_shown = '' ): void {
		$sub = self::sub( $user_id );
		if ( ! empty( $sub['cancel_at_period_end'] ) ) {
			throw new \DomainException( 'Your cancellation is already scheduled.' );
		}
		self::feedback( $sub, $reason, $comment, $offer_shown, false );
		if ( 'paused' === $sub['status'] ) {
			self::event( 'leave', 'customer.subscription.deleted', [ 'id' => $sub['gateway_subscription_id'], 'metadata' => [ 'churn_type' => 'voluntary' ] ] );
			return;
		}
		self::event( 'cancel', 'customer.subscription.updated', [ 'id' => $sub['gateway_subscription_id'], 'cancel_at_period_end' => true ] );
		$fresh = PlanChange::subscription( $user_id );
		if ( $fresh && ( $u = get_userdata( $user_id ) ) ) {
			Mailer::cancel_scheduled( $u, $fresh );
		}
	}

	/** The retention offer for "too expensive": 30% off the next two renewals. Once per member. */
	public static function accept_discount( int $user_id, string $reason, string $comment ): void {
		$sub = self::sub( $user_id );
		if ( get_user_meta( $user_id, 'bidik_retention_used', true ) ) {
			throw new \DomainException( 'That offer has already been used on this account.' );
		}
		if ( 'active' !== $sub['status'] ) {
			throw new \DomainException( 'The offer is available on an active plan.' );
		}
		self::feedback( $sub, $reason, $comment, 'discount', true );
		update_user_meta( $user_id, 'bidik_retention', [ 'percent' => self::DISCOUNT_PERCENT, 'left' => self::DISCOUNT_RENEWALS ] );
		update_user_meta( $user_id, 'bidik_retention_used', Clock::now() );
	}

	public static function pause( int $user_id, int $months, string $reason = '', string $comment = '' ): void {
		$sub = self::sub( $user_id );
		if ( $months < 1 || $months > 3 ) {
			throw new \DomainException( 'You can pause for 1, 2 or 3 months.' );
		}
		if ( 'trialing' === $sub['status'] ) {
			throw new \DomainException( 'Pause is available once your trial has ended. You can cancel and rejoin any time.' );
		}
		if ( 'active' !== $sub['status'] || ! empty( $sub['cancel_at_period_end'] ) ) {
			throw new \DomainException( 'Only an active plan can be paused.' );
		}
		if ( '' !== $reason ) {
			self::feedback( $sub, $reason, $comment, 'pause', true );
		}
		$until = ( new \DateTimeImmutable( '@' . Clock::now() ) )->modify( "+$months months" )->getTimestamp();
		self::event( 'pause', 'customer.subscription.updated', [ 'id' => $sub['gateway_subscription_id'], 'status' => 'paused', 'pause_until' => $until ] );
	}

	/** "Resume now" from Billing. */
	public static function resume( int $user_id ): void {
		$sub = self::sub( $user_id );
		if ( 'paused' !== $sub['status'] ) {
			throw new \DomainException( 'Your plan is not paused.' );
		}
		if ( ! Renewals::card_ok( $user_id ) ) {
			throw new \DomainException( 'Add a working card first, then resume.' );
		}
		self::reactivate( $sub );
	}

	/** Back from a pause: a new period starts now and is charged. Used by the button and by the pause date arriving. */
	public static function reactivate( array $sub ): void {
		$now   = Clock::now();
		$level = PlanChange::level( (int) $sub['level_id'] );
		$end   = ( new \DateTimeImmutable( '@' . $now ) )->modify( 'year' === $level['interval'] ? '+1 year' : '+1 month' )->getTimestamp();
		self::event( 'resume', 'customer.subscription.updated', [ 'id' => $sub['gateway_subscription_id'], 'status' => 'active', 'pause_until' => null, 'current_period_start' => $now, 'current_period_end' => $end ] );
		$fresh = PlanChange::subscription( (int) $sub['user_id'] );
		if ( $fresh ) {
			Renewals::bill( $fresh, (int) $fresh['level_id'], $now, 'welcome back' );
		}
	}

	/** Remembers when the pause began and the joined date it began with. */
	public static function note_pause( int $user_id ): void {
		update_user_meta( $user_id, 'bidik_pause_state', [ 'at' => Clock::now(), 'since' => (int) get_user_meta( $user_id, 'bidik_member_since', true ) ] );
	}

	/** Coming back, the drip clock continues where it stopped: the joined date moves forward by the time away. */
	public static function shift_drip( int $user_id ): void {
		$st = get_user_meta( $user_id, 'bidik_pause_state', true );
		if ( ! is_array( $st ) || empty( $st['since'] ) ) {
			return;
		}
		update_user_meta( $user_id, 'bidik_member_since', Drip::shift_since( (int) $st['since'], (int) $st['at'], Clock::now() ) );
		delete_user_meta( $user_id, 'bidik_lapsed_at' );
		delete_user_meta( $user_id, 'bidik_pause_state' );
	}
}
