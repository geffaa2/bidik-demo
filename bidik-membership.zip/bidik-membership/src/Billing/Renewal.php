<?php
namespace Bidik\Billing;

/**
 * Pure: what should happen to a subscription at this moment? The engine (Renewals) asks, then feeds the
 * answer to the processor as ordinary billing events, so renewal, dunning and pause use the same path as checkout.
 */
final class Renewal {
	public const NONE = 'none', CHARGE = 'charge', END = 'end', RESUME = 'resume', EXPIRE = 'expire';
	public const DUNNING_DAYS = [ 0, 3, 6 ];

	private static function ts( $v ): ?int {
		return is_numeric( $v ) ? (int) $v : ( $v ? ( new \DateTimeImmutable( (string) $v, new \DateTimeZone( 'UTC' ) ) )->getTimestamp() : null );
	}

	/**
	 * @param array<string,mixed> $sub subscription row (datetimes in UTC)
	 * @return array{action:string,apply_schedule:bool}
	 */
	public static function decide( array $sub, int $now ): array {
		$none   = [ 'action' => self::NONE, 'apply_schedule' => false ];
		$end    = self::ts( $sub['current_period_end'] ?? null );
		$status = (string) ( $sub['status'] ?? '' );
		if ( in_array( $status, [ 'trialing', 'active' ], true ) ) {
			if ( null === $end || $now < $end ) {
				return $none;
			}
			return ! empty( $sub['cancel_at_period_end'] )
				? [ 'action' => self::END, 'apply_schedule' => false ]
				: [ 'action' => self::CHARGE, 'apply_schedule' => ! empty( $sub['scheduled_level_id'] ) ];
		}
		if ( 'paused' === $status ) {
			$until = self::ts( $sub['pause_until'] ?? null );
			return $until && $now >= $until ? [ 'action' => self::RESUME, 'apply_schedule' => false ] : $none;
		}
		if ( 'past_due' === $status ) {
			$grace = self::ts( $sub['grace_until'] ?? null );
			return $grace && $now >= $grace ? [ 'action' => self::EXPIRE, 'apply_schedule' => false ] : $none;
		}
		return $none;
	}

	/** Which dunning emails (by day offset) are due and not sent yet. @param int[] $sent @return int[] */
	public static function dunning_due( int $grace_until, int $now, array $sent ): array {
		$start = $grace_until - SubscriptionMachine::GRACE_DAYS * 86400;
		$due   = [];
		foreach ( self::DUNNING_DAYS as $day ) {
			if ( $now >= $start + $day * 86400 && $now < $grace_until && ! in_array( $day, $sent, true ) ) {
				$due[] = $day;
			}
		}
		return $due;
	}

	/** True when a trial ends within two days and the member has not been told. */
	public static function trial_ending( array $sub, int $now, bool $told ): bool {
		$end = self::ts( $sub['trial_end'] ?? null );
		return 'trialing' === ( $sub['status'] ?? '' ) && $end && ! $told && $now < $end && $end - $now <= 2 * 86400 && empty( $sub['cancel_at_period_end'] );
	}
}
