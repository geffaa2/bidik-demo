<?php
namespace Bidik\Billing\Stripe;

defined( 'ABSPATH' ) || exit;

/** POST /wp-json/bidik/v1/stripe. The signature is the only credential; nothing else about the request is trusted. */
final class Webhook {
	public static function register(): void {
		add_action( 'rest_api_init', static function (): void {
			register_rest_route( 'bidik/v1', '/stripe', [ 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => [ self::class, 'receive' ] ] );
		} );
	}

	public static function receive( \WP_REST_Request $r ) {
		$body = $r->get_body();
		$ok   = Signature::verify( $body, (string) $r->get_header( 'stripe-signature' ), Config::webhook_secret(), time() );
		if ( ! $ok['ok'] ) {
			return new \WP_REST_Response( [ 'error' => $ok['reason'] ], 400 );
		}
		$event = json_decode( $body, true );
		if ( ! is_array( $event ) || empty( $event['id'] ) ) {
			return new \WP_REST_Response( [ 'error' => 'not an event' ], 400 );
		}
		$res = Sync::feed( $event );
		// 503 makes Stripe send it again later (an invoice that beat its subscription); a processing error is a 500 for the same reason
		$http = 'retry' === $res['status'] ? 503 : ( 'error' === $res['status'] ? 500 : 200 );
		return new \WP_REST_Response( $res, $http );
	}
}
