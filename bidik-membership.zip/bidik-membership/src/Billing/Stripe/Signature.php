<?php
namespace Bidik\Billing\Stripe;

/** Pure: checks the `Stripe-Signature` header the way Stripe documents it (v1 = HMAC-SHA256 of "timestamp.payload"; any v1 may match; a 5-minute tolerance stops replays). */
final class Signature {
	public const TOLERANCE = 300;

	/** @return array{ok:bool,reason:string} */
	public static function verify( string $payload, string $header, string $secret, int $now, int $tolerance = self::TOLERANCE ): array {
		if ( '' === $secret ) {
			return [ 'ok' => false, 'reason' => 'no webhook secret is configured' ];
		}
		$t  = null;
		$v1 = [];
		foreach ( explode( ',', $header ) as $part ) {
			[ $k, $v ] = array_pad( explode( '=', trim( $part ), 2 ), 2, '' );
			if ( 't' === $k ) {
				$t = ctype_digit( $v ) ? (int) $v : null;
			} elseif ( 'v1' === $k && '' !== $v ) {
				$v1[] = $v;
			}
		}
		if ( null === $t || ! $v1 ) {
			return [ 'ok' => false, 'reason' => 'the signature header is missing or malformed' ];
		}
		if ( abs( $now - $t ) > $tolerance ) {
			return [ 'ok' => false, 'reason' => 'the timestamp is outside the tolerance' ];
		}
		$expected = hash_hmac( 'sha256', $t . '.' . $payload, $secret );
		foreach ( $v1 as $sig ) {
			if ( hash_equals( $expected, $sig ) ) {
				return [ 'ok' => true, 'reason' => '' ];
			}
		}
		return [ 'ok' => false, 'reason' => 'no signature matches the payload' ];
	}

	/** For tests and tools: the header Stripe would send. */
	public static function header( string $payload, string $secret, int $t ): string {
		return 't=' . $t . ',v1=' . hash_hmac( 'sha256', $t . '.' . $payload, $secret );
	}
}
