<?php
namespace Bidik\Billing\Stripe;

use Bidik\Billing\PlanChange;

defined( 'ABSPATH' ) || exit;

/** What Bidik sells, as Stripe knows it: a product per paid tier, a price per level (found by lookup key, so running it twice creates nothing), the two discount codes, and a customer-portal setup. */
final class Catalog {
	private const OPTION = 'bidik_stripe_catalog';
	public const COUPONS = [ 'bidik30' => [ 'name' => 'BIDIK30', 'percent' => 30 ], 'friend10' => [ 'name' => 'FRIEND10', 'percent' => 10 ] ];

	/** @return array{prices:array<int,string>,portal:string} */
	public static function state(): array {
		return array_merge( [ 'prices' => [], 'portal' => '' ], (array) get_option( self::OPTION, [] ) );
	}

	/** @return array<string,mixed> what was created or found */
	public static function ensure(): array {
		$state = self::state();
		$log   = [ 'prices' => [], 'coupons' => [], 'portal' => '' ];
		$prod  = [];
		foreach ( \pmpro_getAllLevels( true, false, true ) as $l ) {
			$lv = PlanChange::level( (int) $l->id );
			if ( ! $lv || 'free' === $lv['tier'] || $lv['price'] <= 0 ) {
				continue;
			}
			$key   = 'bidik_' . $lv['tier'] . '_' . $lv['interval'];
			$found = Client::call( 'GET', '/v1/prices', [ 'lookup_keys' => [ $key ], 'active' => 'true', 'limit' => 1 ] )['data'][0] ?? null;
			if ( $found && (int) $found['unit_amount'] === $lv['price'] ) {
				$state['prices'][ $lv['id'] ] = $found['id'];
				$log['prices'][ $key ]        = 'found';
				continue;
			}
			$prod[ $lv['tier'] ] ??= Client::call( 'POST', '/v1/products', [ 'name' => 'Bidik ' . ucfirst( $lv['tier'] ), 'metadata' => [ 'bidik_tier' => $lv['tier'] ] ], 'bidik-product-' . $lv['tier'] . '-' . site_url() )['id'];
			$price = Client::call( 'POST', '/v1/prices', [ 'product' => $prod[ $lv['tier'] ], 'currency' => 'usd', 'unit_amount' => $lv['price'], 'recurring' => [ 'interval' => $lv['interval'] ], 'lookup_key' => $key, 'transfer_lookup_key' => 'true', 'metadata' => [ 'bidik_level_id' => $lv['id'] ] ] );
			$state['prices'][ $lv['id'] ] = $price['id'];
			$log['prices'][ $key ]        = 'created';
		}
		foreach ( self::COUPONS as $id => $c ) {
			$log['coupons'][ $id ] = Client::find( '/v1/coupons/' . $id ) ? 'found' : 'created';
			if ( 'created' === $log['coupons'][ $id ] ) {
				Client::call( 'POST', '/v1/coupons', [ 'id' => $id, 'name' => $c['name'], 'percent_off' => $c['percent'], 'duration' => 'forever' ] );
			}
		}
		if ( '' === $state['portal'] ) {
			$cfg = Client::call( 'POST', '/v1/billing_portal/configurations', [
				'business_profile' => [ 'headline' => 'Manage your Bidik membership' ],
				'features' => [
					'invoice_history' => [ 'enabled' => 'true' ], 'payment_method_update' => [ 'enabled' => 'true' ],
					'subscription_cancel' => [ 'enabled' => 'true', 'mode' => 'at_period_end', 'proration_behavior' => 'none' ],
					'customer_update' => [ 'enabled' => 'true', 'allowed_updates' => [ 'email', 'name' ] ],
				],
				'default_return_url' => (string) get_permalink( (int) get_option( 'pmpro_account_page_id' ) ),
			] );
			$state['portal'] = $cfg['id'];
		}
		$log['portal'] = $state['portal'];
		update_option( self::OPTION, $state, false );
		return $log;
	}

	public static function price_for( int $level_id ): string {
		$p = self::state()['prices'][ $level_id ] ?? '';
		if ( '' === $p ) {
			self::ensure();
			$p = self::state()['prices'][ $level_id ] ?? '';
		}
		if ( '' === $p ) {
			throw new \RuntimeException( 'That plan has no price in Stripe.' );
		}
		return $p;
	}
}
