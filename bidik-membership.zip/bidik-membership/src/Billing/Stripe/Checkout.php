<?php
namespace Bidik\Billing\Stripe;

use Bidik\Billing\PlanChange;

defined( 'ABSPATH' ) || exit;

/** Sends a new member to Stripe Checkout (hosted: Stripe collects and keeps the card) and brings them back. */
final class Checkout {
	public static function register(): void {
		add_action( 'template_redirect', [ self::class, 'back' ] );
		add_action( 'rest_api_init', static function (): void {
			register_rest_route( 'bidik/v1', '/stripe/portal', [ 'methods' => 'POST', 'permission_callback' => 'is_user_logged_in', 'callback' => static function () {
				try {
					return [ 'url' => self::portal( get_current_user_id() ) ];
				} catch ( \RuntimeException $e ) {
					return new \WP_Error( 'bidik_stripe', $e->getMessage(), [ 'status' => 422 ] );
				}
			} ] );
		} );
	}

	public static function customer( int $user_id ): string {
		$id = (string) get_user_meta( $user_id, 'bidik_stripe_customer', true );
		if ( '' !== $id ) {
			return $id;
		}
		$u   = get_userdata( $user_id );
		$c   = Client::call( 'POST', '/v1/customers', [ 'email' => $u->user_email, 'name' => $u->display_name, 'metadata' => [ 'user_id' => $user_id ] ], 'bidik-customer-' . $user_id . '-' . site_url() );
		update_user_meta( $user_id, 'bidik_stripe_customer', $c['id'] );
		return (string) $c['id'];
	}

	/** @param object $order PMPro MemberOrder, already saved as "review" @return string the Stripe-hosted page to send the member to */
	public static function start( int $user_id, $order ): string {
		$level = $order->membership_level;
		$trial = (int) get_pmpro_membership_level_meta( (int) $level->id, 'bidik_trial_days', true );
		$code  = strtolower( sanitize_text_field( (string) ( $_REQUEST['pmpro_discount_code'] ?? $_REQUEST['other_discount_code'] ?? '' ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$p     = [
			'mode' => 'subscription', 'customer' => self::customer( $user_id ), 'client_reference_id' => $user_id,
			'adaptive_pricing' => [ 'enabled' => 'false' ], // Bidik prices in USD; do not let Stripe show or charge the visitor's own currency
			'line_items' => [ [ 'price' => Catalog::price_for( (int) $level->id ), 'quantity' => 1 ] ],
			'subscription_data' => [ 'metadata' => [ 'user_id' => $user_id, 'level_id' => (int) $level->id ] ],
			'success_url' => home_url( '/' ) . '?bidik_stripe_return={CHECKOUT_SESSION_ID}', 'cancel_url' => add_query_arg( 'pmpro_level', (int) $level->id, (string) get_permalink( (int) get_option( 'pmpro_checkout_page_id' ) ) ),
		];
		if ( $trial > 0 ) {
			$p['subscription_data']['trial_period_days'] = $trial;
		}
		if ( isset( Catalog::COUPONS[ $code ] ) ) {
			$p['discounts'] = [ [ 'coupon' => $code ] ];
		}
		return (string) Client::call( 'POST', '/v1/checkout/sessions', $p )['url'];
	}

	/** Back from Stripe: bring the subscription in, then show PMPro's welcome page. */
	public static function back(): void {
		$sid = isset( $_GET['bidik_stripe_return'] ) ? sanitize_text_field( wp_unslash( $_GET['bidik_stripe_return'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' === $sid || ! is_user_logged_in() || ! preg_match( '/^cs_[A-Za-z0-9_]+$/', $sid ) ) {
			return;
		}
		$uid = get_current_user_id();
		try {
			$sub = Sync::pull_session( $sid, $uid );
			// The order PMPro saved before the redirect is now paid for on Stripe's side: close it, so PMPro's confirmation page has a finished order to show.
			$order = new \MemberOrder();
			$order->getLastMemberOrder( $uid, 'review' );
			if ( ! empty( $order->id ) ) {
				$order->status = 'success';
				$order->saveOrder();
			}
			$to  = add_query_arg( 'pmpro_level', (int) ( $sub['metadata']['level_id'] ?? 0 ), (string) get_permalink( (int) get_option( 'pmpro_confirmation_page_id' ) ) );
		} catch ( \RuntimeException $e ) {
			$to = add_query_arg( 'stripe', 'pending', \Bidik\Account\Account::url( 'billing' ) ); // the webhook will still bring it in
		}
		wp_safe_redirect( $to );
		exit;
	}

	/** The Stripe-hosted page where the member changes card, switches plan or cancels. */
	public static function portal( int $user_id ): string {
		$customer = (string) get_user_meta( $user_id, 'bidik_stripe_customer', true );
		if ( '' === $customer ) {
			throw new \RuntimeException( 'No Stripe customer for this account yet.' );
		}
		Catalog::state()['portal'] ?: Catalog::ensure();
		return (string) Client::call( 'POST', '/v1/billing_portal/sessions', [ 'customer' => $customer, 'configuration' => Catalog::state()['portal'], 'return_url' => \Bidik\Account\Account::url( 'billing' ) ] )['url'];
	}
}
