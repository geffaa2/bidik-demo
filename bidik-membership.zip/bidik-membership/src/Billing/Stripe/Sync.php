<?php
namespace Bidik\Billing\Stripe;

use Bidik\Billing\PlanChange;
use Bidik\Billing\WebhookProcessor;

defined( 'ABSPATH' ) || exit;

/** Gets Stripe's events into the one billing pipeline: from the webhook, or by asking Stripe (after checkout, and in tests). */
final class Sync {
	/** @return array{status:string,detail?:string} processed | duplicate | ignored | retry | error */
	public static function feed( array $event ): array {
		global $wpdb;
		$n = Events::normalize( $event, static fn( int $level ) => (string) ( PlanChange::level( $level )['name'] ?? '' ) );
		if ( null === $n ) {
			return [ 'status' => 'ignored', 'detail' => 'Nothing for Bidik to do for ' . ( $event['type'] ?? 'this event' ) . '.' ];
		}
		$r = WebhookProcessor::handle( 'stripe', $n );
		// Stripe does not promise an order: an invoice can arrive before its subscription. Forget the event and ask Stripe to send it again.
		if ( 'ignored' === $r['status'] && str_contains( (string) ( $r['detail'] ?? '' ), 'unknown subscription' ) ) {
			$wpdb->delete( $wpdb->prefix . 'bidik_events', [ 'gateway' => 'stripe', 'event_id' => $n['id'] ] );
			return [ 'status' => 'retry', 'detail' => $r['detail'] ];
		}
		return $r;
	}

	/**
	 * After the member returns from Stripe Checkout: read what was bought and run it through the pipeline, so the account is ready on the welcome
	 * page without waiting for the webhook. The webhook that follows is harmless (every step is idempotent).
	 *
	 * @return array<string,mixed> the subscription as Stripe has it
	 */
	public static function pull_session( string $session_id, int $expect_user ): array {
		$cs = Client::call( 'GET', '/v1/checkout/sessions/' . rawurlencode( $session_id ), [ 'expand' => [ 'subscription.latest_invoice' ] ] );
		if ( (int) ( $cs['client_reference_id'] ?? 0 ) !== $expect_user ) {
			throw new \RuntimeException( 'That checkout belongs to someone else.' );
		}
		$sub = $cs['subscription'] ?? null;
		if ( ! is_array( $sub ) ) {
			throw new \RuntimeException( 'That checkout has no subscription yet.' );
		}
		update_user_meta( $expect_user, 'bidik_stripe_customer', (string) $cs['customer'] );
		self::feed( [ 'id' => 'evt_pull_' . $sub['id'] . '_created', 'type' => 'customer.subscription.created', 'data' => [ 'object' => $sub ] ] );
		$inv = $sub['latest_invoice'] ?? null;
		if ( is_array( $inv ) && 'paid' === ( $inv['status'] ?? '' ) ) {
			self::feed( [ 'id' => 'evt_pull_' . $inv['id'] . '_paid', 'type' => 'invoice.paid', 'data' => [ 'object' => $inv ] ] );
		}
		return $sub;
	}

	/** Feeds every subscription-related event Stripe holds for a customer, oldest first (the tests' stand-in for webhooks). @return int events fed */
	public static function pull_customer( string $customer ): int {
		$events = Client::call( 'GET', '/v1/events', [ 'limit' => 100, 'types' => [ 'customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted', 'invoice.paid', 'invoice.payment_failed' ] ] )['data'];
		$mine   = array_values( array_filter( $events, static fn( $e ) => str_contains( (string) wp_json_encode( $e ), $customer ) ) );
		usort( $mine, static fn( $a, $b ) => $a['created'] <=> $b['created'] );
		foreach ( $mine as $e ) {
			self::feed( $e );
		}
		return count( $mine );
	}
}
