<?php
namespace Bidik\Billing\Stripe;

/**
 * Pure: turns a real Stripe event (API version 2026-02-25.clover, checked against events from a test-mode account) into the shape
 * WebhookProcessor takes. Two things differ from what the sandbox sends, and both come from the real API:
 *   - an invoice names its subscription at parent.subscription_details.subscription, not at the top;
 *   - a subscription's billing period lives on its item (items.data[0].current_period_start/end), not on the subscription.
 * Which events move a subscription's status is decided here on purpose: only invoice events move active and past_due
 * (so the grace period is always started by the failed payment), and a subscription.updated never moves status itself.
 */
final class Events {
	/** @param ?callable(int):string $describe level id => "Member, monthly" @return array<string,mixed>|null null = nothing for Bidik to do */
	public static function normalize( array $e, ?callable $describe = null ): ?array {
		$type = (string) ( $e['type'] ?? '' );
		$obj  = $e['data']['object'] ?? null;
		if ( ! is_array( $obj ) || empty( $e['id'] ) ) {
			return null;
		}
		return match ( $type ) {
			'customer.subscription.created', 'customer.subscription.updated', 'customer.subscription.deleted' => self::subscription( $e, $type, $obj ),
			'invoice.paid', 'invoice.payment_failed' => self::invoice( $e, $type, $obj, $describe ),
			default => null,
		};
	}

	private static function wrap( array $e, string $type, array $obj ): array {
		return [ 'id' => (string) $e['id'], 'type' => $type, 'data' => [ 'object' => $obj ] ];
	}

	private static function subscription( array $e, string $type, array $s ): ?array {
		$item = $s['items']['data'][0] ?? [];
		$meta = (array) ( $s['metadata'] ?? [] );
		$obj  = [
			'id' => (string) $s['id'], 'customer' => (string) ( $s['customer'] ?? '' ), 'metadata' => array_filter( [ 'user_id' => (int) ( $meta['user_id'] ?? 0 ), 'level_id' => (int) ( $meta['level_id'] ?? 0 ) ] ),
			'current_period_start' => $item['current_period_start'] ?? null, 'current_period_end' => $item['current_period_end'] ?? null,
			'trial_end' => $s['trial_end'] ?? null, 'cancel_at_period_end' => (bool) ( $s['cancel_at_period_end'] ?? false ),
		];
		if ( 'customer.subscription.created' === $type ) {
			if ( ! in_array( $s['status'] ?? '', [ 'trialing', 'active' ], true ) || empty( $obj['metadata']['user_id'] ) || empty( $obj['metadata']['level_id'] ) ) {
				return null; // not paid for yet (incomplete) or not one of ours (no user): the event that follows payment will carry it
			}
			$obj['status'] = (string) $s['status'];
		} elseif ( 'customer.subscription.deleted' === $type ) {
			$obj['metadata'] = [ 'churn_type' => 'payment_failed' === ( $s['cancellation_details']['reason'] ?? '' ) ? 'involuntary' : 'voluntary' ];
		} else { // updated: never move status here, except a pause starting or ending
			unset( $obj['metadata']['level_id'] ); // a plan change is applied by Bidik itself, not by echoing the old metadata back
			$pc = $s['pause_collection'] ?? null;
			if ( $pc ) {
				$obj['status']      = 'paused';
				$obj['pause_until'] = $pc['resumes_at'] ?? null;
			} elseif ( array_key_exists( 'pause_collection', (array) ( $e['data']['previous_attributes'] ?? [] ) ) && ! empty( $e['data']['previous_attributes']['pause_collection'] ) ) {
				$obj['status']      = 'active';
				$obj['pause_until'] = null;
			}
		}
		return self::wrap( $e, $type, $obj );
	}

	private static function invoice( array $e, string $type, array $o, ?callable $describe ): ?array {
		$sub = $o['parent']['subscription_details']['subscription'] ?? null;
		if ( ! $sub ) {
			return null; // a one-off invoice: not a membership
		}
		$meta   = (array) ( $o['parent']['subscription_details']['metadata'] ?? [] );
		$level  = (int) ( $meta['level_id'] ?? 0 );
		$name   = $describe && $level ? $describe( $level ) : '';
		$lines  = [];
		foreach ( (array) ( $o['lines']['data'] ?? [] ) as $l ) {
			$lines[] = [ 'description' => $name ? $name . ( 0 === (int) ( $l['amount'] ?? 0 ) ? ' (trial)' : '' ) : self::clean( (string) ( $l['description'] ?? 'Membership' ) ), 'amount' => (int) ( $l['amount'] ?? 0 ) ];
		}
		$obj = [ 'id' => (string) $o['id'], 'subscription' => (string) $sub, 'currency' => (string) ( $o['currency'] ?? 'usd' ), 'created' => (int) ( $o['created'] ?? 0 ), 'billing_reason' => (string) ( $o['billing_reason'] ?? '' ), 'lines' => $lines ];
		if ( 'invoice.paid' === $type ) {
			$obj['amount_paid'] = (int) ( $o['amount_paid'] ?? 0 );
			// a renewal buys the period on its line; the first invoice and mid-period charges leave the period to the subscription itself
			$p = $o['lines']['data'][0]['period'] ?? null;
			if ( 'subscription_cycle' === ( $o['billing_reason'] ?? '' ) && $p && ! empty( $p['start'] ) && ! empty( $p['end'] ) && (int) $p['end'] > (int) $p['start'] ) {
				$obj['period_start'] = (int) $p['start'];
				$obj['period_end']   = (int) $p['end'];
			}
		} else {
			$obj['amount_due'] = (int) ( $o['amount_due'] ?? 0 );
		}
		return self::wrap( $e, $type, $obj );
	}

	/** "1 × Bidik Member (at $12.00 / month)" is Stripe's wording; people read "Bidik Member". */
	private static function clean( string $d ): string {
		return trim( (string) preg_replace( '/\s*\(at [^)]*\)\s*$/', '', (string) preg_replace( '/^\d+\s*×\s*/u', '', $d ) ) );
	}
}
