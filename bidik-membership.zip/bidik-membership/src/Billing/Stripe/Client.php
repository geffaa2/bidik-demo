<?php
namespace Bidik\Billing\Stripe;

defined( 'ABSPATH' ) || exit;

/** Stripe's REST API over wp_remote_request, pinned to the API version the events were checked against. No SDK, so nothing to install. */
final class Client {
	public const VERSION = '2026-02-25.clover';

	/**
	 * @param array<string,mixed> $params nested arrays become Stripe's bracket syntax (items[0][price]=...)
	 * @return array<string,mixed>
	 * @throws \RuntimeException message is Stripe's own; code is the HTTP status
	 */
	public static function call( string $method, string $path, array $params = [], ?string $idempotency_key = null ): array {
		if ( ! Config::enabled() ) {
			throw new \RuntimeException( 'Stripe is not configured (or a live key was given without BIDIK_STRIPE_ALLOW_LIVE).' );
		}
		$url  = 'https://api.stripe.com' . $path;
		$args = [ 'method' => $method, 'timeout' => 30, 'headers' => [ 'Authorization' => 'Bearer ' . Config::secret(), 'Stripe-Version' => self::VERSION ] ];
		if ( 'GET' === $method || 'DELETE' === $method ) {
			$url .= $params ? '?' . http_build_query( $params ) : '';
		} else {
			$args['body'] = http_build_query( $params );
			$args['headers']['Content-Type'] = 'application/x-www-form-urlencoded';
			if ( $idempotency_key ) {
				$args['headers']['Idempotency-Key'] = $idempotency_key;
			}
		}
		$res = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			throw new \RuntimeException( 'Could not reach Stripe: ' . $res->get_error_message(), 0 );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$json = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code >= 400 || ! is_array( $json ) ) {
			throw new \RuntimeException( is_array( $json ) && isset( $json['error']['message'] ) ? (string) $json['error']['message'] : "Stripe answered HTTP $code.", $code );
		}
		return $json;
	}

	/** GET that returns null on 404 (for "does it exist yet?"). @return array<string,mixed>|null */
	public static function find( string $path, array $params = [] ): ?array {
		try {
			return self::call( 'GET', $path, $params );
		} catch ( \RuntimeException $e ) {
			if ( 404 === $e->getCode() ) {
				return null;
			}
			throw $e;
		}
	}
}
