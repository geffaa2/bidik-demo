<?php
namespace Bidik\Billing\Stripe;

defined( 'ABSPATH' ) || exit;

/**
 * Keys live in wp-config.php constants (or the environment), never in the database and never in the repository:
 *   BIDIK_STRIPE_SECRET, BIDIK_STRIPE_PUBLISHABLE, BIDIK_STRIPE_WEBHOOK_SECRET.
 * Only test-mode secret keys (sk_test_...) are accepted unless BIDIK_STRIPE_ALLOW_LIVE is true, so a mistake cannot charge a real card.
 */
final class Config {
	private static function get( string $name ): string {
		$v = defined( $name ) ? constant( $name ) : getenv( $name );
		return is_string( $v ) ? trim( $v ) : '';
	}

	public static function secret(): string {
		return self::get( 'BIDIK_STRIPE_SECRET' );
	}

	public static function publishable(): string {
		return self::get( 'BIDIK_STRIPE_PUBLISHABLE' );
	}

	public static function webhook_secret(): string {
		return self::get( 'BIDIK_STRIPE_WEBHOOK_SECRET' );
	}

	public static function live(): bool {
		return str_starts_with( self::secret(), 'sk_live_' ) || str_starts_with( self::secret(), 'rk_live_' );
	}

	/** True when there is a usable key: test mode, or live mode that was explicitly allowed. */
	public static function enabled(): bool {
		$k = self::secret();
		if ( '' === $k ) {
			return false;
		}
		return self::live() ? ( defined( 'BIDIK_STRIPE_ALLOW_LIVE' ) && BIDIK_STRIPE_ALLOW_LIVE ) : str_starts_with( $k, 'sk_test_' ) || str_starts_with( $k, 'rk_test_' );
	}

	public static function mode(): string {
		return self::live() ? 'live' : 'test';
	}
}
