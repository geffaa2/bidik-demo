<?php
namespace Bidik\Billing;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/** The member's card on file (sandbox: only the test cards are accepted; no card number is ever stored, only brand, last 4 and expiry). */
final class Cards {
	/** @return array{brand:string,last4:string,exp:string,renews:bool}|null */
	public static function get( int $user_id ): ?array {
		$c = get_user_meta( $user_id, 'bidik_card', true );
		return is_array( $c ) && ! empty( $c['last4'] ) ? [ 'brand' => (string) ( $c['brand'] ?? 'Visa' ), 'last4' => (string) $c['last4'], 'exp' => (string) ( $c['exp'] ?? '' ), 'renews' => (bool) ( $c['renews'] ?? true ) ] : null;
	}

	/** True when the card's expiry month has passed, or is the current month (a gentle warning, not a failure). */
	public static function expiry_state( array $card, int $now ): string {
		if ( ! preg_match( '#^(\d{1,2})/(\d{4})$#', $card['exp'], $m ) ) {
			return 'unknown';
		}
		$end = ( new \DateTimeImmutable( sprintf( '%04d-%02d-01 00:00:00', $m[2], $m[1] ), new \DateTimeZone( 'UTC' ) ) )->modify( 'last day of this month 23:59:59' )->getTimestamp();
		if ( $end < $now ) {
			return 'expired';
		}
		return gmdate( 'Y-m', $now ) === sprintf( '%04d-%02d', $m[2], $m[1] ) ? 'expiring' : 'ok';
	}

	/**
	 * @throws \DomainException with a message that is safe to show
	 * @return array{card:array<string,mixed>,retried:bool}
	 */
	public static function update( int $user_id, string $number, string $exp, string $cvc ): array {
		$digits = preg_replace( '/\D/', '', $number );
		$check  = Sandbox::card( $digits );
		if ( ! $check['ok'] ) {
			throw new \DomainException( $check['error'] );
		}
		if ( ! preg_match( '#^\s*(\d{1,2})\s*/\s*(\d{2}|\d{4})\s*$#', $exp, $m ) || (int) $m[1] < 1 || (int) $m[1] > 12 ) {
			throw new \DomainException( 'Enter the expiry date as MM/YY, for example 08/29.' );
		}
		$year = 2 === strlen( $m[2] ) ? 2000 + (int) $m[2] : (int) $m[2];
		$card = [ 'brand' => $check['brand'], 'last4' => $check['last4'], 'exp' => sprintf( '%d/%d', (int) $m[1], $year ), 'renews' => $check['renews'] ];
		if ( 'expired' === self::expiry_state( $card, Clock::now() ) ) {
			throw new \DomainException( 'That card has expired. Use a card with a future expiry date.' );
		}
		if ( ! preg_match( '/^\d{3,4}$/', trim( $cvc ) ) ) {
			throw new \DomainException( 'Enter the 3-digit security code from the back of the card.' );
		}
		update_user_meta( $user_id, 'bidik_card', $card );
		return [ 'card' => $card, 'retried' => self::retry_open_invoice( $user_id ) ];
	}

	/** A new card on a past-due subscription pays the open invoice straight away. */
	private static function retry_open_invoice( int $user_id ): bool {
		global $wpdb;
		$sub = PlanChange::subscription( $user_id );
		if ( ! $sub || 'past_due' !== $sub['status'] ) {
			return false;
		}
		$inv = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_invoices WHERE subscription_id = %d AND status = 'open' ORDER BY id DESC LIMIT 1", (int) $sub['id'] ), ARRAY_A );
		if ( ! $inv ) {
			return false;
		}
		// The failed invoice was the renewal of the period that began where the last one ended. Paying it late still buys that period:
		// without moving the period on, the next billing day would see it as overdue and charge again.
		$lvl   = PlanChange::level( (int) $sub['level_id'] );
		$start = (int) ( new \DateTimeImmutable( (string) $sub['current_period_end'], new \DateTimeZone( 'UTC' ) ) )->getTimestamp();
		$end   = ( new \DateTimeImmutable( '@' . $start ) )->modify( 'year' === ( $lvl['interval'] ?? 'month' ) ? '+1 year' : '+1 month' )->getTimestamp();
		$r = WebhookProcessor::handle( 'sandbox', [ 'id' => 'evt_sbx_retry_' . substr( wp_generate_uuid4(), 0, 8 ), 'type' => 'invoice.paid', 'data' => [ 'object' => [
			'id' => (string) $inv['gateway_invoice_id'], 'subscription' => (string) $sub['gateway_subscription_id'], 'amount_paid' => (int) $inv['amount_cents'], 'currency' => 'usd',
			'lines' => json_decode( (string) $inv['line_items'], true ) ?: [], 'created' => Clock::now(), 'period_start' => $start, 'period_end' => $end,
		] ] ] );
		return 'processed' === $r['status'];
	}
}
