<?php
namespace Bidik\Billing;

use Bidik\Support\Clock;

defined( 'ABSPATH' ) || exit;

/**
 * After PMPro finishes a sandbox checkout, turn the order into the same events Stripe would send,
 * so the subscription, the invoice, the emails and the access all come from one code path (the processor).
 */
final class CheckoutBridge {
	public static function register(): void {
		add_action( 'pmpro_after_checkout', [ self::class, 'after_checkout' ], 20, 2 );
		add_filter( 'pmpro_send_checkout_emails', '__return_false' );
		add_action( 'pmpro_checkout_processing_failed', [ self::class, 'keep_billing_details' ] );
		add_filter( 'pmpro_confirmation_message', [ self::class, 'confirmation' ], 10, 2 );
	}

	/**
	 * PMPro creates the account before it takes payment and, when the card is declined, shows the form again
	 * from user meta, not from the request. Save what was typed so the visitor only has to fix the card.
	 */
	public static function keep_billing_details( $order ): void {
		$user_id = (int) ( $order->user_id ?? get_current_user_id() );
		if ( ! $user_id ) {
			return;
		}
		foreach ( [ 'bfirstname', 'blastname', 'baddress1', 'baddress2', 'bcity', 'bstate', 'bzipcode', 'bcountry', 'bphone', 'bemail' ] as $field ) {
			if ( isset( $_REQUEST[ $field ] ) ) {
				update_user_meta( $user_id, 'pmpro_' . $field, sanitize_text_field( wp_unslash( $_REQUEST[ $field ] ) ) );
			}
		}
	}

	/** @param object $order PMPro MemberOrder */
	public static function after_checkout( int $user_id, $order ): void {
		if ( 'bidik_sandbox' !== ( $order->gateway ?? '' ) || empty( $order->subscription_transaction_id ) ) {
			return;
		}
		$level = $order->membership_level;
		$now   = Clock::now();
		$days  = (int) get_pmpro_membership_level_meta( (int) $level->id, 'bidik_trial_days', true );
		$trial = $days > 0;
		$start = new \DateTimeImmutable( '@' . $now );
		$end   = $trial ? $start->modify( "+$days days" ) : $start->modify( 'Year' === $level->cycle_period ? '+1 year' : '+1 month' );
		$sub   = (string) $order->subscription_transaction_id;
		$code  = (string) $order->code;
		$paid  = $trial ? 0 : (int) round( (float) $order->total * 100 );
		$what  = $level->name . ( $trial ? ", {$days}-day trial" : '' );

		$digits = preg_replace( '/\D/', '', (string) ( $_REQUEST['AccountNumber'] ?? '' ) );
		$card   = Sandbox::card( $digits );
		update_user_meta( $user_id, 'bidik_card', [ 'brand' => $card['brand'] ?: 'Visa', 'last4' => substr( $digits, -4 ), 'renews' => $card['renews'],
			'exp' => (int) ( $_REQUEST['ExpirationMonth'] ?? 0 ) . '/' . (int) ( $_REQUEST['ExpirationYear'] ?? 0 ) ] ); // no number and no code are kept

		WebhookProcessor::handle( 'sandbox', [
			'id'   => "evt_sbx_sub_$code",
			'type' => 'customer.subscription.created',
			'data' => [ 'object' => [
				'id' => $sub, 'customer' => 'cus_sbx_' . $user_id, 'status' => $trial ? 'trialing' : 'active',
				'current_period_start' => $now, 'current_period_end' => $end->getTimestamp(), 'trial_end' => $trial ? $end->getTimestamp() : null,
				'metadata' => [ 'user_id' => $user_id, 'level_id' => (int) $level->id ],
			] ],
		] );
		WebhookProcessor::handle( 'sandbox', [
			'id'   => "evt_sbx_inv_$code",
			'type' => 'invoice.paid',
			'data' => [ 'object' => [
				'id' => "in_sbx_$code", 'subscription' => $sub, 'amount_paid' => $paid, 'currency' => 'usd', 'billing_reason' => 'subscription_create',
				'period_start' => $now, 'period_end' => $end->getTimestamp(),
				'lines' => [ [ 'description' => $what, 'amount' => $paid ] ],
			] ],
		] );
	}

	/** Welcome copy that says exactly what happens next. */
	public static function confirmation( string $message, $invoice ): string {
		global $wpdb, $current_user;
		$sub = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bidik_subscriptions WHERE user_id = %d ORDER BY id DESC LIMIT 1", (int) $current_user->ID ), ARRAY_A );
		if ( ! $sub ) {
			return $message;
		}
		$level = pmpro_getLevel( (int) $sub['level_id'] );
		$tz    = wp_timezone();
		$fmt   = static fn( string $mysql ) => ( new \DateTimeImmutable( $mysql, new \DateTimeZone( 'UTC' ) ) )->setTimezone( $tz )->format( 'D j M Y' );
		$price   = '$' . number_format( MembershipSync::price_for( (int) $sub['user_id'], (int) $sub['level_id'] ), 2 );
		$charged = '$' . number_format( MembershipSync::last_charge( (int) $sub['id'] ), 2 );
		if ( 'trialing' === $sub['status'] ) {
			$body = '<p>Your 7-day trial of <strong>' . esc_html( $level->name ) . '</strong> is running until <strong>' . esc_html( $fmt( $sub['trial_end'] ) ) . '</strong>. You are not charged before then.</p>'
				. '<p>The first charge is <strong>' . esc_html( $price ) . '</strong> on ' . esc_html( $fmt( $sub['trial_end'] ) ) . '. Cancel from your account any time before that and you pay nothing.</p>';
		} else {
			$body = '<p>Your <strong>' . esc_html( $level->name ) . '</strong> membership is active. We charged <strong>' . esc_html( $charged ) . '</strong> today and it renews on <strong>' . esc_html( $fmt( $sub['current_period_end'] ) ) . '</strong> for ' . esc_html( $price ) . '.</p>';
		}
		return '<h2>You are in. Welcome to Bidik.</h2>' . $body
			. '<p>A confirmation is on its way to your email. <a href="' . esc_url( get_permalink( (int) get_option( 'pmpro_account_page_id' ) ) ) . '">Open your account</a></p>';
	}
}
