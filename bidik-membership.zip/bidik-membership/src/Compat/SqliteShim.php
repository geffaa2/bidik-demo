<?php
namespace Bidik\Compat;

defined( 'ABSPATH' ) || exit;

/**
 * Lets Paid Memberships Pro run on SQLite (WordPress Playground, used for the live demo).
 *
 * PMPro is written for MySQL. On SQLite two of its core read paths fail:
 *  - CONVERT_TZ( x, '+00:00', @@global.time_zone ) is not a SQLite function (member level lookup, member list).
 *  - Post gating builds "(SELECT ..) UNION (SELECT ..)" with parenthesised members, which SQLite rejects.
 *  - "GROUP BY ID" over "l.id AS ID" joined to memberships_users is ambiguous in SQLite (active level lookup).
 * The demo site runs in UTC, so CONVERT_TZ is an identity there. Client sites run on MySQL, where this shim is inactive.
 * See docs/spikes.md (spike A1).
 */
final class SqliteShim {
	public static function register(): void {
		if ( ! self::is_sqlite() ) {
			return;
		}
		add_filter( 'query', [ self::class, 'rewrite' ], 1 );
	}

	public static function is_sqlite(): bool {
		return defined( 'SQLITE_DB_DROPIN_VERSION' ) || class_exists( 'WP_SQLite_DB', false ) || ( $GLOBALS['wpdb'] ?? null ) instanceof \WP_SQLite_DB;
	}

	public static function rewrite( string $sql ): string {
		if ( false !== stripos( $sql, 'CONVERT_TZ(' ) ) {
			$sql = preg_replace( "/CONVERT_TZ\(\s*(.+?)\s*,\s*'\+00:00'\s*,\s*@@global\.time_zone\s*\)/i", '$1', $sql );
		}
		if ( false !== stripos( $sql, ') UNION (' ) ) {
			$sql = preg_replace( '/^\s*\((SELECT .*?)\)\s+UNION\s+\((SELECT .*)\)\s*$/is', '$1 UNION $2', $sql );
		}
		if ( false !== strpos( $sql, 'GROUP BY ID' ) && false !== strpos( $sql, 'pmpro_memberships_users AS mu' ) ) {
			$sql = str_replace( 'GROUP BY ID', 'GROUP BY l.id', $sql );
		}
		return $sql;
	}
}
