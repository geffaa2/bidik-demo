/* Interval toggle for [bidik_pricing]: a radiogroup with arrow-key support. */
(function () {
	var root = document.querySelector('.bidik-pricing');
	if (!root) return;
	var radios = Array.prototype.slice.call(root.querySelectorAll('.seg [role=radio]'));
	function select(radio) {
		radios.forEach(function (r) {
			var on = r === radio;
			r.setAttribute('aria-checked', on ? 'true' : 'false');
			r.tabIndex = on ? 0 : -1;
		});
		var interval = radio.getAttribute('data-interval');
		root.querySelectorAll('[data-interval-view]').forEach(function (el) {
			el.hidden = el.getAttribute('data-interval-view') !== interval;
		});
	}
	radios.forEach(function (radio, i) {
		radio.addEventListener('click', function () { select(radio); });
		radio.addEventListener('keydown', function (e) {
			var next = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
			if (!next) return;
			e.preventDefault();
			var target = radios[(i + next + radios.length) % radios.length];
			select(target);
			target.focus();
		});
	});
})();
