// Course editor: add and remove module rows.
(function () {
  var body = document.querySelector('#bidik-modules tbody');
  var tpl = document.getElementById('bidik-module-template');
  var add = document.getElementById('bidik-add-module');
  if (!body || !tpl || !add) return;
  add.addEventListener('click', function () {
    body.appendChild(tpl.content.cloneNode(true));
  });
  body.addEventListener('click', function (e) {
    var b = e.target.closest('.bidik-remove-module');
    if (!b) return;
    var row = b.closest('tr');
    if (body.rows.length > 1) row.remove();
    else row.querySelectorAll('input').forEach(function (i) { i.value = i.type === 'number' ? 0 : ''; });
  });
})();
