/* Demo bar: the Demo clock, "view as" and reset. Only present on a demo site (BIDIK_DEMO). */
(function () {
  var cfg = window.bidikDemo || {};
  var bar = document.querySelector('.bd-demobar');
  if (!bar) return;

  function api(path, data) {
    return fetch(cfg.root + path, { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/json' }, body: JSON.stringify(data || {}) })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j.message || 'Something went wrong.'); return j; }); });
  }
  var panels = { clock: bar.querySelector('#bd-demo-clock'), as: bar.querySelector('#bd-demo-as') };
  var openers = bar.querySelectorAll('[data-demo-open]');
  function closeAll(except) {
    openers.forEach(function (b) {
      var key = b.getAttribute('data-demo-open');
      var on = key === except;
      b.setAttribute('aria-expanded', on ? 'true' : 'false');
      panels[key].hidden = !on;
    });
  }
  openers.forEach(function (b) {
    b.addEventListener('click', function () {
      var key = b.getAttribute('data-demo-open');
      closeAll(b.getAttribute('aria-expanded') === 'true' ? null : key);
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    var open = bar.querySelector('[data-demo-open][aria-expanded=true]');
    if (open) { closeAll(null); open.focus(); }
  });

  // a note that survives the reload that follows a clock move
  var note = null;
  try { note = sessionStorage.getItem('bd-demo-note'); sessionStorage.removeItem('bd-demo-note'); } catch (e) {}
  if (note) {
    var flash = document.createElement('p');
    flash.className = 'bd-demobar__flash';
    flash.setAttribute('role', 'status');
    flash.textContent = note;
    bar.appendChild(flash);
  }
  function remember(text) { try { sessionStorage.setItem('bd-demo-note', text); } catch (e) {} }

  var clockNote = panels.clock.querySelector('.bd-demopanel__note');
  panels.clock.querySelectorAll('[data-demo-days]').forEach(function (b) {
    b.addEventListener('click', function () {
      panels.clock.querySelectorAll('button').forEach(function (x) { x.disabled = true; });
      clockNote.textContent = 'Working: charging renewals, running reminders…';
      api('clock', { days: +b.getAttribute('data-demo-days') }).then(function (r) {
        remember(r.message);
        window.location.reload();
      }).catch(function (err) {
        panels.clock.querySelectorAll('button').forEach(function (x) { x.disabled = false; });
        clockNote.textContent = err.message;
      });
    });
  });

  bar.querySelectorAll('[data-demo-as]').forEach(function (b) {
    b.addEventListener('click', function () {
      b.disabled = true;
      api('login', { persona: b.getAttribute('data-demo-as') }).then(function (r) {
        window.location.href = r.url;
      }).catch(function (err) { b.disabled = false; window.alert(err.message); });
    });
  });

  var reset = bar.querySelector('[data-demo-reset]');
  var armed = false;
  reset.addEventListener('click', function () {
    if (!armed) {
      armed = true;
      reset.textContent = 'Click again to reset everything';
      setTimeout(function () { armed = false; reset.textContent = 'Reset the whole demo'; }, 5000);
      return;
    }
    reset.disabled = true;
    reset.textContent = 'Resetting… this takes a little while';
    api('reset').then(function (r) {
      remember(r.message);
      window.location.href = r.url || '/';
    }).catch(function (err) { reset.disabled = false; reset.textContent = err.message; });
  });
})();
