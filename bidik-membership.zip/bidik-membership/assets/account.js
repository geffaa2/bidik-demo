/* Account and Pricing windows for signed-in members: change plan (with the exact price first), update card, undo, and the email switches. */
(function () {
  var cfg = window.bidikAccount || {};
  var scrim = document.querySelector('[data-bidik-scrim]');

  /* ---- switches (work without the dialog) ---- */
  document.querySelectorAll('[role=switch]').forEach(function (sw) {
    function flip() {
      var on = sw.getAttribute('aria-checked') !== 'true';
      sw.setAttribute('aria-checked', on ? 'true' : 'false');
      var hidden = sw.parentNode.querySelector('input[type=hidden]');
      if (hidden) hidden.value = on ? '1' : '0';
    }
    sw.addEventListener('click', flip);
    sw.addEventListener('keydown', function (e) { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); flip(); } });
  });
  if (!scrim) return;

  var dialog = scrim.querySelector('.dialog');
  var titleEl = dialog.querySelector('h2');
  var subEl = dialog.querySelector('.sub');
  var bodyEl = dialog.querySelector('.body');
  var footEl = dialog.querySelector('footer');
  var lastFocus = null;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function btn(label, cls, onClick) {
    var b = el('button', 'btn ' + cls, label);
    b.type = 'button';
    if (onClick) b.addEventListener('click', onClick);
    return b;
  }
  function focusables() {
    return Array.prototype.slice.call(dialog.querySelectorAll('button, [href], input, [tabindex]:not([tabindex="-1"])')).filter(function (n) { return !n.disabled && !n.hidden; });
  }
  function open(title, sub, trigger) {
    lastFocus = trigger || document.activeElement;
    titleEl.textContent = title;
    subEl.textContent = sub || '';
    subEl.hidden = !sub;
    bodyEl.textContent = '';
    footEl.textContent = '';
    scrim.hidden = false;
    document.body.style.overflow = 'hidden';
    dialog.focus();
  }
  function close() {
    scrim.hidden = true;
    document.body.style.overflow = '';
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  scrim.addEventListener('mousedown', function (e) { if (e.target === scrim) close(); });
  dialog.querySelector('[data-bidik-close]').addEventListener('click', close);
  document.addEventListener('keydown', function (e) {
    if (scrim.hidden) return;
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key !== 'Tab') return;
    var f = focusables();
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });

  function api(method, path, data) {
    var opts = { method: method, credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/json' } };
    if (data) opts.body = JSON.stringify(data);
    return fetch(cfg.root + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        if (!r.ok) throw new Error(j.message || 'Something went wrong. Try again.');
        return j;
      });
    });
  }
  function errorBox(msg) {
    var old = bodyEl.querySelector('.form-error');
    if (old) old.remove();
    var box = el('p', 'form-error', msg);
    box.setAttribute('role', 'alert');
    bodyEl.appendChild(box);
  }

  /* ---- change plan ---- */
  function renderPreview(p, trigger) {
    titleEl.textContent = p.title;
    subEl.textContent = p.sub || '';
    subEl.hidden = !p.sub;
    bodyEl.textContent = '';
    footEl.textContent = '';
    var swap = el('div', 'swap');
    swap.appendChild(el('span', 'from', p.swap[0]));
    swap.appendChild(el('span', 'to', p.swap[1]));
    swap.insertBefore(el('span', 'arrow', '→'), swap.children[1]);
    bodyEl.appendChild(swap);
    var table = el('table', 'prorate');
    table.appendChild(el('caption', 'sr', 'Charge breakdown'));
    (p.rows || []).forEach(function (r) {
      var tr = el('tr');
      var th = el('th', null, r[0]);
      th.setAttribute('scope', 'row');
      th.appendChild(el('small', null, r[1]));
      tr.appendChild(th);
      tr.appendChild(el('td', r[3] || '', r[2]));
      table.appendChild(tr);
    });
    var tot = el('tr', 'total');
    var tth = el('th', null, p.total[0]);
    tth.setAttribute('scope', 'row');
    tot.appendChild(tth);
    tot.appendChild(el('td', null, p.total[1]));
    table.appendChild(tot);
    bodyEl.appendChild(table);
    bodyEl.appendChild(el('p', 'then', p.then));
    if (p.card) bodyEl.appendChild(el('p', 'card-line', 'Charged to ' + p.card));
    var go = btn(p.confirm, 'btn-primary');
    go.addEventListener('click', function () {
      go.disabled = true;
      go.textContent = 'Working…';
      api('POST', 'plan-change', { level: p.level, expected_due: p.due }).then(function (r) {
        window.location.href = r.redirect;
      }).catch(function (err) {
        go.disabled = false;
        go.textContent = p.confirm;
        errorBox(err.message);
        if (/price changed/i.test(err.message)) {
          go.textContent = 'Review the new price';
          go.onclick = function () { loadPreview(p.level, trigger); };
        }
      });
    });
    footEl.appendChild(btn('Not now', 'btn-ghost', close));
    footEl.appendChild(go);
    go.focus();
  }
  function loadPreview(level, trigger) {
    open('Checking your price…', '', trigger);
    bodyEl.appendChild(el('p', 'fine-plain', 'One moment.'));
    api('GET', 'plan-change/preview?level=' + encodeURIComponent(level)).then(function (p) {
      renderPreview(p, trigger);
    }).catch(function (err) {
      titleEl.textContent = 'You cannot change plan right now';
      bodyEl.textContent = '';
      bodyEl.appendChild(el('p', null, err.message));
      footEl.textContent = '';
      var link = el('a', 'btn btn-primary', 'Go to billing');
      link.href = cfg.billing;
      footEl.appendChild(btn('Close', 'btn-ghost', close));
      footEl.appendChild(link);
    });
  }

  /* ---- update card (sandbox) ---- */
  function field(id, label, attrs, hint) {
    var wrap = el('div', 'field');
    var l = el('label', null, label);
    l.setAttribute('for', id);
    var box = el('div', 'input');
    var input = el('input');
    input.id = id;
    Object.keys(attrs).forEach(function (k) { input.setAttribute(k, attrs[k]); });
    box.appendChild(input);
    wrap.appendChild(l);
    wrap.appendChild(box);
    if (hint) wrap.appendChild(el('span', 'hint', hint));
    return { wrap: wrap, input: input };
  }
  function cardDialog(trigger) {
    open('Update your card', 'Demo site: use the test card 4242 4242 4242 4242, any future date, any 3 digits.', trigger);
    var form = el('form', 'card-form');
    form.noValidate = true;
    var num = field('bd-cc-num', 'Card number', { type: 'text', inputmode: 'numeric', autocomplete: 'cc-number', placeholder: '4242 4242 4242 4242', maxlength: '23' });
    var exp = field('bd-cc-exp', 'Expiry (MM/YY)', { type: 'text', inputmode: 'numeric', autocomplete: 'cc-exp', placeholder: 'MM/YY', maxlength: '7' });
    var cvc = field('bd-cc-cvc', 'Security code', { type: 'text', inputmode: 'numeric', autocomplete: 'cc-csc', placeholder: '123', maxlength: '4' });
    num.input.addEventListener('input', function () { num.input.value = num.input.value.replace(/\D/g, '').slice(0, 19).replace(/(.{4})/g, '$1 ').trim(); });
    exp.input.addEventListener('input', function () {
      var d = exp.input.value.replace(/\D/g, '').slice(0, 4);
      exp.input.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d;
    });
    var row = el('div', 'two');
    row.appendChild(exp.wrap);
    row.appendChild(cvc.wrap);
    form.appendChild(num.wrap);
    form.appendChild(row);
    bodyEl.appendChild(form);
    var save = btn('Save card', 'btn-primary');
    function submit() {
      save.disabled = true;
      save.textContent = 'Checking…';
      api('POST', 'billing/card', { number: num.input.value, exp: exp.input.value, cvc: cvc.input.value }).then(function () {
        var url = cfg.billing + (cfg.billing.indexOf('?') > -1 ? '&' : '?') + 'card=1';
        window.location.href = url;
      }).catch(function (err) {
        save.disabled = false;
        save.textContent = 'Save card';
        errorBox(err.message);
        num.input.focus();
      });
    }
    form.addEventListener('submit', function (e) { e.preventDefault(); submit(); });
    save.addEventListener('click', submit);
    footEl.appendChild(btn('Cancel', 'btn-ghost', close));
    footEl.appendChild(save);
    num.input.focus();
  }

  /* ---- pause, cancel (survey and offer), resume ---- */
  function choiceGroup(items, labelledBy, onChange) {
    var group = el('div', 'choice-group');
    group.setAttribute('role', 'radiogroup');
    group.setAttribute('aria-labelledby', labelledBy);
    var nodes = [];
    var value = null;
    function select(i, focus) {
      value = items[i].value;
      nodes.forEach(function (n, j) {
        n.setAttribute('aria-checked', j === i ? 'true' : 'false');
        n.tabIndex = j === i ? 0 : -1;
      });
      if (focus) nodes[i].focus();
      if (onChange) onChange(value);
    }
    items.forEach(function (it, i) {
      var n = el('div', 'choice');
      n.setAttribute('role', 'radio');
      n.setAttribute('aria-checked', 'false');
      n.tabIndex = i === 0 ? 0 : -1;
      n.appendChild(el('span', 'dot'));
      var t = el('span', 'txt');
      t.appendChild(el('b', null, it.label));
      if (it.hint) t.appendChild(el('small', null, it.hint));
      n.appendChild(t);
      n.addEventListener('click', function () { select(i, true); });
      n.addEventListener('keydown', function (e) {
        var step = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[e.key];
        if (step) { e.preventDefault(); select((i + step + items.length) % items.length, true); }
        else if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); select(i, true); }
      });
      nodes.push(n);
      group.appendChild(n);
    });
    return { el: group, value: function () { return value; }, select: function (i) { select(i, false); } };
  }
  function done(r) { window.location.href = r.redirect; }
  function failIn(btn, label) {
    return function (err) {
      btn.disabled = false;
      btn.textContent = label;
      errorBox(err.message);
    };
  }

  function pauseDialog(trigger) {
    open('Pause your membership', 'Billing stops and you move to Free. Your progress stays, and the weekly schedule waits for you.', trigger);
    bodyEl.appendChild(el('p', 'fine-plain', 'One moment.'));
    api('GET', 'subscription/leave').then(function (d) {
      bodyEl.textContent = '';
      var lab = el('p', 'group-label', 'How long?');
      lab.id = 'bd-pause-l';
      bodyEl.appendChild(lab);
      var g = choiceGroup(d.months.map(function (m) { return { value: m.months, label: m.label, hint: 'Resumes ' + m.until }; }), 'bd-pause-l');
      g.select(0);
      bodyEl.appendChild(g.el);
      bodyEl.appendChild(el('p', 'then', 'On the resume date your plan starts again and your card is charged. You can resume sooner from Billing.'));
      var go = btn('Pause membership', 'btn-primary');
      go.addEventListener('click', function () {
        go.disabled = true;
        go.textContent = 'Working…';
        api('POST', 'subscription/pause', { months: g.value() }).then(done).catch(failIn(go, 'Pause membership'));
      });
      footEl.appendChild(btn('Not now', 'btn-ghost', close));
      footEl.appendChild(go);
    }).catch(function (err) { bodyEl.textContent = ''; errorBox(err.message); footEl.appendChild(btn('Close', 'btn-ghost', close)); });
  }

  function cancelDialog(trigger) {
    open("Before you go, what's the main reason?", '', trigger);
    bodyEl.appendChild(el('p', 'fine-plain', 'One moment.'));
    api('GET', 'subscription/leave').then(function (d) {
      var shown = '';
      bodyEl.textContent = '';
      var reasons = Object.keys(d.reasons).map(function (k) { return { value: k, label: d.reasons[k] }; });
      var offer = el('div', 'offer');
      offer.setAttribute('aria-live', 'polite');
      offer.hidden = true;
      var next = btn('Continue to cancel', 'btn-secondary');
      next.disabled = true;
      var comment = el('textarea');
      comment.id = 'bd-cx-comment';
      comment.rows = 3;
      comment.maxLength = 1000;
      var g = choiceGroup(reasons, 'bd-dlg-t', function (v) {
        next.disabled = false;
        offer.textContent = '';
        shown = '';
        offer.hidden = true;
        if (v === 'too_expensive' && d.discount.eligible) {
          shown = 'discount';
          offer.appendChild(el('p', null, 'Stay for ' + d.discount.price + ' a month for the next ' + d.discount.renewals + ' months (' + d.discount.percent + '% off). Your progress stays put.'));
          var take = btn('Take ' + d.discount.percent + '% off', 'btn-primary', function () {
            take.disabled = true;
            take.textContent = 'Working…';
            api('POST', 'subscription/discount', { reason: v, comment: comment.value }).then(done).catch(failIn(take, 'Take ' + d.discount.percent + '% off'));
          });
          offer.appendChild(take);
          offer.hidden = false;
        } else if (v === 'no_time' && d.can_pause) {
          shown = 'pause';
          offer.appendChild(el('p', null, 'Need a break instead? Pause for 1, 2 or 3 months. Billing stops, your progress stays and the weekly schedule waits for you.'));
          var row = el('div', 'offer-row');
          d.months.forEach(function (m) {
            var b = btn('Pause ' + m.label, 'btn-secondary', function () {
              b.disabled = true;
              api('POST', 'subscription/pause', { months: m.months, reason: v, comment: comment.value }).then(done).catch(function (err) { b.disabled = false; errorBox(err.message); });
            });
            row.appendChild(b);
          });
          offer.appendChild(row);
          offer.hidden = false;
        }
      });
      bodyEl.appendChild(g.el);
      var field = el('div', 'field');
      var l = el('label', null, 'Anything we should know? (optional)');
      l.setAttribute('for', 'bd-cx-comment');
      var box = el('div', 'input area');
      box.appendChild(comment);
      field.appendChild(l);
      field.appendChild(box);
      bodyEl.appendChild(field);
      bodyEl.appendChild(offer);
      next.addEventListener('click', function () { confirmCancel(d, g.value(), comment.value, shown, trigger); });
      footEl.appendChild(btn('Keep my membership', 'btn-ghost', close));
      footEl.appendChild(next);
      g.el.firstChild.focus();
    }).catch(function (err) { bodyEl.textContent = ''; errorBox(err.message); footEl.appendChild(btn('Close', 'btn-ghost', close)); });
  }
  function confirmCancel(d, reason, comment, shown, trigger) {
    titleEl.textContent = 'Cancel your membership?';
    subEl.hidden = true;
    bodyEl.textContent = '';
    footEl.textContent = '';
    bodyEl.appendChild(el('p', null, d.status === 'trialing'
      ? 'Your trial ends on ' + d.ends + ' and you will not be charged. After that you move to Free.'
      : 'You keep ' + d.tier + ' until ' + d.ends + '. After that you move to Free and are not charged again.'));
    bodyEl.appendChild(el('p', 'then', 'Your progress is saved. You can rejoin any time and pick up where you stopped.'));
    var go = btn('Cancel membership', 'btn-danger');
    go.addEventListener('click', function () {
      go.disabled = true;
      go.textContent = 'Working…';
      api('POST', 'subscription/cancel', { reason: reason, comment: comment, offer_shown: shown }).then(done).catch(failIn(go, 'Cancel membership'));
    });
    footEl.appendChild(btn('Back', 'btn-ghost', function () { cancelDialog(trigger); }));
    footEl.appendChild(go);
    go.focus();
  }

  document.addEventListener('click', function (e) {
    var change = e.target.closest('[data-bidik-change]');
    if (change) {
      e.preventDefault();
      if (change.getAttribute('aria-disabled') === 'true') return;
      loadPreview(change.getAttribute('data-bidik-change'), change);
      return;
    }
    var card = e.target.closest('[data-bidik-card]');
    if (card) { e.preventDefault(); cardDialog(card); return; }
    var pause = e.target.closest('[data-bidik-pause]');
    if (pause) { e.preventDefault(); pauseDialog(pause); return; }
    var cancel = e.target.closest('[data-bidik-cancel]');
    if (cancel) { e.preventDefault(); cancelDialog(cancel); return; }
    var resume = e.target.closest('[data-bidik-resume]');
    if (resume) {
      e.preventDefault();
      resume.disabled = true;
      api('POST', 'subscription/resume').then(done).catch(function (err) {
        resume.disabled = false;
        open('Could not resume yet', '', resume);
        bodyEl.appendChild(el('p', null, err.message));
        var add = btn('Update card', 'btn-primary', function () { cardDialog(resume); });
        footEl.appendChild(btn('Close', 'btn-ghost', close));
        footEl.appendChild(add);
      });
      return;
    }
    var portal = e.target.closest('[data-bidik-portal]');
    if (portal) {
      e.preventDefault();
      portal.disabled = true;
      api('POST', 'stripe/portal').then(function (r) { window.location.href = r.url; }).catch(function (err) {
        portal.disabled = false;
        open('Stripe is not available right now', '', portal);
        bodyEl.appendChild(el('p', null, err.message));
        footEl.appendChild(btn('Close', 'btn-ghost', close));
      });
      return;
    }
    var undo = e.target.closest('[data-bidik-undo]');
    if (undo) {
      e.preventDefault();
      undo.disabled = true;
      api('POST', 'plan-change/undo').then(function () { window.location.href = cfg.billing; }).catch(function () { undo.disabled = false; }); // a clean address, so the old "scheduled" notice does not come back
    }
  });
})();
