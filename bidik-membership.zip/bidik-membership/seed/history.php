<?php
/**
 * Six months of made-up membership history, so the admin numbers have something to say: about 180 members who joined over the
 * last 180 days, some still paying, some on a trial, a few past due or paused, and about a quarter who left (most by choice,
 * some because a payment failed). Written straight into the tables for speed; the dates are real and consistent, and the
 * daily MRR snapshots are replayed from them with the same calculator the Overview uses.
 *
 * Deterministic (fixed seed), so a rebuilt demo is the same demo. Idempotent: it does nothing if the history is already there.
 */
defined( 'ABSPATH' ) || exit;

use Bidik\Admin\Data;
use Bidik\Admin\MrrHistory;
use Bidik\Billing\Invoices;
use Bidik\Pricing;
use Bidik\Support\Clock;

const BIDIK_HISTORY_VERSION = '2';

function bidik_history_purge(): int {
	global $wpdb;
	$p   = $wpdb->prefix . 'bidik_';
	$ids = array_map( 'intval', (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->users} WHERE user_login LIKE 'hist\\_%'" ) );
	if ( $ids ) {
		$in = implode( ',', $ids );
		foreach ( [ 'subscriptions', 'invoices', 'progress', 'cancel_feedback', 'email_log', 'drip_notices' ] as $t ) {
			$wpdb->query( "DELETE FROM {$p}$t WHERE user_id IN ($in)" );
		}
		$wpdb->query( "DELETE FROM {$wpdb->pmpro_memberships_users} WHERE user_id IN ($in)" );
		$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE user_id IN ($in)" );
		$wpdb->query( "DELETE FROM {$wpdb->users} WHERE ID IN ($in)" );
	}
	$wpdb->query( "DELETE FROM {$p}mrr_snapshots" );
	delete_option( 'bidik_history_version' );
	return count( $ids );
}

function bidik_history_seed( bool $rebuild = false ): string {
	global $wpdb;
	if ( $rebuild ) {
		bidik_history_purge();
	}
	$have = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_login LIKE 'hist\\_%'" );
	if ( BIDIK_HISTORY_VERSION === get_option( 'bidik_history_version' ) && $have >= 150 ) {
		return "history already there ($have members)";
	}
	if ( $have ) {
		bidik_history_purge();
	}

	mt_srand( 2026 );
	$p     = $wpdb->prefix . 'bidik_';
	$now   = Clock::now();
	$day   = DAY_IN_SECONDS;
	$lv    = Pricing::levels();
	$first = [ 'Sari', 'Joko', 'Maya', 'Dimas', 'Putri', 'Eko', 'Wulan', 'Fajar', 'Intan', 'Rizky', 'Hendra', 'Ayu', 'Galih', 'Nadia', 'Teguh', 'Lina', 'Agus', 'Citra', 'Yoga', 'Mega' ];
	$last  = [ 'Nugroho', 'Wijaya', 'Kusuma', 'Hartono', 'Pratama', 'Saputra', 'Utami', 'Setiawan', 'Rahmawati', 'Susanto', 'Anggraini', 'Firmansyah', 'Handayani', 'Wibowo', 'Marlina' ];
	$cap   = serialize( [ 'subscriber' => true ] );
	$pre   = $wpdb->get_blog_prefix();
	$pick  = static fn( array $a ) => $a[ mt_rand( 0, count( $a ) - 1 ) ];
	$chance = static fn( float $p ) => mt_rand( 0, 9999 ) / 10000 < $p;
	$mysql = static fn( int $ts ) => gmdate( 'Y-m-d H:i:s', $ts );
	$add   = static fn( int $ts, string $by ) => ( new DateTimeImmutable( '@' . $ts ) )->modify( $by )->getTimestamp();

	$subs = [];
	$N    = 182;
	for ( $i = 1; $i <= $N; $i++ ) {
		// joins are denser lately: the square root bends the draw toward today
		$age     = (int) round( 180 * ( 1 - sqrt( mt_rand( 0, 9999 ) / 10000 ) ) ) + 1;
		$created = $now - $age * $day - mt_rand( 0, 80000 );
		$pro     = $chance( 0.3 );
		$year    = $chance( 0.2 );
		$tier    = $pro ? 'pro' : 'member';
		$int     = $year ? 'year' : 'month';
		$trial   = ! $pro && ! $year;
		$subs[]  = compact( 'i', 'age', 'created', 'tier', 'int', 'trial' ) + [ 'status' => 'active', 'canceled' => null, 'churn' => null, 'grace' => null, 'pause' => null ];
	}
	// who left, who is in trouble: assigned by age so the story reads right (new people are on trials, old ones have churned)
	foreach ( $subs as $k => &$s ) {
		if ( $s['trial'] && $s['age'] <= 7 ) {
			$s['status'] = 'trialing';
		} elseif ( $s['trial'] && $s['age'] > 7 && $s['age'] <= 38 && $chance( 0.3 ) ) {
			$s['status'] = 'canceled'; // left during the trial: these are the trials that did not convert
			$s['canceled'] = $s['created'] + mt_rand( 3, 6 ) * $day;
			$s['churn'] = 'voluntary';
		} elseif ( $s['age'] > 25 && $chance( 0.2 ) ) {
			$s['status']   = 'canceled';
			$s['canceled'] = $s['created'] + mt_rand( 24, max( 25, $s['age'] - 1 ) ) * $day;
			$s['churn']    = $chance( 0.28 ) ? 'involuntary' : 'voluntary';
		}
	}
	unset( $s );
	// a handful past due and paused, chosen from people who are otherwise active and have been here a while
	$pool = array_keys( array_filter( $subs, static fn( $s ) => 'active' === $s['status'] && $s['age'] > 45 && 'month' === $s['int'] ) );
	foreach ( array_slice( $pool, 0, 5 ) as $n => $k ) {
		$subs[ $k ]['status'] = 'past_due';
		$subs[ $k ]['grace']  = $now + ( 1 + $n ) * $day; // 5 people with 1 to 5 days left
	}
	foreach ( array_slice( $pool, 5, 3 ) as $k ) {
		$subs[ $k ]['status'] = 'paused';
		$subs[ $k ]['pause']  = $now + mt_rand( 10, 60 ) * $day;
	}

	$reasons = [ 'too_expensive' => 0.34, 'no_time' => 0.26, 'finished' => 0.18, 'not_expected' => 0.1, 'technical' => 0.04, 'other' => 0.08 ];
	$lesson_ids = array_map( static fn( $l ) => $l['post']->ID, \Bidik\Courses\Catalog::structure( (int) ( \Bidik\Courses\Catalog::courses()[0]->ID ?? 0 ) )['lessons'] );
	$counts = [ 'users' => 0, 'invoices' => 0 ];

	foreach ( $subs as $s ) {
		$name  = $pick( $first ) . ' ' . $pick( $last );
		$login = 'hist_' . $s['i'];
		$email = strtolower( str_replace( ' ', '.', $name ) ) . $s['i'] . '@example.com';
		$wpdb->insert( $wpdb->users, [ 'user_login' => $login, 'user_pass' => '!', 'user_nicename' => $login, 'user_email' => $email, 'user_registered' => $mysql( $s['created'] - mt_rand( 0, 3 ) * $day ), 'display_name' => $name, 'user_status' => 0, 'user_url' => '' ] );
		$uid = (int) $wpdb->insert_id;
		[ $fn, $ln ] = explode( ' ', $name, 2 );
		// a working card for everyone still on a plan, so that moving the demo clock renews them instead of failing them all (the past-due ones get the failing card below)
		$card = in_array( $s['status'], [ 'trialing', 'active', 'paused' ], true ) ? serialize( [ 'brand' => 'Visa', 'last4' => '4242', 'exp' => '12/' . ( (int) gmdate( 'Y' ) + 2 ), 'renews' => true ] ) : null;
		foreach ( [ 'first_name' => $fn, 'last_name' => $ln, 'nickname' => $fn, $pre . 'capabilities' => $cap, $pre . 'user_level' => 0, 'bidik_history' => 1, 'bidik_member_since' => $s['created'], 'bidik_card' => $card ] as $mk => $mv ) {
			if ( null === $mv ) {
				continue;
			}
			$wpdb->insert( $wpdb->usermeta, [ 'user_id' => $uid, 'meta_key' => $mk, 'meta_value' => $mv ] );
		}

		$level   = (int) $lv[ $s['tier'] ][ $s['int'] ]['id'];
		$price   = (int) round( (float) $lv[ $s['tier'] ][ $s['int'] ]['amount'] * 100 );
		$span    = 'year' === $s['int'] ? '+1 year' : '+1 month';
		$start   = $s['trial'] ? $s['created'] + 7 * $day : $s['created'];          // first period (after the trial, if any)
		$paid_from = $start;
		// the period they are in now, and the invoice dates before it
		$periods = [];
		$ps      = $start;
		$until   = $s['canceled'] ?: $now;
		while ( $ps <= $until ) {
			$periods[] = $ps;
			$ps        = $add( $ps, $span );
		}
		if ( 'canceled' === $s['status'] && $s['trial'] && $s['canceled'] < $start ) {
			$periods = []; // left during the trial: never charged
		}
		$cur_start = $periods ? end( $periods ) : $start;
		$cur_end   = $add( $cur_start, $span );
		if ( 'past_due' === $s['status'] ) {
			$cur_start = $s['grace'] - 7 * $day;                    // the renewal that failed
			$cur_end   = $add( $cur_start, $span );
			$periods   = array_values( array_filter( $periods, static fn( $x ) => $x < $cur_start ) );
		}
		$wpdb->insert( $p . 'subscriptions', [
			'user_id' => $uid, 'level_id' => $level, 'gateway' => 'sandbox', 'gateway_customer_id' => 'cus_hist_' . $s['i'], 'gateway_subscription_id' => 'sub_hist_' . $s['i'], 'status' => $s['status'],
			'current_period_start' => $mysql( $s['trial'] && 'trialing' === $s['status'] ? $s['created'] : $cur_start ), 'current_period_end' => $mysql( 'trialing' === $s['status'] ? $s['created'] + 7 * $day : $cur_end ),
			'trial_end' => $s['trial'] ? $mysql( $s['created'] + 7 * $day ) : null, 'cancel_at_period_end' => 0, 'pause_until' => $s['pause'] ? $mysql( $s['pause'] ) : null,
			'grace_until' => $s['grace'] ? $mysql( $s['grace'] ) : null, 'churn_type' => $s['churn'], 'canceled_at' => $s['canceled'] ? $mysql( $s['canceled'] ) : null, 'created_at' => $mysql( $s['created'] ),
		] );
		$sid = (int) $wpdb->insert_id;

		foreach ( $periods as $n => $when ) {
			$desc = $s['trial'] && 0 === $n ? ( 'Member, monthly (first charge after trial)' ) : ucfirst( $s['tier'] ) . ', ' . ( 'year' === $s['int'] ? 'yearly' : 'monthly' );
			$wpdb->insert( $p . 'invoices', [ 'number' => Invoices::next_number(), 'user_id' => $uid, 'subscription_id' => $sid, 'gateway_invoice_id' => "in_hist_{$s['i']}_$n", 'amount_cents' => $price, 'currency' => 'USD', 'status' => 'paid',
				'line_items' => wp_json_encode( [ [ 'description' => $desc, 'amount' => $price ] ] ), 'paid_at' => $mysql( $when ), 'created_at' => $mysql( $when ) ] );
			++$counts['invoices'];
		}
		if ( 'pro' === $s['tier'] && 'month' === $s['int'] && $periods && 0 === $s['i'] % 3 ) { // some Pros upgraded from Member mid-period and paid the difference
			$cents = mt_rand( 300, 1500 );
			$wpdb->insert( $p . 'invoices', [ 'number' => Invoices::next_number(), 'user_id' => $uid, 'subscription_id' => $sid, 'gateway_invoice_id' => "in_hist_{$s['i']}_up", 'amount_cents' => $cents, 'currency' => 'USD', 'status' => 'paid',
				'line_items' => wp_json_encode( [ [ 'description' => 'Upgrade to Pro, prorated (' . mt_rand( 8, 24 ) . ' days)', 'amount' => $cents ] ] ), 'paid_at' => $mysql( $periods[0] + 9 * $day ), 'created_at' => $mysql( $periods[0] + 9 * $day ) ] );
			++$counts['invoices'];
		}
		if ( 'past_due' === $s['status'] ) {
			$wpdb->insert( $p . 'invoices', [ 'number' => Invoices::next_number(), 'user_id' => $uid, 'subscription_id' => $sid, 'gateway_invoice_id' => "in_hist_{$s['i']}_open", 'amount_cents' => $price, 'currency' => 'USD', 'status' => 'open',
				'line_items' => wp_json_encode( [ [ 'description' => ucfirst( $s['tier'] ) . ', monthly', 'amount' => $price ] ] ), 'paid_at' => null, 'created_at' => $mysql( $s['grace'] - 7 * $day ) ] );
			update_user_meta( $uid, 'bidik_card', [ 'brand' => 'Visa', 'last4' => '0341', 'exp' => '12/' . ( (int) gmdate( 'Y' ) + 1 ), 'renews' => false ] );
		}
		if ( in_array( $s['status'], [ 'trialing', 'active', 'past_due' ], true ) ) { // they hold the plan on the site as well
			$wpdb->insert( $wpdb->pmpro_memberships_users, [ 'user_id' => $uid, 'membership_id' => $level, 'code_id' => 0, 'initial_payment' => $price / 100, 'billing_amount' => $price / 100, 'cycle_number' => 1, 'cycle_period' => 'year' === $s['int'] ? 'Year' : 'Month',
				'billing_limit' => 0, 'trial_amount' => 0, 'trial_limit' => 0, 'startdate' => $mysql( $s['created'] ), 'enddate' => null, 'status' => 'active', 'modified' => $mysql( $s['created'] ) ] );
		}
		if ( 'voluntary' === $s['churn'] && $chance( 0.65 ) ) {
			$r = 0.0;
			$x = mt_rand( 0, 9999 ) / 10000;
			foreach ( $reasons as $key => $w ) {
				$r += $w;
				if ( $x <= $r ) {
					$reason = $key;
					break;
				}
			}
			$wpdb->insert( $p . 'cancel_feedback', [ 'user_id' => $uid, 'subscription_id' => $sid, 'reason' => $reason ?? 'other', 'comment' => $chance( 0.3 ) ? $pick( [ 'Money is tight this month.', 'Will come back after the trip.', 'Got what I needed.', 'The pace was too fast for me.' ] ) : null,
				'offer_shown' => 'too_expensive' === ( $reason ?? '' ) ? 'discount' : ( 'no_time' === ( $reason ?? '' ) ? 'pause' : null ), 'offer_accepted' => 0, 'created_at' => $mysql( $s['canceled'] - mt_rand( 0, 2 ) * $day ) ] );
		}
		if ( 'canceled' !== $s['status'] && $lesson_ids ) {
			foreach ( array_slice( $lesson_ids, 0, mt_rand( 0, min( count( $lesson_ids ), 14 ) ) ) as $n => $lid ) {
				$wpdb->insert( $p . 'progress', [ 'user_id' => $uid, 'lesson_id' => $lid, 'completed_at' => $mysql( min( $now, $s['created'] + ( 1 + $n ) * 3 * $day ) ) ] );
			}
		}
		++$counts['users'];
	}

	// the chart: replay every subscription (these and the personas) day by day, then keep today's live number
	$from = gmdate( 'Y-m-d', $now - 180 * $day );
	$to   = gmdate( 'Y-m-d', $now );
	$rows = MrrHistory::series( Data::subscriptions(), $from, $to );
	foreach ( $rows as $row ) {
		Data::store( $row );
	}
	update_option( 'bidik_history_version', BIDIK_HISTORY_VERSION, false );
	return sprintf( '%d members, %d invoices, %d daily snapshots (MRR today %s)', $counts['users'], $counts['invoices'], count( $rows ), \Bidik\Admin\Metrics::money( end( $rows )['mrr'] ) );
}
