<?php
/** Builds the downloadable demo files into uploads/bidik-protected (one-page PDFs, a sample-image zip, a 24-preset pack). */
defined( 'ABSPATH' ) || exit;

use Bidik\Content\Downloads;

function bidik_pdf( string $title, array $lines ): string {
	$esc = static fn( string $s ): string => str_replace( [ '\\', '(', ')' ], [ '\\\\', '\\(', '\\)' ], $s );
	$s   = "BT /F2 20 Tf 56 780 Td (" . $esc( $title ) . ") Tj ET\n";
	$y   = 744;
	foreach ( $lines as $line ) {
		$s .= "BT /F1 11 Tf 56 $y Td (" . $esc( $line ) . ") Tj ET\n";
		$y -= 20;
	}
	$s .= "BT /F1 9 Tf 56 48 Td (Bidik is a fictional photography school. This file is part of a demo site.) Tj ET\n";
	$objs = [
		'<< /Type /Catalog /Pages 2 0 R >>',
		'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
		'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>',
		'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
		'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>',
		'<< /Length ' . strlen( $s ) . " >>\nstream\n$s" . 'endstream',
	];
	$pdf = "%PDF-1.4\n";
	$off = [];
	foreach ( $objs as $i => $o ) {
		$off[] = strlen( $pdf );
		$pdf  .= ( $i + 1 ) . " 0 obj\n$o\nendobj\n";
	}
	$x    = strlen( $pdf );
	$pdf .= "xref\n0 " . ( count( $objs ) + 1 ) . "\n0000000000 65535 f \n";
	foreach ( $off as $o ) {
		$pdf .= sprintf( "%010d 00000 n \n", $o );
	}
	return $pdf . 'trailer << /Size ' . ( count( $objs ) + 1 ) . " /Root 1 0 R >>\nstartxref\n$x\n%%EOF\n";
}

function bidik_preset( string $name, array $s ): string {
	$attrs = '';
	foreach ( $s as $k => $v ) {
		$attrs .= " crs:$k=\"" . ( is_float( $v ) ? sprintf( '%+.2f', $v ) : sprintf( '%+d', $v ) ) . '"';
	}
	$uuid = strtoupper( substr( md5( $name ), 0, 8 ) . '-' . substr( md5( $name ), 8, 4 ) . '-' . substr( md5( $name ), 12, 4 ) . '-' . substr( md5( $name ), 16, 4 ) . '-' . substr( md5( $name ), 20, 12 ) );
	return '<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?>' . "\n"
		. '<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Adobe XMP Core 7.0-c000"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">'
		. '<rdf:Description rdf:about="" xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/" crs:PresetType="Normal" crs:Cluster="" crs:UUID="' . $uuid . '" crs:SupportsAmount="False" crs:SupportsColor="True" crs:SupportsMonochrome="True" crs:Version="14.0" crs:ProcessVersion="11.0"' . $attrs . ' crs:HasSettings="True">'
		. '<crs:Name><rdf:Alt><rdf:li xml:lang="x-default">' . $name . '</rdf:li></rdf:Alt></crs:Name><crs:Group><rdf:Alt><rdf:li xml:lang="x-default">Bidik demo</rdf:li></rdf:Alt></crs:Group>'
		. '</rdf:Description></rdf:RDF></x:xmpmeta>' . "\n" . '<?xpacket end="w"?>';
}

function bidik_seed_files(): array {
	$dir = Downloads::dir();
	wp_mkdir_p( $dir );
	file_put_contents( $dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
	file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" );

	$made = [];
	$put  = static function ( string $key, string $bytes ) use ( &$made ): void {
		file_put_contents( Downloads::path( $key ), $bytes );
		$made[] = $key;
	};
	$put( 'dark-sky-planner', bidik_pdf( 'Dark-sky night planner', [
		'Three days before', '  [ ] Moon phase: aim for new moon, or moonset before you shoot', '  [ ] Light pollution map: pick a Bortle 4 sky or darker', '  [ ] Where the Milky Way core will be, and at what time',
		'On the day', '  [ ] Cloud forecast at 18:00 and again two hours before', '  [ ] Charge two batteries, clear the card, pack a red torch', '  [ ] Tell someone where you are going',
		'At the location', '  [ ] Focus on a bright star with live view at 10x', '  [ ] Take a test frame and check the stars at 100 percent', '  [ ] Shoot the foreground at blue hour if you can' ] ) );
	$put( 'histogram-cheatsheet', bidik_pdf( 'Reading the histogram outdoors', [
		'Left edge is black, right edge is white.', 'A spike touching the right edge: highlights have clipped. Lower the exposure.', 'A spike touching the left edge: shadows are crushed. Raise it, or add light.',
		'Backlit scenes: let the left side stay empty and lift the shadows later.', 'Sunset: the red channel clips first. Check it, not only the brightness graph.', 'No histogram is correct on its own. Judge it against the scene in front of you.' ] ) );
	$put( 'window-light-brief', bidik_pdf( 'Window light portrait: the brief', [
		'Make two portraits of a friend beside one window, with and without a reflector.', '1. Switch off the room lights.', '2. Seat your subject a forearm from the window, turned slightly toward it.',
		'3. Shoot eight frames. Keep two.', '4. Add a white reflector on the shadow side and shoot eight more. Keep two.', '5. Show the four to someone and ask which they would pick, then why.' ] ) );

	$img = dirname( __DIR__ ) . '/assets/img/';
	$zip = new ZipArchive();
	$zp  = Downloads::path( 'histogram-practice' );
	@unlink( $zp );
	$zip->open( $zp, ZipArchive::CREATE );
	foreach ( [ 'golden-hour-savanna.jpg', 'mekong-golden-hour.jpg', 'window-light-portrait.jpg' ] as $n => $f ) {
		$zip->addFile( $img . $f, 'practice-' . ( $n + 1 ) . '.jpg' );
	}
	$zip->addFromString( 'READ-ME.txt', "Three sample images for the histogram lesson (JPEG exports, not RAW).\nPhotos: Wikimedia Commons, CC BY-SA 4.0. Credits are in the Bidik site footer.\n" );
	$zip->close();
	$made[] = 'histogram-practice';

	$looks = [ 'Golden Warm' => [ 'Temperature' => 6, 'Exposure2012' => 0.15, 'Contrast2012' => 10, 'Highlights2012' => -35, 'Shadows2012' => 25, 'Vibrance' => 12 ],
		'Blue Hour' => [ 'Temperature' => -8, 'Exposure2012' => 0.10, 'Contrast2012' => 8, 'Highlights2012' => -20, 'Shadows2012' => 30, 'Saturation' => 6 ],
		'Soft Portrait' => [ 'Exposure2012' => 0.20, 'Contrast2012' => -12, 'Highlights2012' => -25, 'Shadows2012' => 15, 'Clarity2012' => -10 ],
		'Deep Shadow' => [ 'Exposure2012' => -0.15, 'Contrast2012' => 25, 'Highlights2012' => -15, 'Shadows2012' => -20, 'Blacks2012' => -15 ],
		'Night Clean' => [ 'Exposure2012' => 0.25, 'Contrast2012' => 12, 'Shadows2012' => 40, 'Blacks2012' => -10, 'Dehaze' => 8 ],
		'Film Fade' => [ 'Contrast2012' => -8, 'Blacks2012' => 18, 'Highlights2012' => -10, 'Saturation' => -10, 'Vibrance' => 5 ],
		'Crisp Landscape' => [ 'Contrast2012' => 18, 'Clarity2012' => 15, 'Dehaze' => 12, 'Vibrance' => 18, 'Highlights2012' => -30 ],
		'Mono Grain' => [ 'Contrast2012' => 20, 'Clarity2012' => 10, 'Highlights2012' => -20, 'Saturation' => -100 ] ];
	$pp  = Downloads::path( 'bidik-preset-pack' );
	@unlink( $pp );
	$zip = new ZipArchive();
	$zip->open( $pp, ZipArchive::CREATE );
	$n = 0;
	foreach ( $looks as $name => $s ) {
		foreach ( [ 1 => 0.5, 2 => 1.0, 3 => 1.5 ] as $level => $k ) {
			$scaled = [];
			foreach ( $s as $key => $v ) {
				$scaled[ $key ] = is_float( $v ) ? round( $v * $k, 2 ) : (int) round( $v * ( 'Saturation' === $key && -100 === $v ? 1 : $k ) );
			}
			$zip->addFromString( sprintf( '%02d %s %d.xmp', ++$n, $name, $level ), bidik_preset( "$name $level", $scaled ) );
		}
	}
	$zip->addFromString( 'READ-ME.txt', "24 demo presets (8 looks x 3 strengths) in the XMP preset format Lightroom uses, made for the Bidik sample site.\n" );
	$zip->close();
	$made[] = 'bidik-preset-pack';
	return $made;
}
