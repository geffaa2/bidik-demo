<?php
/**
 * The people you can "view as" in the demo. Safe to run again: it first puts them back to how they started.
 *
 *   demo-free    Dewi Lestari      Free account
 *   demo-member  Rani Prameswari   Member, joined 10 days ago (module 3 opens in 4 days), trial over, one $12 invoice
 *   demo-pro     Bayu Santoso      Pro, two paid months, every module open
 *   demo-late    Maya Anggraini    Member whose card failed on the last renewal: past due, 7 days to fix it
 *
 * Their password is `bidik-demo`. They exist only on a demo site; see Demo::login(), which refuses to work without BIDIK_DEMO.
 */
defined( 'ABSPATH' ) || exit;

use Bidik\Billing\MembershipSync;
use Bidik\Billing\WebhookProcessor;

const BIDIK_PERSONAS = [ 'demo-free', 'demo-member', 'demo-pro', 'demo-late' ];

/** Removes what the personas have done (and had done to them), so they can be seeded again from the start. */
function bidik_purge_personas(): void {
	global $wpdb;
	$p   = $wpdb->prefix . 'bidik_';
	$ids = array_map( 'intval', (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->users} WHERE user_login LIKE 'demo-%'" ) );
	foreach ( $ids as $id ) {
		foreach ( [ 'subscriptions', 'invoices', 'progress', 'cancel_feedback', 'email_log', 'esp_log', 'drip_notices' ] as $t ) {
			$wpdb->delete( $p . $t, [ 'user_id' => $id ] );
		}
		$wpdb->delete( $wpdb->pmpro_memberships_users, [ 'user_id' => $id ] );
		foreach ( [ 'bidik_card', 'bidik_retention', 'bidik_retention_used', 'bidik_pause_state', 'bidik_lapsed_at', 'bidik_email_prefs', 'bidik_last_lesson', 'bidik_esp_tags' ] as $m ) {
			delete_user_meta( $id, $m );
		}
	}
	$wpdb->query( "DELETE FROM {$p}events WHERE event_id LIKE 'evt_seed_%'" );
}

/**
 * @param array<string,int> $ids level name => id
 * @return string[] what it did
 */
function bidik_seed_personas( array $ids ): array {
	global $wpdb;
	$log = [];
	bidik_purge_personas();
	$now = time();
	$d   = DAY_IN_SECONDS;
	$card_ok  = [ 'brand' => 'Visa', 'last4' => '4242', 'exp' => '12/' . ( (int) gmdate( 'Y' ) + 2 ), 'renews' => true ];
	$card_bad = [ 'brand' => 'Visa', 'last4' => '0341', 'exp' => '12/' . ( (int) gmdate( 'Y' ) + 2 ), 'renews' => false ];

	$people = [
		'demo-free'   => [ 'Dewi Lestari', 'Free', 0, null, null ],
		'demo-member' => [ 'Rani Prameswari', 'Member (monthly)', 10, $card_ok, [
			[ 'sub', 'customer.subscription.created', [ 'status' => 'trialing', 'current_period_start' => $now - 10 * $d, 'current_period_end' => $now - 3 * $d, 'trial_end' => $now - 3 * $d ] ],
			[ 'inv1', 'invoice.paid', [ 'id' => 'in_seed_rani_1', 'amount_paid' => 1200, 'created' => $now - 3 * $d, 'period_start' => $now - 3 * $d, 'period_end' => $now + 27 * $d, 'lines' => [ [ 'description' => 'Member, monthly (first charge after trial)', 'amount' => 1200 ] ] ] ],
		] ],
		'demo-pro'    => [ 'Bayu Santoso', 'Pro (monthly)', 42, $card_ok, [
			[ 'sub', 'customer.subscription.created', [ 'status' => 'active', 'current_period_start' => $now - 42 * $d, 'current_period_end' => $now - 12 * $d ] ],
			[ 'inv1', 'invoice.paid', [ 'id' => 'in_seed_bayu_1', 'amount_paid' => 2400, 'created' => $now - 42 * $d, 'period_start' => $now - 42 * $d, 'period_end' => $now - 12 * $d, 'lines' => [ [ 'description' => 'Pro, monthly', 'amount' => 2400 ] ] ] ],
			[ 'inv2', 'invoice.paid', [ 'id' => 'in_seed_bayu_2', 'amount_paid' => 2400, 'created' => $now - 12 * $d, 'period_start' => $now - 12 * $d, 'period_end' => $now + 18 * $d, 'lines' => [ [ 'description' => 'Pro, monthly', 'amount' => 2400 ] ] ] ],
		] ],
		'demo-late'   => [ 'Maya Anggraini', 'Member (monthly)', 35, $card_bad, [
			[ 'sub', 'customer.subscription.created', [ 'status' => 'active', 'current_period_start' => $now - 35 * $d, 'current_period_end' => $now - 5 * $d ] ],
			[ 'inv1', 'invoice.paid', [ 'id' => 'in_seed_maya_1', 'amount_paid' => 1200, 'created' => $now - 35 * $d, 'period_start' => $now - 35 * $d, 'period_end' => $now - 5 * $d, 'lines' => [ [ 'description' => 'Member, monthly', 'amount' => 1200 ] ] ] ],
			[ 'fail', 'invoice.payment_failed', [ 'id' => 'in_seed_maya_2', 'amount_due' => 1200, 'created' => $now - 5 * $d, 'lines' => [ [ 'description' => 'Member, monthly', 'amount' => 1200 ] ] ] ],
		] ],
	];
	$tags = [ 'demo-member' => 'rani', 'demo-pro' => 'bayu', 'demo-late' => 'maya' ];

	foreach ( $people as $login => [ $name, $level, $days, $card, $events ] ) {
		$parts = explode( ' ', $name, 2 );
		$u     = get_user_by( 'login', $login );
		$uid   = $u ? $u->ID : (int) wp_insert_user( [ 'user_login' => $login, 'user_pass' => 'bidik-demo', 'user_email' => "$login@example.com", 'display_name' => $name, 'role' => 'subscriber' ] );
		wp_set_password( 'bidik-demo', $uid );
		wp_update_user( [ 'ID' => $uid, 'display_name' => $name, 'first_name' => $parts[0], 'last_name' => $parts[1] ?? '' ] );
		MembershipSync::set_level( $uid, $ids[ $level ] );
		update_user_meta( $uid, 'bidik_member_since', $now - $days * $d );
		if ( $card ) {
			update_user_meta( $uid, 'bidik_card', $card );
		}
		foreach ( (array) $events as [ $id, $type, $obj ] ) {
			$tag = $tags[ $login ];
			$obj += 'customer.subscription.created' === $type
				? [ 'id' => "sub_seed_$tag", 'customer' => "cus_seed_$tag", 'metadata' => [ 'user_id' => $uid, 'level_id' => $ids[ $level ] ] ]
				: [ 'subscription' => "sub_seed_$tag", 'currency' => 'usd' ];
			WebhookProcessor::handle( 'sandbox', [ 'id' => "evt_seed_{$tag}_$id", 'type' => $type, 'data' => [ 'object' => $obj ] ] );
		}
		$wpdb->delete( $wpdb->prefix . 'bidik_email_log', [ 'user_id' => $uid ] ); // seeding is not news to the member
		$log[] = "persona $login → " . ( $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$wpdb->prefix}bidik_subscriptions WHERE user_id = %d", $uid ) ) ?: $level );
	}
	return $log;
}
