<?php
/**
 * Course content for the demo: three courses, 40 lessons. Every lesson is [title, minutes, note, bullets, files, tier].
 * tier '' follows the course; 'free' opens that lesson to any Free account (lesson 1 of every course).
 * Minutes add up to what the pricing page promises: 3 h 40 m, 2 h 28 m and 2 h 05 m.
 */
return [
	[
		'slug' => 'light-explained', 'title' => 'Light, Explained', 'tier' => 'member', 'cover' => 'golden-hour-savanna.jpg', 'video' => 'light-explained.mp4',
		'summary' => 'Learn to see what light is doing before you press the shutter: its direction, its softness, its colour and how long it lasts.',
		'description' => '<p>Eighteen lessons that start with the window in your kitchen and end with a night street. Each module opens a week after the one before it, so there is time to shoot between lessons.</p>',
		'modules' => [
			[ 'Seeing light', 0, [
				[ 'Hard light, soft light', 9, 'Hard light comes from a small source far from the subject, soft light from a large one close to it. You can change either one without moving the sun: step nearer to a window, or wait for a cloud.', [ 'Hold a hand up and watch how sharp its shadow edge is.', 'Large and close means soft; small and far means hard.' ], [], 'free' ],
				[ 'Where the shadow falls', 12, 'A shadow tells you where the light is before you look for it. Learn to read its direction and length and you can guess the time of day in any photograph.', [ 'Long shadows mean low sun, which is good for texture.', 'Walk around the subject once before you choose a side.' ], [], '' ],
				[ 'Colour temperature by eye', 8, 'Warm and cool are relative: a candle looks orange next to daylight and white in a dark room. Set your white balance to a neutral grey, then decide how much warmth you want back.', [ 'Shoot a grey card once; it fixes a whole session.', 'Mixed sources never match, so choose one to be correct.' ], [], '' ],
				[ 'Exercise: one subject, four lights', 15, 'Photograph one object in four lights: window, lamp, open shade and direct sun. Put the four frames side by side and note what changed besides brightness.', [ 'Keep the camera on a tripod so only the light moves.', 'Write one sentence about each frame before looking at the next.' ], [], '' ],
			] ],
			[ 'Golden hour & blue hour', 7, [
				[ 'Planning the 40 minutes', 10, 'Golden hour is shorter than the name suggests, and its best light is often the last ten minutes. Arrive early enough to have chosen your frame before the colour arrives.', [ 'Check the sun azimuth, not just the sunset time.', 'Scout in daylight; shoot in the good light.' ], [], '' ],
				[ 'Backlight without losing the face', 13, 'With the sun behind your subject the camera wants to expose for the sky. Meter on the face, let the background brighten, and add a reflector if the shadow is too deep.', [ 'Spot meter, or lock exposure on the skin.', 'A white shirt is a free reflector.' ], [], '' ],
				[ 'Reading the histogram outdoors', 11, 'At golden hour the scene has more range than the screen on the back of your camera can show. The histogram tells you what the preview hides: whether the sky has clipped, and whether the shadows still hold detail you can lift later.', [ 'Push the highlights to the right edge, but stop before the spike touches it.', 'A gap on the left is fine with backlight; you will lift it in editing.', 'Check the red channel at sunset; it clips first.' ], [ 'histogram-cheatsheet', 'histogram-practice' ], '' ],
				[ 'Blue hour on a tripod', 14, 'After the sun drops, the sky turns deep blue and the city lights balance it for a few minutes. Shutter speeds get long, so the tripod does the work and your only job is timing.', [ 'Start before you think you need to; the light fades quickly.', 'Use a two-second timer to avoid shaking the camera.' ], [], '' ],
				[ 'Exercise: the same street, twice', 20, 'Shoot one street at golden hour and again at blue hour from exactly the same spot. The difference between the two sets is the whole lesson.', [ 'Mark your tripod position with chalk or a photo.', 'Compare the histograms, not just the pictures.' ], [], '' ],
			] ],
			[ 'Window light portraits', 14, [
				[ 'One window, three looks', 12, 'A single window gives you three portraits depending on where the subject sits: facing it, side-on and with their back to it. Each one changes the mood without any equipment.', [ 'Side-on gives shape; facing gives flat, even skin.', 'Turn off the room lights so they do not fight the window.' ], [ 'window-light-brief' ], '' ],
				[ 'Reflectors you already own', 9, 'A sheet of white card, a folded bedsheet or a pale wall will push light back into the shadow side. Move it closer for more fill and farther for less.', [ 'White fills softly; silver is harsher.', 'Hold it just out of frame, angled up at the chin.' ], [], '' ],
				[ 'Exercise: a portrait by a window', 18, 'Make one portrait of a friend by a window and one more after you add a reflector. Show both to someone and ask which they would choose, then ask why.', [ 'Shoot eight frames, keep two.', 'Say the subject\'s name before you press the shutter; it relaxes the face.' ], [], '' ],
			] ],
			[ 'Mixed light at night', 21, [
				[ 'Street lamps and white balance', 11, 'Sodium, LED and fluorescent lamps all have different colours, and your camera will average them. Pick the one nearest your subject and set the white balance for it.', [ 'Shoot RAW so white balance stays flexible.', 'Let the background colours drift; they sell the place.' ], [], '' ],
				[ 'Light painting basics', 16, 'With the shutter open for several seconds, a small torch drawn across the frame becomes part of the photograph. Keep the light moving, and keep yourself out of its path.', [ 'Dark clothes make you vanish.', 'Start with 10 seconds and adjust from there.' ], [], '' ],
			] ],
			[ 'Editing for light', 28, [
				[ 'Dodge and burn with restraint', 13, 'Lightening and darkening small areas steers the eye, but only if nobody can see you did it. Work at low opacity and zoom out often to judge the whole frame.', [ 'Ten percent, many times, beats forty percent once.', 'Toggle the layer off to check you have not overdone it.' ], [], '' ],
				[ 'Matching a series', 12, 'A set of photographs feels connected when their light and colour agree. Edit the strongest frame first, then match the others to it rather than editing each on its own.', [ 'Sync settings, then fix exposure per frame.', 'View the set as thumbnails before you finish.' ], [], '' ],
			] ],
			[ 'Final assignment', 35, [
				[ 'Shoot the brief', 10, 'Your brief is one place, three kinds of light and six finished photographs. Plan the visits first, since the hard part is being there at the right time.', [ 'Note the time and weather beside each frame.', 'Pick the place you can reach again if it goes wrong.' ], [], '' ],
				[ 'Critique and reshoot', 7, 'Post your set to the critique thread, read what comes back, and choose one frame to reshoot. Improving a single picture teaches more than adding a new one.', [ 'Ask one specific question when you post.', 'Reshoot within a week, while you remember the light.' ], [], '' ],
			] ],
		],
	],
	[
		'slug' => 'composition-without-rules', 'title' => 'Composition Without Rules', 'tier' => 'member', 'cover' => 'mekong-golden-hour.jpg', 'video' => 'composition.mp4',
		'summary' => 'Use the rules of composition as a starting point, then learn when to break them and how to tell it is working.',
		'description' => '<p>Twelve lessons on arranging a frame. We use the rule of thirds, leading lines and balance as tools, and finish by breaking them on purpose.</p>',
		'modules' => [
			[ 'Before the frame', 0, [
				[ 'Why rules help and where they stop', 9, 'Rules of composition are summaries of what usually works, not laws. Use them to get to a decent frame fast, then ask what the picture needs that the rule did not give it.', [ 'A rule is a first guess, not a verdict.', 'Notice what you do before you look it up.' ], [], 'free' ],
				[ 'Seeing shapes, not subjects', 11, 'Squint at a scene and it turns into patches of light and dark. Compose those patches and the subject will usually take care of itself.', [ 'Squint, or turn the screen to greyscale.', 'Look for the shape of the gaps between things.' ], [], '' ],
				[ 'Exercise: ten frames, one chair', 14, 'Photograph a single chair ten different ways without moving it. Change only your position, your height and your lens.', [ 'Go low, go high, go close, go far.', 'Keep the three you like least; they teach the most.' ], [], '' ],
			] ],
			[ 'Lines and weight', 7, [
				[ 'Leading lines you can\'t see', 12, 'Not every line is a road. Glances, gestures and the edges of light all pull the eye the same way a fence does.', [ 'Follow where the subject is looking.', 'A line that exits the frame sends the eye with it.' ], [], '' ],
				[ 'Balance without symmetry', 10, 'A small bright object can balance a large dark one, much as a child on a seesaw balances an adult by sitting farther out. Think in weight rather than centred shapes.', [ 'Bright, sharp and warm things look heavier.', 'Leave room in front of anything that moves.' ], [], '' ],
				[ 'Negative space', 13, 'Empty space gives a subject somewhere to sit, and it often makes the picture feel calm. Decide how much of it you want before you zoom in.', [ 'Try one frame with twice the space you would normally leave.', 'Plain sky and water are doing real work.' ], [], '' ],
			] ],
			[ 'People in places', 14, [
				[ 'Scale and context', 11, 'A person in a landscape tells the viewer how big everything else is. Leave them small and the place speaks; move closer and they do.', [ 'Decide which one is the subject.', 'Put the person where the eye can find them in one second.' ], [], '' ],
				[ 'Waiting for the moment', 14, 'Find a good background, set your exposure and wait for something to happen in it. Patience is a technique, and most of the work is done before the shutter.', [ 'Choose the spot first, the subject second.', 'Take several frames as the moment builds.' ], [], '' ],
				[ 'Exercise: one corner, one hour', 18, 'Stand on one street corner for an hour and photograph only what passes through your frame. Count how many different pictures the same spot gives you.', [ 'Fix your exposure and focus before the first person walks in.', 'Keep the best three, not the best thirty.' ], [], '' ],
			] ],
			[ 'Breaking it on purpose', 21, [
				[ 'When to ignore the thirds', 10, 'Centring a subject can feel formal and strong, and cutting it off can feel urgent. Break the rule when you know what feeling you want instead.', [ 'Name the feeling before you break the rule.', 'Try the rule version first, for comparison.' ], [], '' ],
				[ 'Cropping as composition', 12, 'You can compose again after the shot. Crop to remove what does not help, but crop once and decide, rather than nudging the edges for an hour.', [ 'Crop to a clear aspect ratio, not an arbitrary one.', 'Keep the original; you may want it back.' ], [], '' ],
				[ 'Final assignment: a set of six', 14, 'Make a set of six photographs of one subject that each use a different compositional idea, then write a line about why you chose it.', [ 'Six different ideas, not six similar frames.', 'Order them so the set has a beginning and an end.' ], [], '' ],
			] ],
		],
	],
	[
		'slug' => 'night-and-astro', 'title' => 'Night & Astro', 'tier' => 'pro', 'cover' => 'milky-way-copper-breaks.jpg', 'video' => 'night-astro.mp4',
		'summary' => 'Photograph the night sky: plan the shoot, find the Milky Way, keep the stars sharp and light the land in front of them.',
		'description' => '<p>Ten lessons for Pro members, from planning a dark-sky night to editing a stacked Milky Way. Pro opens every module at once, so you can work at your own speed.</p>',
		'modules' => [
			[ 'Before dark', 0, [
				[ 'Planning a dark-sky night', 10, 'A good night sky shot starts at home with the moon phase, the cloud forecast and the light pollution map. A few minutes of planning decides whether the drive is worth it.', [ 'New moon weeks give the darkest skies.', 'Check the forecast the day before and again an hour before.' ], [ 'dark-sky-planner' ], 'free' ],
				[ 'Camera settings for stars', 14, 'Stars need a wide lens, a wide aperture, a long exposure and a high ISO, and every one of those has a cost. Start from a known setting and change one thing at a time.', [ 'Shoot RAW; the files carry far more than the preview.', 'Turn off long exposure noise reduction and stack instead.' ], [], '' ],
			] ],
			[ 'The Milky Way', 7, [
				[ 'Finding the core', 11, 'The bright centre of the galaxy is only above the horizon for part of the year, and at a set time of night. A planning app tells you where to point before it is visible.', [ 'The core is brightest in the northern summer.', 'Face south in the northern hemisphere.' ], [], '' ],
				[ 'Focus in the dark', 12, 'Autofocus fails at night, so focus manually on a bright star at maximum zoom. Check again after you change anything, since the ring can slip.', [ 'Use live view and zoom to ten times.', 'Tape the focus ring once you have it.' ], [], '' ],
				[ 'Exposure and the 500 rule', 13, 'The 500 rule gives a quick maximum exposure before stars begin to trail, but high-resolution sensors need less than it suggests. Treat it as a starting point and check your results at full size.', [ 'Divide 500 by your focal length for a rough limit in seconds.', 'On a 45-megapixel sensor, shorten it.' ], [], '' ],
			] ],
			[ 'Foreground and light', 14, [
				[ 'Lighting a foreground', 12, 'A dark landscape under a bright sky looks flat, so add a little light to the land. A low-power torch swept briefly across the foreground is often enough.', [ 'Use a red or warm light to protect night vision.', 'Light the foreground in a separate frame and blend later.' ], [], '' ],
				[ 'Blue hour to night blends', 14, 'Shoot the foreground at blue hour, when there is still detail in it, and the sky later when it is dark. Blending the two gives you a sharper landscape under a clean sky.', [ 'Keep the camera locked off between frames.', 'Match the white balance on both exposures.' ], [], '' ],
			] ],
			[ 'Stack and edit', 21, [
				[ 'Stacking for clean shadows', 13, 'Averaging several identical frames cancels out random noise while the stars stay put. Aim for eight to twelve frames and use software that aligns them.', [ 'Shoot the frames back to back.', 'Align on the stars for the sky and on the land for the ground.' ], [], '' ],
				[ 'Editing the Milky Way', 15, 'Raise contrast in the galaxy gently and protect the colour in the core. Local adjustments do most of the work, and global ones do the finishing.', [ 'Pull the black point down just to the edge of clipping.', 'Add colour last and sparingly.' ], [ 'bidik-preset-pack' ], '' ],
				[ 'Exercise: your first sky', 11, 'Go out on the next clear night and make one sharp, stacked photograph with a foreground that you have lit. Post it to the monthly critique thread.', [ 'Prefer a simple foreground.', 'Write down your settings so you can repeat them.' ], [], '' ],
			] ],
		],
	],
];
