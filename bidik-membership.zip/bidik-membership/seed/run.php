<?php
/**
 * Seeds the Bidik demo: PMPro pages and the five membership levels. Idempotent.
 * Run: node scripts/wp.mjs seed
 */
defined( 'ABSPATH' ) || exit;
global $wpdb;
$out = function_exists( 'bidik_out' ) ? 'bidik_out' : 'error_log';

// 0. remove spike leftovers
$wpdb->query( "DELETE FROM {$wpdb->pmpro_membership_levels} WHERE name LIKE 'Spike %'" );
foreach ( get_posts( [ 'title' => 'Spike gated article', 'post_type' => 'post', 'numberposts' => -1, 'post_status' => 'any' ] ) as $p ) {
	wp_delete_post( $p->ID, true );
}
require_once ABSPATH . 'wp-admin/includes/user.php';
foreach ( get_users( [ 'search' => 'spike_*', 'search_columns' => [ 'user_login' ] ] ) as $u ) {
	wp_delete_user( $u->ID );
}

// 1. PMPro does not create its pages on activation.
$pages = [
	'checkout'     => [ 'Checkout', '[pmpro_checkout]' ],
	'account'      => [ 'Account', '[bidik_account]' ],
	'billing'      => [ 'Billing', '[pmpro_billing]' ],
	'cancel'       => [ 'Cancel', '[pmpro_cancel]' ],
	'confirmation' => [ 'Welcome', '[pmpro_confirmation]' ],
	'invoice'      => [ 'Invoice', '[pmpro_invoice]' ],
	'levels'       => [ 'Pricing', '[bidik_pricing]' ],
];
foreach ( $pages as $slug => [ $title, $shortcode ] ) {
	$pid = (int) get_option( "pmpro_{$slug}_page_id" );
	if ( $pid && get_post( $pid ) ) {
		wp_update_post( [ 'ID' => $pid, 'post_title' => $title, 'post_content' => $shortcode ] );
	}
	if ( ! $pid || ! get_post( $pid ) ) {
		$pid = wp_insert_post( [ 'post_title' => $title, 'post_name' => "membership-$slug", 'post_content' => $shortcode, 'post_status' => 'publish', 'post_type' => 'page' ] );
		update_option( "pmpro_{$slug}_page_id", $pid );
	}
}

// 1-. gateway: our sandbox accepts Stripe's test cards. Real Stripe replaces it in M2b.
update_option( 'pmpro_gateway', 'bidik_sandbox' );
update_option( 'pmpro_gateway_environment', 'sandbox' );
update_option( 'pmpro_currency', 'USD' );
update_option( 'pmpro_wizard_step', 'done' ); // the setup wizard is for new PMPro sites; this one is configured here
delete_option( 'pmpro_wizard_redirect' );

// 1a. membership pages use the wide Membership template; Pricing has its own (page-membership-levels).
foreach ( [ 'checkout', 'account', 'billing', 'cancel', 'confirmation', 'invoice' ] as $slug ) {
	update_post_meta( (int) get_option( "pmpro_{$slug}_page_id" ), '_wp_page_template', 'membership' );
}
$home = get_page_by_path( 'home' );
$home_id = $home ? $home->ID : wp_insert_post( [ 'post_title' => 'Home', 'post_name' => 'home', 'post_content' => '[bidik_home]', 'post_status' => 'publish', 'post_type' => 'page' ] );
wp_update_post( [ 'ID' => $home_id, 'post_content' => '[bidik_home]' ] );
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home_id );

// 1b. site basics: name, no sample content
update_option( 'blogname', 'Bidik' );
update_option( 'blogdescription', 'Photography lessons, one module at a time' );
update_option( 'timezone_string', 'Asia/Jakarta' );
foreach ( [ 'Hello world!' => 'post', 'Sample Page' => 'page' ] as $title => $type ) {
	foreach ( get_posts( [ 'title' => $title, 'post_type' => $type, 'numberposts' => -1, 'post_status' => 'any' ] ) as $p ) {
		wp_delete_post( $p->ID, true );
	}
}

// 2. levels: initial payment is due today unless the level has a trial (then 0). Tier, interval, rank (upgrade vs downgrade), trial days.
$levels = [
	[ 'Free',             0,   0, 'month', 'free',   'month', 0, 0 ],
	[ 'Member (monthly)', 0,  12, 'month', 'member', 'month', 1, 7 ],
	[ 'Member (yearly)',120, 120, 'year',  'member', 'year',  1, 0 ],
	[ 'Pro (monthly)',   24,  24, 'month', 'pro',    'month', 2, 0 ],
	[ 'Pro (yearly)',   240, 240, 'year',  'pro',    'year',  2, 0 ],
];
$ids = [];
foreach ( $levels as [ $name, $initial, $amount, $period, $tier, $interval, $rank, $trial ] ) {
	$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->pmpro_membership_levels} WHERE name = %s", $name ) );
	$lvl = new PMPro_Membership_Level( $existing ?: null );
	$lvl->name = $name;
	$lvl->description = '';
	$lvl->confirmation = '';
	$lvl->initial_payment = $initial;
	$lvl->billing_amount = $amount;
	$lvl->cycle_number = $amount ? 1 : 0;
	$lvl->cycle_period = $amount ? ucfirst( $period ) : '';
	$lvl->billing_limit = 0;
	$lvl->trial_amount = 0;
	$lvl->trial_limit = 0;
	$lvl->expiration_number = 0;
	$lvl->expiration_period = '';
	$lvl->allow_signups = 1;
	$lvl->save();
	$id = (int) $lvl->id;
	update_pmpro_membership_level_meta( $id, 'bidik_tier', $tier );
	update_pmpro_membership_level_meta( $id, 'bidik_interval', $interval );
	update_pmpro_membership_level_meta( $id, 'bidik_rank', $rank );
	update_pmpro_membership_level_meta( $id, 'bidik_trial_days', $trial );
	update_pmpro_membership_level_meta( $id, 'drip_bypass', $rank >= 2 ? 1 : 0 );
	$ids[ $name ] = $id;
}
// 2b. one plan at a time: put the levels in a level group that allows a single choice (PMPro closes the old level itself on a plain checkout)
$group_id = function_exists( 'pmpro_get_group_id_for_level' ) ? (int) pmpro_get_group_id_for_level( reset( $ids ) ) : 0;
if ( $group_id ) {
	$wpdb->update( $wpdb->pmpro_groups, [ 'allow_multiple_selections' => 0 ], [ 'id' => $group_id ] );
}
// 3. discount codes: BIDIK30 (30% off) and FRIEND10 (10% off) on every paid level
$codes = [ 'BIDIK30' => 0.30, 'FRIEND10' => 0.10 ];
foreach ( $codes as $code => $off ) {
	$cid = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->pmpro_discount_codes} WHERE code = %s", $code ) );
	$data = [ 'code' => $code, 'starts' => gmdate( 'Y-m-d', strtotime( '-1 day' ) ), 'expires' => gmdate( 'Y-m-d', strtotime( '+2 years' ) ), 'uses' => 0 ];
	if ( $cid ) { $wpdb->update( $wpdb->pmpro_discount_codes, $data, [ 'id' => $cid ] ); } else { $wpdb->insert( $wpdb->pmpro_discount_codes, $data ); $cid = (int) $wpdb->insert_id; }
	$wpdb->delete( $wpdb->pmpro_discount_codes_levels, [ 'code_id' => $cid ] );
	foreach ( $levels as [ $name, , $amount, , , , , $trial_days ] ) {
		if ( $amount > 0 ) {
			$discounted = round( $amount * ( 1 - $off ), 2 );
			$wpdb->insert( $wpdb->pmpro_discount_codes_levels, [ 'code_id' => $cid, 'level_id' => $ids[ $name ], 'initial_payment' => $trial_days ? 0 : $discounted, 'billing_amount' => $discounted,
				'cycle_number' => 1, 'cycle_period' => 'month' === ( $name ) ? 'Month' : ( str_contains( $name, 'yearly' ) ? 'Year' : 'Month' ), 'billing_limit' => 0, 'trial_amount' => 0, 'trial_limit' => 0, 'expiration_number' => 0, 'expiration_period' => '' ] );
		}
	}
}
require __DIR__ . '/content.php';

// 4-5. the people you can "view as" in the demo, with their billing (see seed/personas.php; running again puts them back to the start)
require __DIR__ . '/personas.php';
foreach ( bidik_seed_personas( $ids ) as $line ) {
	$out( $line );
}
// 6. six months of history for the admin numbers (and the personas above are part of it)
require __DIR__ . '/history.php';
$t0 = microtime( true );
$out( 'history: ' . bidik_history_seed( in_array( 'rebuild', (array) ( $_SERVER['argv'] ?? [] ), true ) ) . sprintf( ' in %.1fs', microtime( true ) - $t0 ) );
\Bidik\Admin\Data::snapshot_today();
$all = pmpro_getAllLevels( true, false, true );
$out( 'levels: ' . count( $all ) . ' → ' . wp_json_encode( $ids ) );
foreach ( array_keys( $pages ) as $slug ) {
	$out( "page $slug → " . get_permalink( (int) get_option( "pmpro_{$slug}_page_id" ) ) );
}
$left = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_login LIKE 'spike_%'" );
$out( "spike users left: $left" );
