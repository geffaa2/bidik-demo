<?php
/** Seeds courses, lessons, articles and the Courses and Library pages. Idempotent: matches by slug and updates in place. */
defined( 'ABSPATH' ) || exit;

use Bidik\Content\PostTypes;

require_once __DIR__ . '/files.php';

function bidik_upsert( string $type, string $slug, array $data, array $meta ): int {
	$existing = get_posts( [ 'name' => $slug, 'post_type' => $type, 'post_status' => 'any', 'numberposts' => 1, 'suppress_filters' => true ] );
	$args     = $data + [ 'post_type' => $type, 'post_name' => $slug, 'post_status' => 'publish' ];
	if ( $existing ) {
		$args['ID'] = $existing[0]->ID;
	}
	$id = wp_insert_post( wp_slash( $args ), true );
	if ( is_wp_error( $id ) ) {
		throw new RuntimeException( $id->get_error_message() );
	}
	foreach ( $meta as $k => $v ) {
		update_post_meta( $id, "bidik_$k", is_array( $v ) ? wp_json_encode( $v ) : $v );
	}
	return (int) $id;
}

$stats = [ 'courses' => 0, 'lessons' => 0, 'articles' => 0 ];

// pages
foreach ( [ 'courses' => [ 'Courses', '[bidik_courses]' ], 'library' => [ 'Library', '[bidik_library]' ] ] as $key => [ $title, $code ] ) {
	$pid = (int) get_option( "bidik_page_$key" );
	if ( ! $pid || ! get_post( $pid ) ) {
		$pid = wp_insert_post( [ 'post_title' => $title, 'post_name' => $key, 'post_content' => $code, 'post_status' => 'publish', 'post_type' => 'page' ] );
		update_option( "bidik_page_$key", $pid );
	} else {
		wp_update_post( [ 'ID' => $pid, 'post_content' => $code, 'post_title' => $title ] );
	}
}

// files first, so lessons can show their sizes
$out( 'files: ' . implode( ', ', bidik_seed_files() ) );

// courses and lessons
$wanted = [];
foreach ( require __DIR__ . '/courses.php' as $order => $c ) {
	$modules = [];
	foreach ( $c['modules'] as [ $title, $days ] ) {
		$modules[] = [ 'title' => $title, 'days' => $days ];
	}
	$course_id = bidik_upsert( PostTypes::COURSE, $c['slug'], [ 'post_title' => $c['title'], 'post_content' => $c['description'], 'menu_order' => $order ],
		[ 'tier' => $c['tier'], 'cover' => $c['cover'], 'video' => $c['video'], 'summary' => $c['summary'], 'modules' => $modules ] );
	++$stats['courses'];
	$n = 0;
	foreach ( $c['modules'] as $mi => [ , , $lessons ] ) {
		foreach ( $lessons as [ $title, $minutes, $note, $bullets, $files, $tier ] ) {
			++$n;
			$slug     = $c['slug'] . '-' . sprintf( '%02d', $n ) . '-' . sanitize_title( $title );
			$wanted[] = $slug;
			$html     = '<p>' . esc_html( $note ) . '</p>' . ( $bullets ? '<ul>' . implode( '', array_map( static fn( $b ) => '<li>' . esc_html( $b ) . '</li>', $bullets ) ) . '</ul>' : '' );
			bidik_upsert( PostTypes::LESSON, $slug, [ 'post_title' => $title, 'post_content' => $html, 'menu_order' => $n ],
				[ 'course_id' => $course_id, 'module' => $mi, 'minutes' => $minutes, 'files' => $files, 'tier' => $tier ] );
			++$stats['lessons'];
		}
	}
}
// lessons that are no longer in the seed
foreach ( get_posts( [ 'post_type' => PostTypes::LESSON, 'numberposts' => -1, 'post_status' => 'any', 'suppress_filters' => true ] ) as $l ) {
	if ( ! in_array( $l->post_name, $wanted, true ) ) {
		wp_delete_post( $l->ID, true );
	}
}

// articles, newest first: the first in the list gets the latest date
$total = count( $articles = require __DIR__ . '/articles.php' );
foreach ( $articles as $i => [ $title, $kind, $read, $tier, $cover, $summary, $paras ] ) {
	$date = gmdate( 'Y-m-d H:i:s', strtotime( '2026-11-15 08:00:00' ) - $i * 3 * DAY_IN_SECONDS );
	bidik_upsert( PostTypes::ARTICLE, sanitize_title( $title ), [ 'post_title' => $title, 'post_content' => '<p>' . implode( '</p><p>', array_map( 'esc_html', $paras ) ) . '</p>', 'post_date_gmt' => $date, 'post_date' => get_date_from_gmt( $date ) ],
		[ 'kind' => $kind, 'read' => $read, 'tier' => $tier, 'cover' => $cover, 'summary' => $summary ] );
	++$stats['articles'];
}
flush_rewrite_rules( false );
$out( 'content: ' . wp_json_encode( $stats ) );
