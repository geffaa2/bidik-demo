<?php
/**
 * The library: 12 open articles and 12 for members. Each is [title, kind, minutes, tier, cover, summary, paragraphs].
 * Member articles are long enough that the 120-word teaser cuts them mid-way.
 */
$savanna = 'golden-hour-savanna.jpg';
$mekong  = 'mekong-golden-hour.jpg';
$milky   = 'milky-way-copper-breaks.jpg';
$window  = 'window-light-portrait.jpg';

return [
	// ---- open ----
	[ 'How to read a histogram in ten seconds', 'Field guide', 4, 'open', $savanna, 'The graph on the back of your camera, explained without any maths.', [
		'A histogram is a bar chart of how many pixels are dark, how many are middle grey and how many are bright. The left edge is black and the right edge is white. That is all it is.',
		'Look at two things. Is there a tall spike pressed against the right edge? Then your highlights have clipped and no software will bring them back. Is there a spike on the left? Then the shadows are crushed.',
		'A good histogram does not have a fixed shape. A night street should lean left and a snowy field should lean right. Judge it against the scene in front of you, not against a perfect hill.',
	] ],
	[ 'The three exposure settings, in the order that matters', 'Article', 5, 'open', $mekong, 'Aperture, shutter speed and ISO all trade against each other. Decide them in this order.', [
		'Start with what you are not willing to give up. If the subject moves, protect shutter speed. If you want a soft background, protect aperture. Everything else is a compromise around that choice.',
		'ISO comes last because it is the cheapest to change and the least visible in a modern camera. Raise it until the shutter speed and aperture you want give a good exposure, and accept the grain.',
		'Once you work this way the exposure triangle stops being a diagram and becomes a short list of questions you ask in the same order every time.',
	] ],
	[ 'Why your sunsets look flat', 'Article', 4, 'open', $savanna, 'The sky is rarely the problem. The missing foreground usually is.', [
		'A sunset on its own is a colour wash. It looks dramatic to you because you are standing in it, but the photograph has no scale and no layers.',
		'Add something in front of the sky: a tree, a rooftop, a person, a fence. A dark shape against the colour gives the eye somewhere to start and something to compare the sky with.',
		'Then expose for the sky, not the foreground. Let the shape go dark. A silhouette is a decision, not a mistake.',
	] ],
	[ 'A field guide to white balance', 'Field guide', 6, 'open', $savanna, 'What the Kelvin numbers mean and when to ignore them.', [
		'White balance tells the camera what colour the light is, so it can make white things look white. Daylight sits around 5500 K, a tungsten bulb near 3000 K and open shade closer to 7000 K.',
		'In auto mode the camera guesses, and it guesses well in plain light. It struggles when one colour fills the frame, such as a red wall or a green forest, because it assumes the average should be grey.',
		'Shoot RAW and the setting stops being permanent: you can change it later without damage. Take one frame of a grey card or a white sheet at the start of a session and you will always have a reference.',
	] ],
	[ 'Shooting through a window without the reflection', 'Field guide', 3, 'open', $window, 'Three small changes that remove most of the glare.', [
		'Press the lens, with the hood on, against the glass. The hood blocks reflections from behind you and the glass stops being a mirror.',
		'Move to a window with the light outside brighter than the light inside. Turn off lamps behind you, and wear dark clothes if you can.',
		'A polarising filter helps when you cannot get close. Turn it slowly while you watch the screen until the reflection fades.',
	] ],
	[ 'What a 50 mm lens does to a face', 'Article', 4, 'open', $window, 'Why the same face looks different at 24 mm and at 85 mm.', [
		'A lens does not change a face. Distance does. Wide lenses make you stand close, and a close camera exaggerates the nose and shrinks the ears.',
		'A 50 mm lens on a full-frame camera sits in the middle: it sees roughly what your eyes see, from a distance that looks natural for a head-and-shoulders portrait.',
		'If you want a flatter, more compressed look, step back and use 85 mm or more. If you want energy and a sense of place, use a wider lens and go closer on purpose.',
	] ],
	[ 'Cleaning a sensor without panic', 'Field guide', 5, 'open', $savanna, 'Most dust spots can be fixed in five minutes and without touching the sensor.', [
		'Photograph a clear sky at f/16 with the lens out of focus. Dust spots appear as dark smudges and tell you whether cleaning is really needed.',
		'Start with a rocket blower, camera facing down, mirror up or shutter open. Never use canned air, which can spray propellant onto the sensor.',
		'If a spot remains, use a swab made for your sensor size and a single slow pass. If you are not comfortable with that, a camera shop will do it for a small fee.',
	] ],
	[ 'How we critique a photograph', 'Article', 5, 'open', $mekong, 'The three questions we ask in every critique, in the order we ask them.', [
		'First: what do you see? Say it plainly, without judgement. Describing a picture slows everyone down enough to notice what is actually there.',
		'Second: what is it trying to do? Look for the intention, even a modest one. A critique that ignores the photographer\'s aim is only an opinion.',
		'Third: what would make it stronger? Offer one change, and say why. One clear suggestion is worth ten vague ones.',
	] ],
	[ 'Choosing a first tripod', 'Field guide', 6, 'open', $milky, 'What to look for, and what you can ignore, when you buy your first one.', [
		'A tripod is judged by how still it keeps the camera, not by its list of features. Choose legs that are stiff when extended, and a head that locks without creeping.',
		'Weight is a compromise. A light carbon tripod is pleasant to carry and a heavier one is steadier in wind, so decide how far you will really walk with it.',
		'Skip the cheapest models that wobble. A mid-priced tripod that you take everywhere will beat an expensive one you leave at home.',
	] ],
	[ 'Shoot RAW, and what that really buys you', 'Article', 4, 'open', $savanna, 'It is not about quality. It is about how much room you have to change your mind.', [
		'A JPEG is a finished photograph: the camera has chosen white balance, contrast and colour, and thrown away what it did not use. A RAW file keeps what the sensor recorded.',
		'That extra information gives you room. You can recover a sky that was a stop too bright or lift a shadow that was a stop too dark, and change white balance without a penalty.',
		'The cost is storage and an extra step in editing. For anything you care about, it is worth it.',
	] ],
	[ 'Backing up a shoot on the road', 'Field guide', 5, 'open', $mekong, 'A simple routine so one dropped bag does not end a trip.', [
		'Keep every photograph in three places before you format a card: the card itself, a laptop or phone, and a second drive or cloud copy.',
		'Do it the same evening, while you remember which cards are full. Label them, and never put a full card back in the camera bag with the empty ones.',
		'If you shoot a lot, a pocket-sized drive and a card reader weigh almost nothing and remove most of the risk.',
	] ],
	[ 'The beginner\'s guide to focus modes', 'Field guide', 6, 'open', $milky, 'Single, continuous and manual: which to use when.', [
		'Single-shot autofocus locks once and stays there. It suits still subjects like landscapes and portraits, and it gives the camera time to be accurate.',
		'Continuous autofocus keeps following whatever you have selected. Use it for people, animals and vehicles, and let the camera track them while you frame.',
		'Manual focus is for the dark, for macro and for anything the camera cannot find. Learn to use focus peaking or a zoomed live view, and it becomes quick.',
	] ],

	// ---- members ----
	[ 'Golden hour is shorter than you think', 'Article', 6, 'member', $savanna, 'The best light of the evening lasts ten minutes, and it starts before the sun looks interesting.', [
		'Golden hour is an hour only in books. In most places the usable light, warm and low and soft enough to flatter a face, lasts closer to forty minutes, and the strongest part of it is shorter still. You are better off arriving thirty minutes early than ten minutes late.',
		'Plan the frame while the sun is still high. Choose where the shadows will fall, which way the subject will face and where you will stand when the light is lowest. By the time the sky turns orange you should only be pressing the shutter.',
		'Pay attention to the minutes after the sun has gone. The sky holds its colour while the ground goes cool and quiet, and the contrast between them often gives you the most interesting picture of the evening.',
		'Use a notebook or your phone to record when the good light really started and ended. After a few evenings in the same place you will know it better than any app can tell you.',
	] ],
	[ 'Backlight: keeping the face and the sky', 'Article', 7, 'member', $savanna, 'Shooting toward the sun gives you the glow, and the face is the price. Here is how to pay less.', [
		'When the sun is behind your subject the camera sees a bright sky and exposes for it, so the face goes dark. You have three honest choices: accept a silhouette, expose for the face and lose the sky, or add light to the face and keep both.',
		'Adding light is easier than it sounds. A white reflector, a pale wall or even a friend with a sheet of card will push the sun back toward the subject. Place it low and angled up, close enough to be useful and just out of frame.',
		'If you have no reflector, meter on the skin and let the sky blow out a little. The glow around the hair often looks better with a slightly bright background, and a lens hood and a clean front element reduce flare.',
		'Finally, move. A small step to either side changes where the sun sits relative to the head and can turn a flat halo into a clean rim of light.',
	] ],
	[ 'Window light, one reflector, no studio', 'Article', 8, 'member', $window, 'How to light a portrait with the window you already have.', [
		'One window and one reflector give you a portrait light that studios charge for. The window is a large, soft source that wraps around the face, and the reflector controls how deep the shadows go.',
		'Place your subject beside the window at about a forearm\'s length, turned a little toward it. Switch off the room lights, as they add a second colour and muddy the skin. Watch the face, not the camera screen, as you adjust.',
		'Hold the reflector on the side away from the window and angle it into the shadow. Move it closer to lift the shadow and farther away to deepen it. White gives a gentle fill and silver adds sparkle, which can be too much.',
		'Last, check the eyes. A bright window should leave a clean catchlight near the top of each eye. If it does not, ask your subject to tilt their chin a few degrees.',
	] ],
	[ 'Metering for snow and sand', 'Article', 5, 'member', $mekong, 'Bright scenes fool the meter into making them grey. Teach it better.', [
		'A camera meter assumes the scene averages out to middle grey. Point it at a snowfield and it darkens the picture to make the white look grey, so your snow ends up dull and blue.',
		'The fix is exposure compensation. Add between one and two stops of positive compensation on a bright scene and check the histogram until the bulk of it sits well to the right without touching the edge.',
		'Do the opposite for dark scenes: a black cat on a black sofa needs negative compensation, or the camera will lift it to grey.',
		'If the numbers feel arbitrary, meter off your own palm in the same light and add one stop. It is quick, repeatable, and free.',
	] ],
	[ 'Stars, trails and the 500 rule', 'Article', 7, 'member', $milky, 'A rule of thumb from the film era, and why modern sensors have outgrown it.', [
		'The 500 rule says to divide 500 by your focal length to find the longest exposure, in seconds, before stars start to streak. At 20 mm that gives 25 seconds, which would have worked well on a film camera.',
		'High-resolution sensors reveal the movement that older ones hid. At 45 megapixels, stars begin to stretch well before the rule says so, and photographers often use 300 or 400 in place of 500.',
		'The better way to choose is to take a test frame, zoom to 100 percent on a star near the edge, and look for an oval where there should be a point. If you see one, shorten the exposure.',
		'Trails are not a failure, either. Stack several long exposures and you get circles around the pole star, which is a different photograph and a good one.',
	] ],
	[ 'Street photography and the ten-metre rule', 'Article', 6, 'member', $mekong, 'How close is close enough, and how to stop worrying about it.', [
		'Most people shoot street photographs from too far away, because it feels safe. The picture then has no relationship with anyone in it and could have been taken by a security camera.',
		'Try staying within ten metres of your subjects. You will see faces, hands and the small details that make a moment, and you will be noticed less than you expect if you move calmly and smile.',
		'Be open about what you do. If someone asks, show them the frame and offer to delete it. In most cases they relax, and some of the best portraits come from the conversation that follows.',
		'Learn the rules where you shoot, because they vary. Respect places where photography is not welcome, and stop when asked.',
	] ],
	[ 'Colour grading a series so it holds together', 'Article', 8, 'member', $savanna, 'Pictures taken on different days can still look like one set.', [
		'A series works when the viewer feels a single hand behind every picture. That does not mean identical colour. It means shared choices: the same black point, a similar white balance direction and a limited range of saturation.',
		'Pick one hero frame and finish it first. Then open the others beside it and match them, adjusting exposure and white balance for each image rather than pasting the same settings onto all of them.',
		'View the set as a contact sheet and zoom out until you cannot see detail. Any picture that stands out in colour, even if it is a good one, is the one to adjust.',
		'Leave the set for a day, then look again. The odd ones will be obvious, and you will fix them in minutes.',
	] ],
	[ 'Why we crop before we edit', 'Article', 5, 'member', $mekong, 'Cropping first changes what the colour and contrast have to do.', [
		'Most people crop last. The trouble is that tone and colour adjustments are made to the whole frame, so they are tuned for areas that you later throw away.',
		'Crop first and the edit has a smaller job. The brightness of the subject is now judged against the real edges of the picture, and a distracting corner stops pulling at the eye.',
		'Keep the crop honest: choose a ratio, decide on the edges and stay with them. A crop you keep nudging will not improve.',
		'Remember that cropping costs pixels. If you know the picture will need to be cropped, shoot a little wider and leave yourself the room.',
	] ],
	[ 'Shooting a rainy city at night', 'Article', 7, 'member', $mekong, 'Wet streets are the best reflectors in town. Here is how to use them.', [
		'Rain changes a city after dark. Surfaces turn into mirrors, and every sign and headlight appears twice, once in the air and once under your feet.',
		'Protect the camera first. A cheap rain cover or a clear plastic bag with a hole for the lens is enough, and a lens hood keeps drops off the front element. Carry a microfibre cloth and wipe the lens often.',
		'Look down as much as you look up. Compose with a puddle in the foreground and let it carry the colours above, and expose for the highlights so signs do not burn out.',
		'Shoot at a slightly slow shutter, around one-fiftieth of a second, so passing people and umbrellas blur gently while the street stays sharp.',
	] ],
	[ 'Reading a scene for the layers', 'Article', 6, 'member', $savanna, 'Foreground, middle ground and background: the simplest way to give a picture depth.', [
		'Photographs are flat, so the feeling of depth has to be built. The easiest way to build it is to arrange three layers: something close, something in the middle and something far away.',
		'Start by finding the main subject, then look for an object that can sit in front of it. Leaves, a fence, a doorway or a person\'s shoulder all work as a foreground, as long as they do not compete for attention.',
		'Use light to separate the layers. A bright middle ground against a dark background, or the reverse, tells the eye which layer matters.',
		'Check the edges once you have the layers. A branch that touches the subject\'s head spoils the effect, and moving one step solves it.',
	] ],
	[ 'Long-exposure water without an ND filter', 'Article', 6, 'member', $mekong, 'Silky water at dawn or dusk, with the gear you already have.', [
		'Long exposures usually need a neutral density filter to cut the light, but the sun does the same job for free at dawn, at dusk and under heavy cloud.',
		'Set your camera on a tripod at the lowest ISO and a small aperture, such as f/16. In dim light that will often give you a shutter speed of a second or longer, which is enough to turn waves into mist.',
		'Use the timer or a remote release to avoid shaking the camera, and turn off any image stabilisation when the camera is on a tripod.',
		'Check the highlights after the first frame. Water in long exposures reflects the sky and can clip quickly, so lower the exposure if the histogram touches the right edge.',
	] ],
	[ 'Planning a trip around light, not landmarks', 'Article', 8, 'member', $milky, 'Choose where to stand and when, and let the landmark be a bonus.', [
		'Most trips are planned around places. Photographers get better pictures when they plan around light: where the sun rises, how it falls on a hillside and when a street turns into a corridor of gold.',
		'Use a sun-position app to see the direction of sunrise and sunset on the day you arrive. A landmark that faces east is a morning subject, and one that faces west belongs to the evening.',
		'Allow more days than you think you need in one place. Weather is the biggest variable, and staying put for three mornings gives you three chances at a good one.',
		'Keep midday free. The light is flat and harsh, so use that time to scout, edit or eat, and save your energy for the hours that count.',
	] ],
];
