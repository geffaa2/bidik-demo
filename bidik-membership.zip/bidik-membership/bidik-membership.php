<?php
/**
 * Plugin Name: Bidik Membership
 * Description: Billing state machine, drip, dunning and member tools on top of Paid Memberships Pro. Demo for a fictional photography school.
 * Version: 0.1.0
 * Requires PHP: 8.1
 * License: GPL-2.0-or-later
 * Text Domain: bidik
 */
defined( 'ABSPATH' ) || exit;

// PSR-4: Bidik\Foo\Bar -> src/Foo/Bar.php
spl_autoload_register( static function ( string $class ): void {
	if ( 0 !== strpos( $class, 'Bidik\\' ) ) {
		return;
	}
	$file = __DIR__ . '/src/' . str_replace( '\\', '/', substr( $class, 6 ) ) . '.php';
	if ( is_readable( $file ) ) {
		require_once $file;
	}
} );

define( 'BIDIK_FILE', __FILE__ );

\Bidik\Compat\SqliteShim::register();
\Bidik\Schema::register();
add_action( 'init', [ \Bidik\Pricing::class, 'register' ] );
add_action( 'init', [ \Bidik\Chrome::class, 'register' ] );
add_action( 'init', [ \Bidik\Content\PostTypes::class, 'register' ] );
add_action( 'init', [ \Bidik\Content\Gate::class, 'register' ] );
add_action( 'init', [ \Bidik\Content\Library::class, 'register' ] );
add_action( 'init', [ \Bidik\Courses\Views::class, 'register' ] );
add_action( 'init', [ \Bidik\Courses\DripJob::class, 'register' ] );
add_action( 'init', [ \Bidik\Account\Account::class, 'register' ] );
add_action( 'init', [ \Bidik\Admin\Pages::class, 'register' ] );
add_action( 'init', [ \Bidik\Import\Admin::class, 'register' ] );
add_action( 'init', [ \Bidik\Esp\Admin::class, 'register' ] );
add_action( 'init', [ \Bidik\Demo\Demo::class, 'register' ] );
// PMPro loads after us (alphabetical order), and its gateway base class only exists once it has.
add_action( 'plugins_loaded', static function (): void {
	if ( class_exists( 'PMProGateway' ) ) {
		require_once __DIR__ . '/src/Billing/gateway-sandbox.php';
		PMProGateway_bidik_sandbox::init();
		\Bidik\Billing\CheckoutBridge::register();
		\Bidik\Billing\Renewals::register();
	}
}, 20 );
// The demo's address changes every time Playground starts, which PMPro reads as "the site was moved" and pauses its services.
// A demo has nowhere to move to, so keep PMPro's last known address in step (only when BIDIK_DEMO is set).
add_action( 'plugins_loaded', static function (): void {
	if ( defined( 'BIDIK_DEMO' ) && BIDIK_DEMO && function_exists( 'pmpro_compare_siteurl' ) ) {
		update_option( 'pmpro_last_known_url', get_site_url( null, '', 'https' ), false );
	}
}, 30 );
register_activation_hook( __FILE__, [ \Bidik\Schema::class, 'install' ] );
